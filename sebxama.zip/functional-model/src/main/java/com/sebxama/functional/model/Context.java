package com.sebxama.functional.model;

public class Context implements URIOccurrence {

	private URI uri;
	private Statement statement;
	private ContextKind kind;
	
	public Context(URI uri, Statement statement) {
		uri.getContextOccurrences().add(this);
		this.uri = uri;
		this.statement = statement;
	}
	
	public URI getURI() {
		return this.uri;
	}
	
	public Statement getStatement() {
		return this.statement;
	}
	
	public void setKind(ContextKind kind) {
		kind.getContextOccurrences().add(this);
		this.kind = kind;
	}
	
	public ContextKind getKind() {
		return this.kind;
	}
	
}
