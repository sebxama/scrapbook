package core.model;

import java.util.HashMap;
import java.util.Map;

public class ObjectKindImpl extends ResourceImpl<ObjectKind> implements ObjectKind {

	private static Map<IRI, ObjectKind> objs = new HashMap<IRI, ObjectKind>();
	
	private Map<Statement, Object> instances;
	private Map<Statement, Property> attributes;
	private Map<Statement, Subject> values;
	
	public ObjectKindImpl(IRI iri) {
		super(iri);
		setResource(this);
		this.instances = new HashMap<Statement, Object>();
		this.attributes = new HashMap<Statement, Property>();
		this.values = new HashMap<Statement, Subject>();
	}

	public Object getInstance(Statement ctx) {
		return instances.get(ctx);
	}

	public Property getAttribute(Statement ctx) {
		return attributes.get(ctx);
	}

	public Subject getValue(Statement ctx) {
		return values.get(ctx);
	}

	public void setInstance(Statement ctx, Object inst) {
		this.instances.put(ctx, inst);
	}

	public void setAttribute(Statement ctx, Property prop) {
		this.attributes.put(ctx, prop);
	}

	public void setValue(Statement ctx, Subject val) {
		this.values.put(ctx, val);
	}
	
	public static ObjectKind getOrCreate(IRI iri) {
		ObjectKind ret = objs.get(iri);
		if(ret == null) {
			ret = new ObjectKindImpl(iri);
			objs.put(iri, ret);
		}
		return ret;
	}
	
}
