package com.cognescent.core.model;

import com.cognescent.core.streams.SubjectKindsStream;

public class SubjectKind extends Kind<StatementSubject, StatementPredicate, StatementObject> {

	protected SubjectKind() {
		SubjectKindsStream.getInstance().addSubjectKind(this);	
	}
	
	public String toString() {
		return "{ \"className\": \""+this.getClass().getName()+"\", \"IRI\" : \""+this.getIRI().getValue()+"\"}";
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}

}
