package com.sebxama.functional.model;

public class SubjectKind extends Kind {

	public SubjectKind(String uri) {
		super(uri);
	}
	
}
