package com.cognescent.core.model;

public class SubjectKind extends Kind<StatementSubject, StatementPredicate, StatementObject> {

}
