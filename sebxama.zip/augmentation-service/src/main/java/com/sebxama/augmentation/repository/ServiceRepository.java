package com.sebxama.augmentation.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;
import org.springframework.stereotype.Repository;

import com.sebxama.augmentation.model.Entity;

import reactor.core.publisher.Flux;

@Repository
public interface ServiceRepository extends R2dbcRepository<Entity, Integer> {

	Flux<Entity> findByNameContaining(String nombre);

}
