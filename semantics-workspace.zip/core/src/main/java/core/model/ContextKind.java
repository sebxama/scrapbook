package core.model;

public interface ContextKind extends Context, Kind {

	public Context getInstance();
	
	public Property getAttribute();
	
	public Object getValue();
	
}
