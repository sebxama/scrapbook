package com.cognescent.core.model;

import com.cognescent.core.streams.ContextKindsStream;

public class ObjectKindStatement extends KindStatement<StatementObject, StatementPredicate, StatementSubject> {
	
	public ObjectKindStatement(Kind<StatementObject, StatementPredicate, StatementSubject> kind, StatementObject instance, StatementPredicate attribute, StatementSubject value) {
		super(kind, instance, attribute, value);
		kind.addStatement(this);
	}

	public String toString() {
		return "{\"className\": \""+this.getClass().getName()+"\", "+ 
					"\"kind\" : "+this.getKind().toString()+", " +
					"\"instance\" : + "+this.getInstance().toString()+", " +
					"\"attribute\" : + "+this.getAttribute().toString()+", " +
					"\"value\" : + "+this.getValue().toString() + "}";
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
