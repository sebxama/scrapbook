package com.sebxama.alignment.service;

import org.eclipse.rdf4j.spring.support.RDF4JTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.sebxama.alignment.repository.ServiceRepository;
import com.sebxama.functional.model.Statement;

import reactor.core.publisher.Flux;

@Service
public class AlignmentService {

	@Autowired
	RDF4JTemplate rdfTemplate;
	
	@Autowired
	ServiceRepository serviceRepository;

	@Autowired
	WebClient.Builder wcBuilder;
	
	public Flux<Statement> perform(Flux<Statement> stream) {
		// TODO
		return null;
	}
	
}
