package com.cognescent.core.streams;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.IRI;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.Statement;
import com.cognescent.core.model.StatementContext;

import reactor.core.publisher.Flux;

public class StatementsStream {

	private static StatementsStream instance;
	public static StatementsStream getInstance() {
		if(instance == null)
			instance = new StatementsStream();
		return instance;
	}
	
	private Set<Statement> statements;
	
	protected StatementsStream() {
		this.statements = new HashSet<Statement>();
	}
	
	public void addStatement(Statement statement) {
		this.statements.add(statement);
	}
	
	public void removeStatement(Statement statement) {
		this.statements.remove(statement);
	}
	
	public Flux<Statement> getStream() {
		return Flux.fromIterable(this.statements);
	}
	
//	public Iterable<Kind> mapKinds(Iterable<IRI> match) {
//		// TODO: Use zipWith(T1: Statement (inst), T2: IRIs function (Embeddings), Result: Kinds. 
//		return null;
//	}
//	
//	public Iterable<IRI> mapIRIs(Iterable<Kind> match) {
//		// TODO:
//		return null;
//	}
	
}
