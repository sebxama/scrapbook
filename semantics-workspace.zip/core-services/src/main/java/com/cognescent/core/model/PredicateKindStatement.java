package com.cognescent.core.model;

import com.cognescent.core.streams.ContextKindsStream;

public class PredicateKindStatement extends KindStatement<StatementPredicate, StatementSubject, StatementObject> {
	
	public PredicateKindStatement(Kind<StatementPredicate, StatementSubject, StatementObject> kind, StatementPredicate instance, StatementSubject attribute, StatementObject value) {
		super(kind, instance, attribute, value);
		kind.addStatement(this);
	}

}
