package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

import com.cognescent.core.streams.PredicatesStream;

public class StatementPredicate extends IRIStatementOccurrence {

	private static Map<IRI, StatementPredicate> predicates = new HashMap<IRI, StatementPredicate>();

	protected StatementPredicate() {
		PredicatesStream.getInstance().addPredicate(this);
	}
	
	public static StatementPredicate get(IRI key) {
		StatementPredicate pred = predicates.get(key);
		if(pred == null) {
			pred = new StatementPredicate();
			pred.setIRI(key);
			predicates.put(key, pred);
		}
		return pred;
	}
	
}
