package com.cognescent.core.streams;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.IRI;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.Statement;
import com.cognescent.core.model.StatementContext;

import reactor.core.publisher.Flux;

public class IRIsStream {

	private static IRIsStream instance;
	public static IRIsStream getInstance() {
		if(instance == null)
			instance = new IRIsStream();
		return instance;
	}
	
	private Set<IRI> iris;
	
	protected IRIsStream() {
		this.iris = new HashSet<IRI>();
	}
	
	public void addIRI(IRI iri) {
		this.iris.add(iri);
	}
	
	public void removeIRI(IRI iri) {
		this.iris.remove(iri);
	}
	
	public Flux<IRI> getStream() {
		return Flux.fromIterable(this.iris);
	}
	
//	public Iterable<Kind> mapStatements(Iterable<Statement> match) {
//		// TODO:
//		return null;
//	}
//	
//	public Iterable<Statement> mapKinds(Iterable<Kind> match) {
//		// TODO:
//		return null;
//	}
	
}
