package com.cognescent.core.model;

public class PredicateKindStatement extends KindStatement<StatementPredicate, StatementSubject, StatementObject> {
	
	public PredicateKindStatement(Statement stat, Kind<StatementPredicate, StatementSubject, StatementObject> kind, StatementPredicate instance, StatementSubject attribute, StatementObject value) {
		super(kind, instance, attribute, value);
		this.setStatement(stat);
		kind.addStatement(this);
	}
	
	public String toString() {
		return "{\"className\": \""+this.getClass().getCanonicalName()+"\", "+ 
					"\"kind\" : "+this.getKind().toString()+", " +
					"\"statement\" : "+this.getStatement().toString()+", " +
					"\"instance\" : "+this.getInstance().toString()+", " +
					"\"attribute\" : "+this.getAttribute().toString()+", " +
					"\"value\" : "+this.getValue().toString() + "}";
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
