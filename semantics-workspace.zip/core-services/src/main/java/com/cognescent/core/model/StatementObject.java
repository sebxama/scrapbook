package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

import com.cognescent.core.streams.ObjectsStream;

public class StatementObject extends IRIStatementOccurrence {

	private static Map<IRI, StatementObject> objects = new HashMap<IRI, StatementObject>();

	protected StatementObject() {
		ObjectsStream.getInstance().addObject(this);
	}
	
	public static StatementObject get(IRI key) {
		StatementObject obj = objects.get(key);
		if(obj == null) {
			obj = new StatementObject();
			obj.setIRI(key);
			objects.put(key, obj);
		}
		return obj;
	}

	public String toString() {
		return "{ \"className\": \""+this.getClass().getName()+"\", \"IRI\" : \""+this.getIRI().getValue()+"\"}";
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
