package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

public class StatementObject extends IRIStatementOccurrence {

	private static Map<IRI, StatementObject> objects = new HashMap<IRI, StatementObject>();

	protected StatementObject() {

	}
	
	public static StatementObject getByIRI(IRI key) {
		StatementObject obj = objects.get(key);
		if(obj == null) {
			obj = new StatementObject();
			obj.setIRI(key);
			objects.put(key, obj);
		}
		return obj;
	}

	public String toString() {
		return "{ \"className\": \""+this.getClass().getCanonicalName()+"\", \"IRI\" : \""+this.getIRI().getValue()+"\"}";
	}
	
	public int hashCode() {
		return (this.getClass().getCanonicalName() + ":" + this.getIRI().getValue()).hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
