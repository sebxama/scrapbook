package com.cognescent.core.services.aggregation;

import java.util.HashMap;
import java.util.Map;

import com.cognescent.core.model.IRIStatementOccurrence;
import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementObject;
import com.cognescent.core.model.StatementPredicate;
import com.cognescent.core.model.StatementSubject;
import com.cognescent.core.services.aggregation.AggregationInstance.ContextAggregationInstance;
import com.cognescent.core.services.aggregation.AggregationInstance.ObjectAggregationInstance;
import com.cognescent.core.services.aggregation.AggregationInstance.PredicateAggregationInstance;
import com.cognescent.core.services.aggregation.AggregationInstance.SubjectAggregationInstance;

public class AggregationAttribute<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {

	private static Map<String, ContextAggregationAttribute> contextAggregations
		= new HashMap<String, ContextAggregationAttribute>();
	private static Map<String, SubjectAggregationAttribute> subjectAggregations
		= new HashMap<String, SubjectAggregationAttribute>();
	private static Map<String, PredicateAggregationAttribute> predicateAggregations
		= new HashMap<String, PredicateAggregationAttribute>();;
	private static Map<String, ObjectAggregationAttribute> objectAggregations
		= new HashMap<String, ObjectAggregationAttribute>();;
	
	private ATTR attribute;
	private Map<AggregationInstance<INST, ATTR, VAL>, AggregationValue<INST, ATTR, VAL>> values;
	
	public AggregationAttribute(ATTR attribute) {
		this.attribute = attribute;
		this.values = new HashMap<AggregationInstance<INST, ATTR, VAL>, AggregationValue<INST, ATTR, VAL>>();
	}

	public ATTR getAttribute() {
		return this.attribute;
	}
	
	public Map<AggregationInstance<INST, ATTR, VAL>, AggregationValue<INST, ATTR, VAL>> getValues() {
		return this.values;
	}

	public static ContextAggregationAttribute getContextAggregationAttribute(StatementSubject subj) {
		ContextAggregationAttribute ret = contextAggregations.get(subj.getIRI().getValue());
		if(ret == null) {
			ret = new ContextAggregationAttribute(subj);
			contextAggregations.put(subj.getIRI().getValue(), ret);
		}
		return ret;
	}

	public static SubjectAggregationAttribute getSubjectAggregationAttribute(StatementPredicate pred) {
		SubjectAggregationAttribute ret = subjectAggregations.get(pred.getIRI().getValue());
		if(ret == null) {
			ret = new SubjectAggregationAttribute(pred);
			subjectAggregations.put(pred.getIRI().getValue(), ret);
		}
		return ret;
	}

	public static PredicateAggregationAttribute getPredicateAggregationAttribute(StatementSubject subj) {
		PredicateAggregationAttribute ret = predicateAggregations.get(subj.getIRI().getValue());
		if(ret == null) {
			ret = new PredicateAggregationAttribute(subj);
			predicateAggregations.put(subj.getIRI().getValue(), ret);
		}
		return ret;
	}

	public static ObjectAggregationAttribute getObjectAggregationAttribute(StatementPredicate pred) {
		ObjectAggregationAttribute ret = objectAggregations.get(pred.getIRI().getValue());
		if(ret == null) {
			ret = new ObjectAggregationAttribute(pred);
			objectAggregations.put(pred.getIRI().getValue(), ret);
		}
		return ret;
	}
	
	static class ContextAggregationAttribute extends AggregationAttribute<StatementContext, StatementSubject, StatementObject> {

		public ContextAggregationAttribute(StatementSubject subj) {
			super(subj);
			contextAggregations.put(subj.getIRI().getValue(), this);
		}
		
	}
	
	static class SubjectAggregationAttribute extends AggregationAttribute<StatementSubject, StatementPredicate, StatementObject> {

		public SubjectAggregationAttribute(StatementPredicate pred) {
			super(pred);
			subjectAggregations.put(pred.getIRI().getValue(), this);
		}
		
	}
	
	static class PredicateAggregationAttribute extends AggregationAttribute<StatementPredicate, StatementSubject, StatementObject> {

		public PredicateAggregationAttribute(StatementSubject subj) {
			super(subj);
			predicateAggregations.put(subj.getIRI().getValue(), this);
		}
		
	}
	
	static class ObjectAggregationAttribute extends AggregationAttribute<StatementObject, StatementPredicate, StatementSubject> {

		public ObjectAggregationAttribute(StatementPredicate pred) {
			super(pred);
			objectAggregations.put(pred.getIRI().getValue(), this);
		}
		
	}
	
}
