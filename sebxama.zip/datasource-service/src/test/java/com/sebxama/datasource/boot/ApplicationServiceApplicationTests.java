package com.sebxama.datasource.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.sebxama.datasource.service.DatasourceService;

@SpringBootTest
class SpringBootServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
