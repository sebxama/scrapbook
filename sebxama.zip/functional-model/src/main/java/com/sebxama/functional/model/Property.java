package com.sebxama.functional.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sebxama.functional.model.objectmapper.deserializer.PropertyDeserializer;
import com.sebxama.functional.model.objectmapper.serializer.PropertySerializer;

@JsonDeserialize(using = PropertyDeserializer.class)
@JsonSerialize(using = PropertySerializer.class)
public class Property {

	private URI uri;
	private URI attribute;
	private URI value;
	
	public Property() {
		
	}

	public URI getURI() {
		return uri;
	}

	public void setURI(URI uri) {
		uri.getProperties().add(this);
		this.uri = uri;
	}

	public URI getAttribute() {
		return attribute;
	}

	public void setAttribute(URI attribute) {
		this.attribute = attribute;
	}

	public URI getValue() {
		return value;
	}

	public void setValue(URI value) {
		this.value = value;
	}
	
}
