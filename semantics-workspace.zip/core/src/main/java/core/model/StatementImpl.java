package core.model;

public class StatementImpl extends ResourceOccurrenceImpl implements Statement {

	private Context context;
	private Subject subject;
	private Property property;
	private Object object;
	
	protected StatementImpl(Resource iri) {
		super(iri);
	}

	public Context getContext() {
		return context;
	}

	public Subject getSubject() {
		return subject;
	}

	public Property getProperty() {
		return property;
	}

	public Object getObject() {
		return object;
	}

	public void setContext(Context context) {
		context.setContextStatement(this);
		this.context = context;
	}

	public void setSubject(Subject subject) {
		subject.setContextStatement(this);
		this.subject = subject;
	}

	public void setProperty(Property property) {
		property.setContextStatement(this);
		this.property = property;
	}

	public void setObject(Object object) {
		object.setContextStatement(this);
		this.object = object;
	}

	public ResourceOccurrence getInstance() {
		return this.subject;
	}

	public ResourceOccurrence getAttribute() {
		return this.property;
	}

	public ResourceOccurrence getValue() {
		return this.object;
	}

}
