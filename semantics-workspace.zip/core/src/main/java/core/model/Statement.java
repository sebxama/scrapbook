package core.model;

public interface Statement extends SubjectKind, PropertyKind, ObjectKind {

	public Context getContext();
	
	public Subject getSubject();
	
	public Property getProperty();
	
	public Object getObject();
	
	public ContextKind getContextKind();
	
	public SubjectKind getSubjectKind();
	
	public PropertyKind getPropertyKind();
	
	public ObjectKind getObjectKind();

	public void setContextKind(ContextKind kind);
	
	public void setSubjectKind(SubjectKind kind);
	
	public void setPropertyKind(PropertyKind kind);
	
	public void setObjectKind(ObjectKind kind);
	
}
