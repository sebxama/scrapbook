package core.model;

/**
 * Kind statements aggregated in function of their Instance,
 * Attribute, Value configuration.
 *
 */
public interface Kind {

	public Resource getInstance();
	
	public Resource getAttribute();
	
	public Resource getValue();
	
}
