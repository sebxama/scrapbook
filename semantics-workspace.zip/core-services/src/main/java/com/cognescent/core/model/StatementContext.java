package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

public class StatementContext extends IRIStatementOccurrence {

	private static Map<IRI, StatementContext> contexts = new HashMap<IRI, StatementContext>();
	
	public static StatementContext get(IRI key) {
		StatementContext ctx = contexts.get(key);
		if(ctx == null) {
			ctx = new StatementContext();
			ctx.setIRI(key);
			contexts.put(key, ctx);
		}
		return ctx;
	}
	
}
