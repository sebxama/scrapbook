package com.sebxama.functional.model.objectmapper.serializer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.sebxama.functional.model.SubjectKind;

public class SubjectKindSerializer extends StdSerializer<SubjectKind> {
    
    public SubjectKindSerializer() {
        this(null);
    }
  
    public SubjectKindSerializer(Class<SubjectKind> t) {
        super(t);
    }

    @Override
    public void serialize(SubjectKind value, JsonGenerator jgen, SerializerProvider provider)
    	throws IOException, JsonProcessingException {
 
        jgen.writeStartObject();
        jgen.writeStringField("source", value.getSource().getURI().getValue());
        jgen.writeObjectField("uri", value.getURI());
        jgen.writeEndObject();
    }

}
