package com.sebxama.functional.model;

public class ValueKind extends Kind {

	public ValueKind() {
		
	}

	public ValueKind(Kind src) {
		super(src);
	}

}
