package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

public class Kinds {

	private static Kinds instance;
	public static Kinds getInstance() {
		if(instance == null)
			instance = new Kinds();
		return instance;
	}
	
	private Map<String, ContextKind> contextKinds;
	private Map<String, SubjectKind> subjectKinds;
	private Map<String, PredicateKind> predicateKinds;
	private Map<String, ObjectKind> objectKinds;

	protected Kinds() {
		contextKinds = new HashMap<String, ContextKind>();
		subjectKinds = new HashMap<String, SubjectKind>();
		predicateKinds = new HashMap<String, PredicateKind>();
		objectKinds = new HashMap<String, ObjectKind>();
	}
	
	public ContextKind getContextKind(String iri) {
		ContextKind ret = contextKinds.get(iri);
		if(ret == null) {
			ret = new ContextKind();
			contextKinds.put(iri, ret);
		}
		return ret;
	}

	public SubjectKind getSubjectKind(String iri) {
		SubjectKind ret = subjectKinds.get(iri);
		if(ret == null) {
			ret = new SubjectKind();
			subjectKinds.put(iri, ret);
		}
		return ret;
	}
	
	public PredicateKind getPredicateKind(String iri) {
		PredicateKind ret = predicateKinds.get(iri);
		if(ret == null) {
			ret = new PredicateKind();
			predicateKinds.put(iri, ret);
		}
		return ret;
	}
	
	public ObjectKind getObjectKind(String iri) {
		ObjectKind ret = objectKinds.get(iri);
		if(ret == null) {
			ret = new ObjectKind();
			objectKinds.put(iri, ret);
		}
		return ret;
	}
	
}
