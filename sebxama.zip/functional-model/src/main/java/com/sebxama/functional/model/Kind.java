package com.sebxama.functional.model;

import java.util.HashSet;
import java.util.Set;

public abstract class Kind {

	private URI uri;
	private Set<Context> contextOccurrences;
	private Set<Subject> subjectOccurrences;
	private Set<Predicate> predicateOccurrences;
	private Set<Value> objectOccurrences;
	
	public Kind() {
		this.contextOccurrences = new HashSet<Context>();
		this.subjectOccurrences = new HashSet<Subject>();
		this.predicateOccurrences = new HashSet<Predicate>();
		this.objectOccurrences = new HashSet<Value>();
	}
	
	public URI getURI() {
		return this.uri;
	}
	
	public void setURI(URI uri) {
		this.uri = uri;
	}
	
	public Set<Context> getContextOccurrences() {
		return this.contextOccurrences;
	}

	public Set<Subject> getSubjectOccurrences() {
		return this.subjectOccurrences;
	}
	
	public Set<Predicate> getPredicateOccurrences() {
		return this.predicateOccurrences;
	}
	
	public Set<Value> getObjectOccurrences() {
		return this.objectOccurrences;
	}
	
}
