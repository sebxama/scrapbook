package core.model;

public abstract class ResourceOccurrenceImpl implements ResourceOccurrence {

	private Resource iri;
	private Statement context;
	
	public ResourceOccurrenceImpl(Resource iri) {
		this.iri = iri;
	}
	
	public Resource getIRI() {
		return iri;
	}

	public void setContextStatement(Statement context) {
		this.context = context;
	}
	
	public Statement getContextStatement() {
		return this.context;
	}
	
	public String toString() {
		String ret = this.getClass().getCanonicalName() + " : " + this.getIRI().toString() + "["+this.context.getIRI().toString()+"]";
		return ret;
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
