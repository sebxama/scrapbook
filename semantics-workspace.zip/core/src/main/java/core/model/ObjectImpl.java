package core.model;

import java.util.HashMap;
import java.util.Map;

public class ObjectImpl extends ResourceImpl<Object> implements Object {

	private static Map<IRI, Object> objs = new HashMap<IRI, Object>();
	
	public ObjectImpl(IRI iri) {
		super(iri);
		setResource(this);
	}

	public static Object getOrCreate(IRI iri) {
		Object ret = objs.get(iri);
		if(ret == null) {
			ret = new ObjectImpl(iri);
			objs.put(iri, ret);
		}
		return ret;
	}
	
}
