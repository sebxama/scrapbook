package com.sebxama.functional.model;

import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sebxama.functional.model.objectmapper.deserializer.URIDeserializer;
import com.sebxama.functional.model.objectmapper.serializer.URISerializer;

@JsonDeserialize(using = URIDeserializer.class)
@JsonSerialize(using = URISerializer.class)
public class URI {
	
	private String value;
	private Long primeID;
	private Set<Context> contextOccurrences;
	private Set<Subject> subjectOccurrences;
	private Set<Predicate> predicateOccurrences;
	private Set<Value> objectOccurrences;
	
	public URI() {
		this.contextOccurrences = new HashSet<Context>();
		this.subjectOccurrences = new HashSet<Subject>();
		this.predicateOccurrences = new HashSet<Predicate>();
		this.objectOccurrences = new HashSet<Value>();
	}
	
	public URI(String value) {
		this();
		this.value = value;
	}
	
	public String getValue() {
		return this.value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
	
	public Long getPrimeID() {
		return this.primeID;
	}

	public void setPrimeID(Long id) {
		this.primeID = id;
	}
	
	public Set<Context> getContextOccurrences() {
		return this.contextOccurrences;
	}
	
	public void setContextOccurrences(Set<Context> occs) {
		this.contextOccurrences = occs;
	}

	public Set<Subject> getSubjectOccurrences() {
		return this.subjectOccurrences;
	}

	public void setSubjectOccurrences(Set<Subject> occs) {
		this.subjectOccurrences = occs;
	}
	
	public Set<Predicate> getPredicateOccurrences() {
		return this.predicateOccurrences;
	}

	public void setPredicateOccurrences(Set<Predicate> occs) {
		this.predicateOccurrences = occs;
	}
	
	public Set<Value> getObjectOccurrences() {
		return this.objectOccurrences;
	}
	
	public void setObjectOccurrences(Set<Value> occs) {
		this.objectOccurrences = occs;
	}
	
	@Override
	public String toString() {
		return this.value;
	}
	
	@Override
	public int hashCode() {
		return this.value.hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof URI)
			if(obj.hashCode() == this.hashCode())
				return true;
		return false;
	}
	
}
