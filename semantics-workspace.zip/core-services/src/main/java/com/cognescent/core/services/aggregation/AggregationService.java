package com.cognescent.core.services.aggregation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.cognescent.core.model.ContextKind;
import com.cognescent.core.model.IRI;
import com.cognescent.core.model.IRIStatementOccurrence;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.ObjectKind;
import com.cognescent.core.model.PredicateKind;
import com.cognescent.core.model.Statement;
import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementObject;
import com.cognescent.core.model.StatementPredicate;
import com.cognescent.core.model.StatementSubject;
import com.cognescent.core.model.Statements;
import com.cognescent.core.model.SubjectKind;
import com.cognescent.core.services.aggregation.AggregationKind.ContextAggregationKind;
import com.cognescent.core.services.aggregation.AggregationKind.ObjectAggregationKind;
import com.cognescent.core.services.aggregation.AggregationKind.PredicateAggregationKind;
import com.cognescent.core.services.aggregation.AggregationKind.SubjectAggregationKind;

/**
 * Learn Types.
 *
 */
public class AggregationService {

	/*
	 * TODO: Kinds IRIStatementOccurrence / Context, Placeholder IRIs (Statement)
	 */
	public void performAggregation() {

		// 1. Aggregation: One Context per instance
		// 2. Merge Contexts: Contexts from lesser Attribute
		//    set count to same / increased Attribute set count
		//    Instances: compare contains relationship. Sub Kinds
		//    Attribute sets contains super Kind Attribute sets. 
		//    new Kinds (unseen Attributes). Multiple Kinds (Occurrences).
		// 3. Materialize merged / aggregated Contexts (Kinds)
		//    into Model Kinds / KindStatements.

		contextsAggregation();
		aggregateContextKinds();
		aggregateStatementContextKinds();

		subjectsAggregation();
		aggregateSubjectKinds();
		aggregateStatementSubjectKinds();

		predicatesAggregation();
		aggregatePredicateKinds();
		aggregateStatementPredicateKinds();

		objectsAggregation();
		aggregateObjectKinds();
		aggregateStatementObjectKinds();
	}

	private void contextsAggregation() {
		// Contexts
		for(StatementContext ctx : Statements.getInstance().getStatementContexts()) {

			AggregationKind.ContextAggregationKind kind = AggregationKind.getContextAggregationKind(ctx.getIRI());
			AggregationInstance.ContextAggregationInstance inst = AggregationInstance.getContextAggregationInstance(ctx);
			kind.getInstances().add(inst);

			for(Statement stat2 : Statements.getInstance().getStatements(ctx, null, null, null)) {

				inst.getRoles().put(stat2, kind);
				StatementSubject subj = stat2.getSubject();
				AggregationAttribute.ContextAggregationAttribute attr = AggregationAttribute.getContextAggregationAttribute(subj);
				kind.getAttributes().add(attr);

				for(Statement stat3 : Statements.getInstance().getStatements(ctx, subj, null, null)) {

					StatementObject obj = stat3.getObject();
					AggregationValue.ContextAggregationValue val = AggregationValue.getContextAggregationValue(obj);
					val.getInstances().put(attr, inst);
					attr.getValues().put(inst, val);
					kind.getValues().add(val);

				}
			}
		}
	}

	private void aggregateContextKinds() {

		List<ContextAggregationKind> kinds = new ArrayList<ContextAggregationKind>(AggregationKind.getContextAggregationKinds());
		Collections.sort(kinds, new Comparator<ContextAggregationKind>() {
			@Override
			public int compare(ContextAggregationKind o1, ContextAggregationKind o2) {
				if(o1.getAttributes().size() < o2.getAttributes().size())
					return -1;
				if(o1.getAttributes().size() > o2.getAttributes().size())
					return 1;
				return 0;
			}
		});

		for(ContextAggregationKind k1 : kinds) {
			for(ContextAggregationKind k2 : kinds) {
				if(k2.getAttributes().containsAll(k1.getAttributes())) {
					if(k1.getAttributes().size() == k2.getAttributes().size()) {
						// Same Kind.
						// FIXME: Calculate attributes hash (embedding).
						String mergedKindIRIString = "urn:kind://"+k1.getAttributes().hashCode()+":"+k2.getAttributes().hashCode();
						IRI mergedKindIRI = IRI.get(mergedKindIRIString);
						ContextAggregationKind mergedKind = AggregationKind.getContextAggregationKind(mergedKindIRI);
						mergedKind.getInstances().addAll(k1.getInstances());
						mergedKind.getAttributes().addAll(k1.getAttributes());
						mergedKind.getValues().addAll(k1.getValues());
						mergedKind.getInstances().addAll(k2.getInstances());
						mergedKind.getAttributes().addAll(k2.getAttributes());
						mergedKind.getValues().addAll(k2.getValues());
						AggregationKind.putContextAggregationKind(k1.getIRI(), mergedKind);
						AggregationKind.putContextAggregationKind(k2.getIRI(), mergedKind);
					} else {
						// k1 subset of k2 (Super Kind)
						k2.setParent(k1);
					}
				}				
			}
		}
	}

	private void aggregateStatementContextKinds() {
		for(ContextAggregationKind kind : AggregationKind.getContextAggregationKinds()) {
			ContextKind contextKind = ContextKind.getByIRI(kind.getIRI());
			// Populate
			Set<StatementContext> insts = new HashSet<StatementContext>();
			for(AggregationInstance<StatementContext, StatementSubject, StatementObject> aggrInst : kind.getInstances()) {
				StatementContext ctx = aggrInst.getInstance();
				insts.add(ctx);
			}
			contextKind.getInstances().addAll(insts);
			Set<StatementSubject> subjs = new HashSet<StatementSubject>();
			for(AggregationAttribute<StatementContext, StatementSubject, StatementObject> aggrAttr : kind.getAttributes()) {
				StatementSubject sub = aggrAttr.getAttribute();
				subjs.add(sub);
			}
			contextKind.getAttributes().addAll(subjs);
			Set<StatementObject> objs = new HashSet<StatementObject>();
			for(AggregationValue<StatementContext, StatementSubject, StatementObject> aggrVal : kind.getValues()) {
				StatementObject obj = aggrVal.getValue();
				objs.add(obj);
			}
			contextKind.getValues().addAll(objs);

			// Parent
			if(kind.getParent() != null) {
				ContextKind parent = ContextKind.getByIRI(kind.getParent().getIRI());
				contextKind.setParent(parent);
			}

			// Occurrences / Kind Statements
			for(IRIStatementOccurrence occur : contextKind.getIRI().getOccurrences()) {
				for(Statement stat : occur.getStatementOccurrences()) {
					stat.setContextKind(contextKind);
					contextKind.addStatement(stat.getContextKindStatement());
				}
			}
		}
	}

	private void subjectsAggregation() {
		// Subjects
		for(StatementSubject subj : Statements.getInstance().getStatementSubjects()) {

			AggregationKind.SubjectAggregationKind kind = AggregationKind.getSubjectAggregationKind(subj.getIRI());
			AggregationInstance.SubjectAggregationInstance inst = AggregationInstance.getSubjectAggregationInstance(subj);
			kind.getInstances().add(inst);

			for(Statement stat2 : Statements.getInstance().getStatements(null, subj, null, null)) {

				inst.getRoles().put(stat2, kind);
				StatementPredicate pred = stat2.getPredicate();
				AggregationAttribute.SubjectAggregationAttribute attr = AggregationAttribute.getSubjectAggregationAttribute(pred);
				kind.getAttributes().add(attr);

				for(Statement stat3 : Statements.getInstance().getStatements(null, subj, pred, null)) {

					StatementObject obj = stat3.getObject();
					AggregationValue.SubjectAggregationValue val = AggregationValue.getSubjectAggregationValue(obj);
					val.getInstances().put(attr, inst);
					attr.getValues().put(inst, val);
					kind.getValues().add(val);

				}
			}
		}
	}

	private void aggregateSubjectKinds() {

		List<SubjectAggregationKind> kinds = new ArrayList<SubjectAggregationKind>(AggregationKind.getSubjectAggregationKinds());
		Collections.sort(kinds, new Comparator<SubjectAggregationKind>() {
			@Override
			public int compare(SubjectAggregationKind o1, SubjectAggregationKind o2) {
				if(o1.getAttributes().size() < o2.getAttributes().size())
					return -1;
				if(o1.getAttributes().size() > o2.getAttributes().size())
					return 1;
				return 0;
			}
		});

		for(SubjectAggregationKind k1 : kinds) {
			for(SubjectAggregationKind k2 : kinds) {
				if(k2.getAttributes().containsAll(k1.getAttributes())) {
					if(k1.getAttributes().size() == k2.getAttributes().size()) {
						// Same Kind.
						// FIXME: Calculate attributes hash (embedding).
						String mergedKindIRIString = "urn:kind://"+k1.getAttributes().hashCode()+":"+k2.getAttributes().hashCode();
						IRI mergedKindIRI = IRI.get(mergedKindIRIString);
						SubjectAggregationKind mergedKind = AggregationKind.getSubjectAggregationKind(mergedKindIRI);
						mergedKind.getInstances().addAll(k1.getInstances());
						mergedKind.getAttributes().addAll(k1.getAttributes());
						mergedKind.getValues().addAll(k1.getValues());
						mergedKind.getInstances().addAll(k2.getInstances());
						mergedKind.getAttributes().addAll(k2.getAttributes());
						mergedKind.getValues().addAll(k2.getValues());
						AggregationKind.putSubjectAggregationKind(k1.getIRI(), mergedKind);
						AggregationKind.putSubjectAggregationKind(k2.getIRI(), mergedKind);
					} else {
						// k1 subset of k2 (Super Kind)
						k2.setParent(k1);
					}
				}				
			}
		}
	}

	private void aggregateStatementSubjectKinds() {
		for(SubjectAggregationKind kind : AggregationKind.getSubjectAggregationKinds()) {
			SubjectKind subjectKind = SubjectKind.getByIRI(kind.getIRI());
			// Populate
			Set<StatementSubject> insts = new HashSet<StatementSubject>();
			for(AggregationInstance<StatementSubject, StatementPredicate, StatementObject> aggrInst : kind.getInstances()) {
				StatementSubject ctx = aggrInst.getInstance();
				insts.add(ctx);
			}
			subjectKind.getInstances().addAll(insts);
			Set<StatementPredicate> preds = new HashSet<StatementPredicate>();
			for(AggregationAttribute<StatementSubject, StatementPredicate, StatementObject> aggrAttr : kind.getAttributes()) {
				StatementPredicate sub = aggrAttr.getAttribute();
				preds.add(sub);
			}
			subjectKind.getAttributes().addAll(preds);
			Set<StatementObject> objs = new HashSet<StatementObject>();
			for(AggregationValue<StatementSubject, StatementPredicate, StatementObject> aggrVal : kind.getValues()) {
				StatementObject obj = aggrVal.getValue();
				objs.add(obj);
			}
			subjectKind.getValues().addAll(objs);

			// Parent
			if(kind.getParent() != null) {
				SubjectKind parent = SubjectKind.getByIRI(kind.getParent().getIRI());
				subjectKind.setParent(parent);
			}

			// Occurrences / Kind Statements
			for(IRIStatementOccurrence occur : subjectKind.getIRI().getOccurrences()) {
				for(Statement stat : occur.getStatementOccurrences()) {
					stat.setSubjectKind(subjectKind);
					subjectKind.addStatement(stat.getSubjectKindStatement());
				}
			}
		}
	}

	private void predicatesAggregation() {
		// Predicates
		for(StatementPredicate pred : Statements.getInstance().getStatementPredicates()) {

			AggregationKind.PredicateAggregationKind kind = AggregationKind.getPredicateAggregationKind(pred.getIRI());
			AggregationInstance.PredicateAggregationInstance inst = AggregationInstance.getPredicateAggregationInstance(pred);
			kind.getInstances().add(inst);

			for(Statement stat2 : Statements.getInstance().getStatements(null, null, pred, null)) {

				inst.getRoles().put(stat2, kind);
				StatementSubject subj = stat2.getSubject();
				AggregationAttribute.PredicateAggregationAttribute attr = AggregationAttribute.getPredicateAggregationAttribute(subj);
				kind.getAttributes().add(attr);

				for(Statement stat3 : Statements.getInstance().getStatements(null, subj, pred, null)) {

					StatementObject obj = stat3.getObject();
					AggregationValue.PredicateAggregationValue val = AggregationValue.getPredicateAggregationValue(obj);
					val.getInstances().put(attr, inst);
					attr.getValues().put(inst, val);
					kind.getValues().add(val);

				}
			}
		}
	}

	private void aggregatePredicateKinds() {

		List<PredicateAggregationKind> kinds = new ArrayList<PredicateAggregationKind>(AggregationKind.getPredicateAggregationKinds());
		Collections.sort(kinds, new Comparator<PredicateAggregationKind>() {
			@Override
			public int compare(PredicateAggregationKind o1, PredicateAggregationKind o2) {
				if(o1.getAttributes().size() < o2.getAttributes().size())
					return -1;
				if(o1.getAttributes().size() > o2.getAttributes().size())
					return 1;
				return 0;
			}
		});

		for(PredicateAggregationKind k1 : kinds) {
			for(PredicateAggregationKind k2 : kinds) {
				if(k2.getAttributes().containsAll(k1.getAttributes())) {
					if(k1.getAttributes().size() == k2.getAttributes().size()) {
						// Same Kind.
						// FIXME: Calculate attributes hash (embedding).
						String mergedKindIRIString = "urn:kind://"+k1.getAttributes().hashCode()+":"+k2.getAttributes().hashCode();
						IRI mergedKindIRI = IRI.get(mergedKindIRIString);
						PredicateAggregationKind mergedKind = AggregationKind.getPredicateAggregationKind(mergedKindIRI);
						mergedKind.getInstances().addAll(k1.getInstances());
						mergedKind.getAttributes().addAll(k1.getAttributes());
						mergedKind.getValues().addAll(k1.getValues());
						mergedKind.getInstances().addAll(k2.getInstances());
						mergedKind.getAttributes().addAll(k2.getAttributes());
						mergedKind.getValues().addAll(k2.getValues());
						AggregationKind.putPredicateAggregationKind(k1.getIRI(), mergedKind);
						AggregationKind.putPredicateAggregationKind(k2.getIRI(), mergedKind);
					} else {
						// k1 subset of k2 (Super Kind)
						k2.setParent(k1);
					}
				}
			}
		}
	}

	private void aggregateStatementPredicateKinds() {
		for(PredicateAggregationKind kind : AggregationKind.getPredicateAggregationKinds()) {
			PredicateKind predicateKind = PredicateKind.getByIRI(kind.getIRI());
			// Populate
			Set<StatementPredicate> insts = new HashSet<StatementPredicate>();
			for(AggregationInstance<StatementPredicate, StatementSubject, StatementObject> aggrInst : kind.getInstances()) {
				StatementPredicate pred = aggrInst.getInstance();
				insts.add(pred);
			}
			predicateKind.getInstances().addAll(insts);
			Set<StatementSubject> subjs = new HashSet<StatementSubject>();
			for(AggregationAttribute<StatementPredicate, StatementSubject, StatementObject> aggrAttr : kind.getAttributes()) {
				StatementSubject sub = aggrAttr.getAttribute();
				subjs.add(sub);
			}
			predicateKind.getAttributes().addAll(subjs);
			Set<StatementObject> objs = new HashSet<StatementObject>();
			for(AggregationValue<StatementPredicate, StatementSubject, StatementObject> aggrVal : kind.getValues()) {
				StatementObject obj = aggrVal.getValue();
				objs.add(obj);
			}
			predicateKind.getValues().addAll(objs);

			// Parent
			if(kind.getParent() != null) {
				PredicateKind parent = PredicateKind.getByIRI(kind.getParent().getIRI());
				predicateKind.setParent(parent);
			}

			// Occurrences / Kind Statements
			for(IRIStatementOccurrence occur : predicateKind.getIRI().getOccurrences()) {
				for(Statement stat : occur.getStatementOccurrences()) {
					stat.setPredicateKind(predicateKind);
					predicateKind.addStatement(stat.getPredicateKindStatement());
				}
			}
		}
	}

	private void objectsAggregation() {
		// Objects
		for(StatementObject obj : Statements.getInstance().getStatementObjects()) {

			AggregationKind.ObjectAggregationKind kind = AggregationKind.getObjectAggregationKind(obj.getIRI());
			AggregationInstance.ObjectAggregationInstance inst = AggregationInstance.getObjectAggregationInstance(obj);
			kind.getInstances().add(inst);

			for(Statement stat2 : Statements.getInstance().getStatements(null, null, null, obj)) {

				inst.getRoles().put(stat2, kind);
				StatementPredicate pred = stat2.getPredicate();
				AggregationAttribute.ObjectAggregationAttribute attr = AggregationAttribute.getObjectAggregationAttribute(pred);
				kind.getAttributes().add(attr);

				for(Statement stat3 : Statements.getInstance().getStatements(null, null, pred, obj)) {

					StatementSubject subj = stat3.getSubject();
					AggregationValue.ObjectAggregationValue val = AggregationValue.getObjectAggregationValue(subj);
					val.getInstances().put(attr, inst);
					attr.getValues().put(inst, val);
					kind.getValues().add(val);

				}
			}
		}
	}

	private void aggregateObjectKinds() {

		List<ObjectAggregationKind> kinds = new ArrayList<ObjectAggregationKind>(AggregationKind.getObjectAggregationKinds());
		Collections.sort(kinds, new Comparator<ObjectAggregationKind>() {
			@Override
			public int compare(ObjectAggregationKind o1, ObjectAggregationKind o2) {
				if(o1.getAttributes().size() < o2.getAttributes().size())
					return -1;
				if(o1.getAttributes().size() > o2.getAttributes().size())
					return 1;
				return 0;
			}
		});

		for(ObjectAggregationKind k1 : kinds) {
			for(ObjectAggregationKind k2 : kinds) {
				if(k2.getAttributes().containsAll(k1.getAttributes())) {
					if(k1.getAttributes().size() == k2.getAttributes().size()) {
						// Same Kind.
						// FIXME: Calculate attributes hash (embedding).
						String mergedKindIRIString = "urn:kind://"+k1.getAttributes().hashCode()+":"+k2.getAttributes().hashCode();
						IRI mergedKindIRI = IRI.get(mergedKindIRIString);
						ObjectAggregationKind mergedKind = AggregationKind.getObjectAggregationKind(mergedKindIRI);
						mergedKind.getInstances().addAll(k1.getInstances());
						mergedKind.getAttributes().addAll(k1.getAttributes());
						mergedKind.getValues().addAll(k1.getValues());
						mergedKind.getInstances().addAll(k2.getInstances());
						mergedKind.getAttributes().addAll(k2.getAttributes());
						mergedKind.getValues().addAll(k2.getValues());
						AggregationKind.putObjectAggregationKind(k1.getIRI(), mergedKind);
						AggregationKind.putObjectAggregationKind(k2.getIRI(), mergedKind);
					} else {
						// k1 subset of k2 (Super Kind)
						k2.setParent(k1);
					}
				}
			}
		}
	}

	private void aggregateStatementObjectKinds() {
		for(ObjectAggregationKind kind : AggregationKind.getObjectAggregationKinds()) {
			ObjectKind objectKind = ObjectKind.getByIRI(kind.getIRI());
			// Populate
			Set<StatementObject> insts = new HashSet<StatementObject>();
			for(AggregationInstance<StatementObject, StatementPredicate, StatementSubject> aggrInst : kind.getInstances()) {
				StatementObject obj = aggrInst.getInstance();
				insts.add(obj);
			}
			objectKind.getInstances().addAll(insts);
			Set<StatementPredicate> preds = new HashSet<StatementPredicate>();
			for(AggregationAttribute<StatementObject, StatementPredicate, StatementSubject> aggrAttr : kind.getAttributes()) {
				StatementPredicate pred = aggrAttr.getAttribute();
				preds.add(pred);
			}
			objectKind.getAttributes().addAll(preds);
			Set<StatementSubject> subjs = new HashSet<StatementSubject>();
			for(AggregationValue<StatementObject, StatementPredicate, StatementSubject> aggrVal : kind.getValues()) {
				StatementSubject subj = aggrVal.getValue();
				subjs.add(subj);
			}
			objectKind.getValues().addAll(subjs);

			// Parent
			if(kind.getParent() != null) {
				ObjectKind parent = ObjectKind.getByIRI(kind.getParent().getIRI());
				objectKind.setParent(parent);
			}

			// Occurrences / Kind Statements
			for(IRIStatementOccurrence occur : objectKind.getIRI().getOccurrences()) {
				for(Statement stat : occur.getStatementOccurrences()) {
					stat.setObjectKind(objectKind);
					objectKind.addStatement(stat.getObjectKindStatement());
				}
			}
		}
	}

}
