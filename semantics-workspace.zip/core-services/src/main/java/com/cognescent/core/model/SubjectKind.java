package com.cognescent.core.model;

import com.cognescent.core.streams.SubjectKindsStream;

public class SubjectKind extends Kind<StatementSubject, StatementPredicate, StatementObject> {

	protected SubjectKind() {
		SubjectKindsStream.getInstance().addSubjectKind(this);	
	}
	
}
