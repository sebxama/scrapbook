package core.model;

public interface ObjectKind extends Context, Subject, Property, Object, Kind {

	public Object getInstance();
	
	public Property getAttribute();
	
	public Subject getValue();
	
}
