package core.model.aggregation;

// Infer CSPO Types
public class Aggregation {

}
