package core.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

public class StatementImpl extends ResourceOccurrenceImpl implements Statement {

	private Context context;
	private Subject subject;
	private Property property;
	private Object object;

	private ContextKind contextKind;
	private SubjectKind subjectKind;
	private PropertyKind propertyKind;
	private ObjectKind objectKind;
	
	protected StatementImpl(Resource iri) {
		super(iri);
	}

	@JsonBackReference
	public Context getContext() {
		return context;
	}

	@JsonBackReference
	public Subject getSubject() {
		return subject;
	}

	@JsonBackReference
	public Property getProperty() {
		return property;
	}

	@JsonBackReference
	public Object getObject() {
		return object;
	}

	public void setContext(Context context) {
		context.setContextStatement(this);
		this.context = context;
	}

	public void setSubject(Subject subject) {
		subject.setContextStatement(this);
		this.subject = subject;
	}

	public void setProperty(Property property) {
		property.setContextStatement(this);
		this.property = property;
	}

	public void setObject(Object object) {
		object.setContextStatement(this);
		this.object = object;
	}

	@JsonBackReference
	public ResourceOccurrence getInstance() {
		return this.subject;
	}

	@JsonBackReference
	public ResourceOccurrence getAttribute() {
		return this.property;
	}

	@JsonBackReference
	public ResourceOccurrence getValue() {
		return this.object;
	}
	
	public ContextKind getContextKind() {
		return contextKind;
	}

	public void setContextKind(ContextKind contextKind) {
		this.contextKind = contextKind;
	}

	public SubjectKind getSubjectKind() {
		return subjectKind;
	}

	public void setSubjectKind(SubjectKind subjectKind) {
		this.subjectKind = subjectKind;
	}

	public PropertyKind getPropertyKind() {
		return propertyKind;
	}

	public void setPropertyKind(PropertyKind propertyKind) {
		this.propertyKind = propertyKind;
	}

	public ObjectKind getObjectKind() {
		return objectKind;
	}

	public void setObjectKind(ObjectKind objectKind) {
		this.objectKind = objectKind;
	}

	@Override
	public Resource getResource() {
		return Resource.get("urn:statement:" + this.context.getResource().hashCode() + ":" + this.subject.getResource().hashCode() + ":" + this.property.getResource().hashCode() + ":" + this.object.getResource().hashCode());
	}
	
	@Override
	public String toString() {
		return getResource().getIRI();
	}
	
	@Override
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
