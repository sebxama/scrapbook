package com.cognescent.core.model;

import com.cognescent.core.streams.ObjectKindsStream;

public class ObjectKind extends Kind<StatementObject, StatementPredicate, StatementSubject> {

	protected ObjectKind() {
		ObjectKindsStream.getInstance().addObjectKind(this);	
	}
	
	public String toString() {
		return "{ \"className\": \""+this.getClass().getName()+"\", \"IRI\" : \""+this.getIRI().getValue()+"\"}";
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
