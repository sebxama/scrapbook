package com.cognescent.core.streams;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementSubject;

import reactor.core.publisher.Flux;

public class ContextsStream {

	private static ContextsStream instance;
	public static ContextsStream getInstance() {
		if(instance == null)
			instance = new ContextsStream();
		return instance;
	}
	
	private Set<StatementContext> contexts;
	
	protected ContextsStream() {
		this.contexts = new HashSet<StatementContext>();
	}
	
	public void addContext(StatementContext context) {
		this.contexts.add(context);
	}
	
	public void removeContext(StatementContext context) {
		this.contexts.remove(context);
	}
	
	public Flux<StatementContext> getStream() {
		return Flux.fromIterable(this.contexts);
	}
	
}
