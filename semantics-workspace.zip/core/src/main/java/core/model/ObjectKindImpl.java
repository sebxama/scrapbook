package core.model;

public class ObjectKindImpl extends KindImpl<Object, Property, Subject> implements ObjectKind {
	
	public ObjectKindImpl(Resource iri) {
		super(iri);
	}
	
	public ContextKind getContextKind() {
		return this.getContextStatement().getContextKind();
	}

	/**
	 * Relationship range.
	 */
	@Override
	public SubjectKind getSubjectKind() {
		return this.getContextStatement().getSubjectKind();
	}

	/**
	 * Relationship domain.
	 */
	@Override
	public PropertyKind getPropertyKind() {
		return this.getContextStatement().getPropertyKind();
	}
	
}
