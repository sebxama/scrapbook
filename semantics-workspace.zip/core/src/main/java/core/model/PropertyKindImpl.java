package core.model;

public class PropertyKindImpl extends KindImpl<Property, Subject, Object> implements PropertyKind {
	
	public PropertyKindImpl(Resource iri) {
		super(iri);
	}
	
}
