package com.sebxama.augmentation.service;

import org.eclipse.rdf4j.spring.support.RDF4JTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sebxama.augmentation.repository.ServiceRepository;

@Service
public class IndexService {

	@Autowired
	RDF4JTemplate rdfTemplate;
	
	@Autowired
	PrimesIDService idsService;
	
	@Autowired
	ServiceRepository serviceRepository;

}
