package core.model;

public interface Kind extends ResourceOccurrence {
	
	public ResourceOccurrence getInstance();
	
	public ResourceOccurrence getAttribute();
	
	public ResourceOccurrence getValue();
	
}
