package com.cognescent.core.model;

import com.cognescent.core.streams.SubjectKindsStream;

public class SubjectKind extends Kind<StatementSubject, StatementPredicate, StatementObject> {

	protected SubjectKind() {
		
	}
	
	public SubjectKind(StatementContext type, StatementSubject instance, StatementPredicate attribute, StatementObject value) {
		super(type, instance, attribute, value);
		SubjectKindsStream.getInstance().addSubjectKind(this);
	}
	
}
