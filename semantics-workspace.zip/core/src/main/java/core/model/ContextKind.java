package core.model;

public interface ContextKind extends Kind {

}
