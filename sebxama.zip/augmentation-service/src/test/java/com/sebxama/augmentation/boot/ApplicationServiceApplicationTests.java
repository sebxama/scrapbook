package com.sebxama.augmentation.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.sebxama.augmentation.service.NamingService;

@SpringBootTest
class SpringBootServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
