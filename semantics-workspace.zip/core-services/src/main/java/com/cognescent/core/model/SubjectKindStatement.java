package com.cognescent.core.model;

import com.cognescent.core.streams.ContextKindsStream;

public class SubjectKindStatement extends KindStatement<StatementSubject, StatementPredicate, StatementObject> {
	
	public SubjectKindStatement(Kind<StatementSubject, StatementPredicate, StatementObject> kind, StatementSubject instance, StatementPredicate attribute, StatementObject value) {
		super(kind, instance, attribute, value);
		kind.addStatement(this);
	}
	
}
