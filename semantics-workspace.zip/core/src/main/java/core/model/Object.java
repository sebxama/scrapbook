package core.model;

public interface Object extends Context {

}
