package core.model;

public interface ModelObject extends ResourceOccurrence {
	
}
