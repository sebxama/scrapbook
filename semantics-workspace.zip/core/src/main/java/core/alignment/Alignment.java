package core.alignment;

// Infer relationships / properties
public class Alignment {

}
