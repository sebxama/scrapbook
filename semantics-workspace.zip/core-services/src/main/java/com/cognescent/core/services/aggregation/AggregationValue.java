package com.cognescent.core.services.aggregation;

import com.cognescent.core.model.IRIStatementOccurrence;

public class AggregationValue<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {

	private VAL value;
	
	public AggregationValue(VAL value) {
		this.value = value;
	}
	
	public void setValue(VAL value) {
		this.value = value;
	}
	
	public VAL getValue() {
		return this.value;
	}
	
}
