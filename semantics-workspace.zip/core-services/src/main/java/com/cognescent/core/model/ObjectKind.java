package com.cognescent.core.model;

import com.cognescent.core.streams.ObjectKindsStream;

public class ObjectKind extends Kind<StatementObject, StatementPredicate, StatementSubject> {

	protected ObjectKind() {
		ObjectKindsStream.getInstance().addObjectKind(this);	
	}
	
}
