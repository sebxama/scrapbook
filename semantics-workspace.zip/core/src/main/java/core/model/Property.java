package core.model;

public interface Property extends ResourceOccurrence {

	public PropertyKind getPropertyKind();
	
}
