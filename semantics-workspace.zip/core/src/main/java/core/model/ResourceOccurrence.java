package core.model;

public interface ResourceOccurrence {

	public Resource getResource();
	
	public Statement getContextStatement();

	public void setContextStatement(Statement stat);
	
}
