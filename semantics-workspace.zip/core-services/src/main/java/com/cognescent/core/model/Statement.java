package com.cognescent.core.model;

import com.cognescent.core.streams.StatementsStream;

public class Statement /* extends IRIStatementOccurrence (reification) */ {

	private StatementContext context;
	private StatementSubject subject;
	private StatementPredicate predicate;
	private StatementObject object;
	
	private ContextKind contextKind;
	private SubjectKind subjectKind;
	private PredicateKind predicateKind;
	private ObjectKind objectKind;
	
	private ContextKindStatement contextKindStatement;
	private SubjectKindStatement subjectKindStatement;
	private PredicateKindStatement predicateKindStatement;
	private ObjectKindStatement objectKindStatement;
	
	public Statement() {
		StatementsStream.getInstance().addStatement(this);
	}
	
	public Statement(String contextIRI, String subjectIRI, String predicateIRI, String objectIRI) {
		this();
		IRI context = IRI.get(contextIRI);
		IRI subject = IRI.get(subjectIRI);
		IRI predicate = IRI.get(predicateIRI);
		IRI object = IRI.get(objectIRI);
		StatementContext statementContext = StatementContext.get(context);
		StatementSubject statementSubject = StatementSubject.get(subject);
		StatementPredicate statementPredicate = StatementPredicate.get(predicate);
		StatementObject statementObject = StatementObject.get(object);
		context.getOccurrences().add(statementContext);
		subject.getOccurrences().add(statementSubject);
		predicate.getOccurrences().add(statementPredicate);
		object.getOccurrences().add(statementObject);
		statementContext.getStatementOccurrences().add(this);
		statementSubject.getStatementOccurrences().add(this);
		statementPredicate.getStatementOccurrences().add(this);
		statementObject.getStatementOccurrences().add(this);
		this.context = statementContext;
		this.subject = statementSubject;
		this.predicate = statementPredicate;
		this.object = statementObject;
		this.contextKind = Kinds.getInstance().getContextKind(context.getValue());
		this.subjectKind = Kinds.getInstance().getSubjectKind(context.getValue());
		this.predicateKind = Kinds.getInstance().getPredicateKind(context.getValue());
		this.objectKind = Kinds.getInstance().getObjectKind(context.getValue());
		this.contextKind.getStatementOccurrences().add(statementContext);
		this.subjectKind.getStatementOccurrences().add(statementSubject);
		this.predicateKind.getStatementOccurrences().add(statementPredicate);
		this.objectKind.getStatementOccurrences().add(statementObject);
		this.contextKindStatement = getContextKindStatement();
		this.subjectKindStatement = getSubjectKindStatement();
		this.predicateKindStatement = getPredicateKindStatement();
		this.objectKindStatement = getObjectKindStatement();
	}
	
	public Statement(IRI context, IRI subject, IRI predicate, IRI object) {
		this();
		StatementContext statementContext = StatementContext.get(context);
		StatementSubject statementSubject = StatementSubject.get(subject);
		StatementPredicate statementPredicate = StatementPredicate.get(predicate);
		StatementObject statementObject = StatementObject.get(object);
		context.getOccurrences().add(statementContext);
		subject.getOccurrences().add(statementSubject);
		predicate.getOccurrences().add(statementPredicate);
		object.getOccurrences().add(statementObject);
		statementContext.getStatementOccurrences().add(this);
		statementSubject.getStatementOccurrences().add(this);
		statementPredicate.getStatementOccurrences().add(this);
		statementObject.getStatementOccurrences().add(this);		
		this.context = statementContext;
		this.subject = statementSubject;
		this.predicate = statementPredicate;
		this.object = statementObject;
		this.contextKind = Kinds.getInstance().getContextKind(context.getValue());
		this.subjectKind = Kinds.getInstance().getSubjectKind(context.getValue());
		this.predicateKind = Kinds.getInstance().getPredicateKind(context.getValue());
		this.objectKind = Kinds.getInstance().getObjectKind(context.getValue());
		this.contextKind.getStatementOccurrences().add(statementContext);
		this.subjectKind.getStatementOccurrences().add(statementSubject);
		this.predicateKind.getStatementOccurrences().add(statementPredicate);
		this.objectKind.getStatementOccurrences().add(statementObject);
		this.contextKindStatement = getContextKindStatement();
		this.subjectKindStatement = getSubjectKindStatement();
		this.predicateKindStatement = getPredicateKindStatement();
		this.objectKindStatement = getObjectKindStatement();
	}

	public Statement(StatementContext context, StatementSubject subject, StatementPredicate predicate, StatementObject object) {
		this();
		context.getStatementOccurrences().add(this);
		subject.getStatementOccurrences().add(this);
		predicate.getStatementOccurrences().add(this);
		object.getStatementOccurrences().add(this);		
		this.context = context;
		this.subject = subject;
		this.predicate = predicate;
		this.object = object;
		this.contextKind = Kinds.getInstance().getContextKind(context.getIRI().getValue());
		this.subjectKind = Kinds.getInstance().getSubjectKind(context.getIRI().getValue());
		this.predicateKind = Kinds.getInstance().getPredicateKind(context.getIRI().getValue());
		this.objectKind = Kinds.getInstance().getObjectKind(context.getIRI().getValue());
		this.contextKind.getStatementOccurrences().add(context);
		this.subjectKind.getStatementOccurrences().add(subject);
		this.predicateKind.getStatementOccurrences().add(predicate);
		this.objectKind.getStatementOccurrences().add(object);
		this.contextKindStatement = getContextKindStatement();
		this.subjectKindStatement = getSubjectKindStatement();
		this.predicateKindStatement = getPredicateKindStatement();
		this.objectKindStatement = getObjectKindStatement();
	}
	
	public StatementContext getContext() {
		return context;
	}

	public StatementSubject getSubject() {
		return subject;
	}

	public StatementPredicate getPredicate() {
		return predicate;
	}

	public StatementObject getObject() {
		return object;
	}
	
	public ContextKindStatement getContextKindStatement() {
		if(contextKindStatement == null) {
			contextKindStatement = new ContextKindStatement(this.contextKind, this.context, this.subject, this.object);
			contextKindStatement.setStatement(this);
		}
		return contextKindStatement;
	}
	
	public SubjectKindStatement getSubjectKindStatement() {
		if(subjectKindStatement == null) {
			subjectKindStatement = new SubjectKindStatement(this.subjectKind, this.subject, this.predicate, this.object);
			subjectKindStatement.setStatement(this);
		}
		return subjectKindStatement;
	}
	
	private PredicateKindStatement getPredicateKindStatement() {
		if(predicateKindStatement == null) {
			predicateKindStatement = new PredicateKindStatement(this.predicateKind, this.predicate, this.subject, this.object);
			predicateKindStatement.setStatement(this);
		}
		return predicateKindStatement;
	}
	
	private ObjectKindStatement getObjectKindStatement() {
		if(objectKindStatement == null) {
			objectKindStatement = new ObjectKindStatement(this.objectKind, this.object, this.predicate, this.subject);
			objectKindStatement.setStatement(this);
		}
		return objectKindStatement;
	}
	
	public ContextKind getContextKind() {
		return this.contextKind;
	}

	public SubjectKind getSubjectKind() {
		return this.subjectKind;
	}
	
	public PredicateKind getPredicateKind() {
		return this.predicateKind;
	}
	
	public ObjectKind getObjectKind() {
		return this.objectKind;
	}

}
