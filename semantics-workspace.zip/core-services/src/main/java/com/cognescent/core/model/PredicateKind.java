package com.cognescent.core.model;

public class PredicateKind extends Kind<StatementPredicate, StatementSubject, StatementObject> {

	public PredicateKind() {
		
	}
	
	public PredicateKind(StatementPredicate instance, StatementSubject attribute, StatementObject value) {
		super(instance, attribute, value);
	}
	
}
