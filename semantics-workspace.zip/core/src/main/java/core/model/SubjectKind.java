package core.model;

public interface SubjectKind extends Property, Object, Kind {

	// SubjectKind from Statements:
	// getInstance() : Subject
	// getAttribute() : Property
	// getValue() : Object
	
}
