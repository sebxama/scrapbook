package com.cognescent.ddd.dom;

public class Attribute extends Type {

	public Attribute() {
		super();
	}
	
	public Attribute(String iri) {
		super(iri);
	}
	
}
