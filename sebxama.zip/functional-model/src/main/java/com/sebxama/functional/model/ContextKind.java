package com.sebxama.functional.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ContextKind extends Kind {

	public ContextKind() {
		
	}
	
	public ContextKind(Kind src) {
		super(src);
	}

	@Override
	@SuppressWarnings("unchecked")
	public Set<Subject> getAttributes() {
		Set<Subject> ret = new HashSet<Subject>();
		for(Context ctx : super.getContextOccurrences()) {
			ret.add(ctx.getStatement().getSubject());
		}
		return ret;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Map<Subject, Set<Predicate>> getAttributeValues() {
		Map<Subject, Set<Predicate>> ret = new HashMap<Subject, Set<Predicate>>();
		Set<Subject> attrs = getAttributes();
		for(Subject subj : attrs) {
			Set<Predicate> vals = new HashSet<Predicate>();
			for(Subject occur : subj.getURI().getSubjectOccurrences()) {
				vals.add(occur.getStatement().getPredicate());
			}
			ret.put(subj, vals);
		}
		return ret;
	}

}
