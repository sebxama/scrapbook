package com.cognescent.core.fca;

import java.math.BigInteger;
import java.util.Set;

public class Embeddings {

	public static Set<BigInteger> factorize(BigInteger input) {
		// TODO:
		return null;
	}
	
	public static Set<BigInteger> commonFactors(BigInteger a, BigInteger b) {
		// TODO:
		return null;
	}
}
