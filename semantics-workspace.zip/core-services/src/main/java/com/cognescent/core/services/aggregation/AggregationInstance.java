package com.cognescent.core.services.aggregation;

import java.util.HashMap;
import java.util.Map;

import com.cognescent.core.model.IRI;
import com.cognescent.core.model.IRIStatementOccurrence;
import com.cognescent.core.model.Statement;
import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementObject;
import com.cognescent.core.model.StatementPredicate;
import com.cognescent.core.model.StatementSubject;
import com.cognescent.core.services.aggregation.AggregationKind.ContextAggregationKind;
import com.cognescent.core.services.aggregation.AggregationKind.ObjectAggregationKind;
import com.cognescent.core.services.aggregation.AggregationKind.PredicateAggregationKind;
import com.cognescent.core.services.aggregation.AggregationKind.SubjectAggregationKind;

public class AggregationInstance<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {
	
	private static Map<IRI, ContextAggregationInstance> contextAggregations
		= new HashMap<IRI, ContextAggregationInstance>();
	private static Map<IRI, SubjectAggregationInstance> subjectAggregations
		= new HashMap<IRI, SubjectAggregationInstance>();
	private static Map<IRI, PredicateAggregationInstance> predicateAggregations
		= new HashMap<IRI, PredicateAggregationInstance>();
	private static Map<IRI, ObjectAggregationInstance> objectAggregations
		= new HashMap<IRI, ObjectAggregationInstance>();
	
	private IRI iri;
	private INST instance;
	private Map<Statement, AggregationKind<INST, ATTR, VAL>> roles;
	
	protected AggregationInstance(INST instance) {
		this.iri = instance.getIRI();
		this.instance = instance;
		this.roles = new HashMap<Statement, AggregationKind<INST, ATTR, VAL>>();
	}
	
	public INST getInstance() {
		return this.instance;
	}

	public IRI getIRI() {
		return iri;
	}

	public void setIRI(IRI iri) {
		this.iri = iri;
	}
	
	public Map<Statement, AggregationKind<INST, ATTR, VAL>> getRoles() {
		return this.roles;
	}
	
	public static ContextAggregationInstance getContextAggregationInstance(StatementContext ctx) {
		ContextAggregationInstance ret = contextAggregations.get(ctx.getIRI());
		if(ret == null) {
			ret = new ContextAggregationInstance(ctx);
			contextAggregations.put(ctx.getIRI(), ret);
		}
		return ret;
	}

	public static SubjectAggregationInstance getSubjectAggregationInstance(StatementSubject subj) {
		SubjectAggregationInstance ret = subjectAggregations.get(subj.getIRI());
		if(ret == null) {
			ret = new SubjectAggregationInstance(subj);
			subjectAggregations.put(subj.getIRI(), ret);
		}
		return ret;
	}

	public static PredicateAggregationInstance getPredicateAggregationInstance(StatementPredicate pred) {
		PredicateAggregationInstance ret = predicateAggregations.get(pred.getIRI());
		if(ret == null) {
			ret = new PredicateAggregationInstance(pred);
			predicateAggregations.put(pred.getIRI(), ret);
		}
		return ret;
	}

	public static ObjectAggregationInstance getObjectAggregationInstance(StatementObject obj) {
		ObjectAggregationInstance ret = objectAggregations.get(obj.getIRI());
		if(ret == null) {
			ret = new ObjectAggregationInstance(obj);
			objectAggregations.put(obj.getIRI(), ret);
		}
		return ret;
	}
	
	static class ContextAggregationInstance extends AggregationInstance<StatementContext, StatementSubject, StatementObject> {

		public ContextAggregationInstance(StatementContext ctx) {
			super(ctx);
			contextAggregations.put(ctx.getIRI(), this);
		}
		
	}
	
	static class SubjectAggregationInstance extends AggregationInstance<StatementSubject, StatementPredicate, StatementObject> {

		public SubjectAggregationInstance(StatementSubject subj) {
			super(subj);
			subjectAggregations.put(subj.getIRI(), this);
		}
		
	}
	
	static class PredicateAggregationInstance extends AggregationInstance<StatementPredicate, StatementSubject, StatementObject> {

		public PredicateAggregationInstance(StatementPredicate pred) {
			super(pred);
			predicateAggregations.put(pred.getIRI(), this);
		}
		
	}
	
	static class ObjectAggregationInstance extends AggregationInstance<StatementObject, StatementPredicate, StatementSubject> {

		public ObjectAggregationInstance(StatementObject obj) {
			super(obj);
			objectAggregations.put(obj.getIRI(), this);
		}
		
	}
	
}
