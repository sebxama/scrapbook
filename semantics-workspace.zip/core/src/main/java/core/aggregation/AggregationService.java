package core.aggregation;

import java.io.Reader;
import java.io.StringReader;
import java.util.Set;

import org.eclipse.rdf4j.model.Model;
import org.eclipse.rdf4j.model.Resource;
import org.eclipse.rdf4j.rio.RDFFormat;
import org.eclipse.rdf4j.spring.support.RDF4JTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import core.model.Context;
import core.model.ContextImpl;
import core.model.ContextKindImpl;
import core.model.Subject;
import core.model.SubjectImpl;
import core.model.SubjectKind;
import core.model.SubjectKindImpl;
import core.model.SubjectKindStatement;
import core.model.SubjectKinds;
import reactor.core.publisher.Flux;
import core.model.Property;
import core.model.PropertyImpl;
import core.model.PropertyKindImpl;
import core.model.Statement;
import core.model.StatementImpl;
import core.model.Object;
import core.model.ObjectImpl;
import core.model.ObjectKindImpl;
import core.model.Statements;


@Service
public class AggregationService {

	private RDF4JTemplate rdf4jTemplate;
	
	public AggregationService(@Autowired RDF4JTemplate rdf4jTemplate) {
		this.rdf4jTemplate = rdf4jTemplate;
	}

	public void loadRDFData(String data, RDFFormat format) {
		Reader reader = new StringReader(data);
		rdf4jTemplate.consumeConnection(con -> {
			try { con.add(reader, format, (Resource[])null); } catch(Throwable t) { t.printStackTrace(); }
		});
	}
	
	public void loadRepositoryStatements(String sparqlQuery, String[] sparqlRules /* SPIN Like*/) {

		if(sparqlRules != null) {
			for(String rule : sparqlRules) {
				Model model = rdf4jTemplate.graphQuery(rule)
						.evaluateAndConvert()
						.toModel();
				rdf4jTemplate.consumeConnection(con -> {
					try { con.add(model, (Resource[])null); } catch(Throwable t) { t.printStackTrace(); }
				});
			}
		}
		
		// FIXME: Query including contexts (quads)
		if(sparqlQuery == null) { // Retrieve all statements
			sparqlQuery = "CONSTRUCT {?s ?p ?o} WHERE { $s $p $o }";
		}
		
		Model model = rdf4jTemplate.graphQuery(sparqlQuery)
									.evaluateAndConvert()
									.toModel();

		Statements.getInstance().getStatements().clear();
		
		for(org.eclipse.rdf4j.model.Statement st : model) {
			
			// FIXME: Initial Context (Subject Hash?)
			String ctx = st.getContext() != null ? st.getContext().stringValue() : "urn:context:root";
			Context context = new ContextImpl(core.model.Resource.getContextResource(ctx));
			
			String sub = st.getSubject().stringValue();
			Subject subject = new SubjectImpl(core.model.Resource.getSubjectResource(sub));
			
			String pred = st.getPredicate().stringValue();
			Property property = new PropertyImpl(core.model.Resource.getPropertyResource(pred));
			
			// FIXME: Handle Literals
			String obj = st.getObject().isLiteral() ? st.getObject().stringValue().hashCode()+"" : st.getObject().stringValue();
			Object object = new ObjectImpl(core.model.Resource.getObjectResource(obj));

			StatementImpl stat = Statements.getInstance().addStatement(context, subject, property, object);

			// FIXME: Default initial Kinds
			
			ContextKindImpl ck = new ContextKindImpl(core.model.Resource.getContextKindResource(context, property, object));
			ck.setInstance(context);
			ck.setAttribute(property);
			ck.setValue(object);
			ck.setContextStatement(stat);
			stat.setContextKind(ck);
			
			SubjectKindImpl sk = new SubjectKindImpl(core.model.Resource.getSubjectKindResource(subject, property, object));
			sk.setInstance(subject);
			sk.setAttribute(property);
			sk.setValue(object);
			sk.setContextStatement(stat);
			stat.setSubjectKind(sk);
			
			PropertyKindImpl pk = new PropertyKindImpl(core.model.Resource.getPropertyKindResource(property, subject, object));
			pk.setInstance(property);
			pk.setAttribute(subject);
			pk.setValue(object);
			pk.setContextStatement(stat);
			stat.setPropertyKind(pk);

			ObjectKindImpl ok = new ObjectKindImpl(core.model.Resource.getObjectKindResource(object, property, subject));
			ok.setInstance(object);
			ok.setAttribute(property);
			ok.setValue(subject);
			ok.setContextStatement(stat);
			stat.setObjectKind(ok);
			
		}
	}

	public Set<SubjectKindStatement> performAggregation() {
		// return Flux.fromIterable(Statements.getInstance().getStatements());
		return SubjectKinds.getInstance().getSubjectKindStatements();
	}
	
}
