package core.model;

/**
 * 1. Instantiate all input statements.
 * 2. Aggregate Kinds.
 * 3. Populate Context Resources (CSPOs).
 *
 */
public interface Statement extends SubjectKind, PropertyKind, ObjectKind {

	public Context getContext();
	
	public Subject getSubject();
	
	public Property getProperty();
	
	public Object getObject();
	
	// From aggregated Kind statements
	
	public ContextKind getContextKind();
	
	public SubjectKind getSubjectKind();
	
	public PropertyKind getPropertyKind();
	
	public ObjectKind getObjectKind();
	
}
