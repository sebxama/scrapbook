package com.cognescent.core.model;

public class StatementSubject extends IRIStatementOccurrence {

}
