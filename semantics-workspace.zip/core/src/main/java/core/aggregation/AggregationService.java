package core.aggregation;

import java.io.Reader;
import java.io.StringReader;

import org.eclipse.rdf4j.model.Model;
import org.eclipse.rdf4j.model.Resource;
import org.eclipse.rdf4j.rio.RDFFormat;
import org.eclipse.rdf4j.spring.support.RDF4JTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import core.model.Context;
import core.model.ContextImpl;
import core.model.Subject;
import core.model.SubjectImpl;
import reactor.core.publisher.Flux;
import core.model.Property;
import core.model.PropertyImpl;
import core.model.Statement;
import core.model.Object;
import core.model.ObjectImpl;
import core.model.Statements;


@Service
public class AggregationService {

	private RDF4JTemplate rdf4jTemplate;
	
	public AggregationService(@Autowired RDF4JTemplate rdf4jTemplate) {
		this.rdf4jTemplate = rdf4jTemplate;
	}

	public void loadRDFData(String data, RDFFormat format) {
		Reader reader = new StringReader(data);
		rdf4jTemplate.consumeConnection(con -> {
			try { con.add(reader, format, (Resource[])null); } catch(Throwable t) { t.printStackTrace(); }
		});
	}
	
	public void loadRepositoryStatements(String sparqlQuery, String[] sparqlRules /* SPIN Like*/) {

		if(sparqlRules != null) {
			for(String rule : sparqlRules) {
				Model model = rdf4jTemplate.graphQuery(rule)
						.evaluateAndConvert()
						.toModel();
				rdf4jTemplate.consumeConnection(con -> {
					try { con.add(model, (Resource[])null); } catch(Throwable t) { t.printStackTrace(); }
				});
			}
		}
		
		// FIXME: Query including contexts (quads)
		if(sparqlQuery == null) { // Retrieve all statements
			sparqlQuery = "CONSTRUCT {?s ?p ?o} WHERE { $s $p $o }";
		}
		
		Model model = rdf4jTemplate.graphQuery(sparqlQuery)
									.evaluateAndConvert()
									.toModel();

		Statements.getInstance().getStatements().clear();
		
		for(org.eclipse.rdf4j.model.Statement st : model) {
			// FIXME: Initial Context (Subject Hash?)
			String ctx = st.getContext() != null ? st.getContext().stringValue() : "urn:context:root";
			Context context = new ContextImpl(core.model.Resource.get(ctx));
			String sub = st.getSubject().stringValue();
			Subject subject = new SubjectImpl(core.model.Resource.get(sub));
			String pred = st.getPredicate().stringValue();
			Property property = new PropertyImpl(core.model.Resource.get(pred));
			// FIXME: Handle Literals
			String obj = st.getObject().isLiteral() ? st.getObject().stringValue().hashCode()+"" : st.getObject().stringValue();
			Object object = new ObjectImpl(core.model.Resource.get(obj));
			Statements.getInstance().addStatement(context, subject, property, object);
		}
	}

	public Flux<Statement> performAggregation() {
		return Flux.fromIterable(Statements.getInstance().getStatements());
	}
	
}
