package core.model;

import java.util.HashMap;
import java.util.Map;

public interface SubjectKind extends Property, Object, Kind {
	
	public void setInstance(Statement ctx, Subject subj);
	
	public void setAttribute(Statement ctx, Property prop);
	
	public void setValue(Statement ctx, Object obj);
	
}
