package com.sebxama.functional.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ValueKind extends Kind {

	public ValueKind() {
		
	}

	public ValueKind(Kind src) {
		super(src);
	}

	@Override
	@SuppressWarnings("unchecked")
	public Set<Predicate> getAttributes() {
		Set<Predicate> ret = new HashSet<Predicate>();
		for(Value val : super.getObjectOccurrences()) {
			ret.add(val.getStatement().getPredicate());
		}
		return ret;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Map<Predicate, Set<Subject>> getAttributeValues() {
		Map<Predicate, Set<Subject>> ret = new HashMap<Predicate, Set<Subject>>();
		Set<Predicate> preds = getAttributes();
		for(Predicate pred : preds) {
			Set<Subject> vals = new HashSet<Subject>();
			for(Predicate occur : pred.getURI().getPredicateOccurrences()) {
				vals.add(occur.getStatement().getSubject());
			}
			ret.put(pred, vals);
		}
		return ret;
	}

}
