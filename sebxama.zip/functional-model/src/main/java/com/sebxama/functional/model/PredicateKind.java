package com.sebxama.functional.model;

public class PredicateKind extends Kind {

	public PredicateKind() {
		
	}
	
	public PredicateKind(Kind src) {
		super(src);
	}

}
