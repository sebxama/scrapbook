package com.sebxama.functional.service;

public class NamingService {

	private static NamingService instance;
	public static NamingService getInstance() {
		if(instance == null)
			instance = new NamingService();
		return instance;
	}
	
	protected NamingService() {
		
	}

}
