package com.cognescent.core.streams;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementObject;
import com.cognescent.core.model.StatementSubject;

import reactor.core.publisher.Flux;

public class SubjectsStream {

	private static SubjectsStream instance;
	public static SubjectsStream getInstance() {
		if(instance == null)
			instance = new SubjectsStream();
		return instance;
	}
	
	private Set<StatementSubject> subjects;
	
	protected SubjectsStream() {
		this.subjects = new HashSet<StatementSubject>();
	}
	
	public void addSubject(StatementSubject subject) {
		this.subjects.add(subject);
	}

	public void removeSubject(StatementSubject subject) {
		this.subjects.remove(subject);
	}
	
	public Flux<StatementSubject> getStream() {
		return Flux.fromIterable(this.subjects);
	}
	
}
