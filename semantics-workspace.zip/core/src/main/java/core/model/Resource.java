package core.model;

import java.util.Set;

/**
 * IRI Occurrences. From materialized Statements filter.
 */
public interface Resource {

	public IRI getIRI();
	
	public Set<Context> getContextOccurrences();
	
	public Set<Subject> getSubjectOccurrences();
	
	public Set<Property> getPropertyOccurrences();
	
	public Set<Object> getObjectOccurrences();
	
	public Set<ContextKind> getContextKindOccurrences();
	
	public Set<SubjectKind> getSubjectKindOccurrences();
	
	public Set<PropertyKind> getPropertyKindOccurrences();
	
	public Set<ObjectKind> getObjectKindOccurrences();
	
	public Set<Statement> getStatementOccurrences();
	
}
