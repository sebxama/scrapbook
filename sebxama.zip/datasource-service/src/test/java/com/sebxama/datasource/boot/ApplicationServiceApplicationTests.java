package com.sebxama.datasource.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.sebxama.datasource.service.ApplicationService;

@SpringBootTest
class SpringBootServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
