package com.cognescent.ddd.dci;

import com.cognescent.ddd.dom.Type;

public class Role {

	private Type type;
	
	public Role() {
		
	}
	
	public void setType(Type type) {
		this.type = type;
	}
	
	public Type getType() {
		return this.type;
	}
	
}
