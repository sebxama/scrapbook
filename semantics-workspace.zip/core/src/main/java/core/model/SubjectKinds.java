package core.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SubjectKinds {

	private static SubjectKinds instance;
	public static SubjectKinds getInstance() {
		if(instance == null)
			instance = new SubjectKinds();
		return instance;
	}
	
	protected SubjectKinds() {
		
	}

	public Map<Subject, SubjectKind> getSubjectAggregatedInstances() {
		Map<Subject, SubjectKind> ret = new HashMap<Subject, SubjectKind>();
		for(Statement stat : Statements.getInstance().getStatements()) {
			Subject key = stat.getSubject();
			SubjectKind kind = ret.get(key);
			if(kind == null)
				kind = SubjectKindImpl.getOrCreate(key.getIRI());
			kind.getIRI().getOccurrences().add(stat);
			kind.setInstance(stat, key);
			kind.setAttribute(stat, stat.getProperty());
			kind.setValue(stat, stat.getObject());
			ret.put(key, kind);
		}
		return ret;
	}

}
