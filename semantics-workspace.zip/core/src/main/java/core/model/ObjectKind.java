package core.model;

public interface ObjectKind extends Subject, Property, Kind {

}
