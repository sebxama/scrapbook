package core.model;

public interface Property extends ResourceOccurrence {

}
