package core.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

public class SubjectImpl extends ResourceOccurrenceImpl implements Subject {
	
	public SubjectImpl(Resource iri) {
		super(iri);
	}
	
	@JsonBackReference
	public SubjectKind getSubjectKind() {
		return this.getContextStatement().getSubjectKind();
	}
	
}
