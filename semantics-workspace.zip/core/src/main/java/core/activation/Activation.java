package core.activation;

// Infer state / flow: contexts / interactions.
public class Activation {

}
