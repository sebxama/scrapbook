package com.cognescent.core.model;

public class PredicateKind extends Kind<StatementPredicate, StatementSubject, StatementObject> {

}
