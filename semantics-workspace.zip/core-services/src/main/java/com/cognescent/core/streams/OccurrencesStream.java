package com.cognescent.core.streams;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.IRIStatementOccurrence;
import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementObject;

import reactor.core.publisher.Flux;

/**
 * Resources
 */
public class OccurrencesStream {

	private static OccurrencesStream instance;
	public static OccurrencesStream getInstance() {
		if(instance == null)
			instance = new OccurrencesStream();
		return instance;
	}
	
	private Set<IRIStatementOccurrence> occurrences;
	
	protected OccurrencesStream() {
		this.occurrences = new HashSet<IRIStatementOccurrence>();
	}
	
	public void addOccurrence(IRIStatementOccurrence occurrence) {
		this.occurrences.add(occurrence);
	}

	public void removeOccurrence(IRIStatementOccurrence occurrence) {
		this.occurrences.remove(occurrence);
	}
	
	public Flux<IRIStatementOccurrence> getStream() {
		return Flux.fromIterable(this.occurrences);
	}
	
}
