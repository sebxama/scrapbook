package core.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ObjectKinds {

	private static ObjectKinds instance;
	public static ObjectKinds getInstance() {
		if(instance == null)
			instance = new ObjectKinds();
		return instance;
	}
	
	protected ObjectKinds() {
		
	}

	// TODO:
	public Set<ObjectKind> getObjectKinds(Resource context, Resource instance, Resource attribute, Resource value) {
		Set<ObjectKind> ret = new HashSet<ObjectKind>();
		for(Statement stat : Statements.getInstance().getStatements(context, value, attribute, instance))
			ret.add(stat.getObjectKind());
		return ret;
	}

	/**
	 * FCA Concepts context lattice building. Kind Instance: Axis,
	 * Kind Attribute: FCA Context objects, Kind Value: FCA Context attributes.
	 * @return Kinds aggregated by distinct Objects Resource (IRI).
	 */
	public Map<Resource, Set<ObjectKind>> getObjectAggregatedKinds() {
		Map<Resource, Set<ObjectKind>> ret = new HashMap<Resource, Set<ObjectKind>>();
		for(Object obj : Objects.getInstance().getObjects()) {
			Set<ObjectKind> set = ret.get(obj.getResource());
			if(set == null)
				set = new HashSet<ObjectKind>();
			set.add(obj.getObjectKind());
			ret.put(obj.getResource(), set);
		}
		return ret;
	}

	/**
	 * Once Aggregated (FCA), Context Statements Kinds merged / updated.
	 * Populate corresponding Kind Statements from Kinds in Context Statements.
	 * @return Aggregated Kind Statements.
	 */
	public Set<ObjectKindStatement> getObjectKindStatements() {
		Set<ObjectKindStatement> ret = new HashSet<ObjectKindStatement>();
		Set<ObjectKind> kinds = getObjectKinds(null, null, null, null);
		for(ObjectKind kind : kinds) {
			Resource iri = Resource.getKindStatementResource(kind.getContextKind(), kind.getSubjectKind(), kind.getPropertyKind(), kind.getObjectKind());
			ObjectKindStatement stat = new ObjectKindStatement(iri);
			stat.setContext(kind.getContextStatement().getObjectKind());
			stat.setSubject(kind.getContextStatement().getSubjectKind());
			stat.setProperty(kind.getContextStatement().getPropertyKind());
			stat.setObject(kind.getContextStatement().getObjectKind());
			ret.add(stat);
		}
		return ret;
	}
	
}
