package core.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;

public abstract class ResourceOccurrenceImpl implements ResourceOccurrence {

	private Resource iri;
	private Statement context;
	
	public ResourceOccurrenceImpl(Resource iri) {
		this.iri = iri;
	}
	
	public Resource getResource() {
		return iri;
	}

	public void setContextStatement(Statement context) {
		this.context = context;
	}
	
	@JsonManagedReference
	public Statement getContextStatement() {
		return this.context;
	}
	
	public String toString() {
		String ret = this.getClass().getCanonicalName() + " : " + this.getResource().toString() + "["+this.context.getResource().toString()+"]";
		return ret;
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
