package core.model;

public interface Statement extends Context, Subject, Property, Object {

	public Context getContext();
	
	public Subject getSubject();
	
	public Property getProperty();
	
	public Object getObject();
	
	/**
	 * Updated / Merged in Aggregation
	 */
	public ContextKind getContextKind();

	/**
	 * Updated / Merged in Aggregation
	 */
	public SubjectKind getSubjectKind();
	
	/**
	 * Updated / Merged in Aggregation
	 */
	public PropertyKind getPropertyKind();
	
	/**
	 * Updated / Merged in Aggregation
	 */
	public ObjectKind getObjectKind();
	
}
