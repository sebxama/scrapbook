package com.cognescent.core.model;

import com.cognescent.core.streams.KindsStream;

// TODO: Refactor to KindStatement (AggregationKind population)
public abstract class Kind<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> /* extends Statement */ {

	private StatementContext type;
	private INST instance;
	private ATTR attribute;
	private VAL value;
	
	protected Kind() {
		KindsStream.getInstance().addKind(this);
	}
	
	public Kind(StatementContext type, INST instance, ATTR attribute, VAL value) {
		this();
		this.type = type;
		this.instance = instance;
		this.attribute = attribute;
		this.value = value;
	}

	public void setType(StatementContext type) {
		this.type = type;
	}
	
	public StatementContext getType() {
		return this.type;
	}
	
	public INST getInstance() {
		return instance;
	}

	public void setInstance(INST instance) {
		this.instance = instance;
	}

	public ATTR getAttribute() {
		return attribute;
	}

	public void setAttribute(ATTR attribute) {
		this.attribute = attribute;
	}

	public VAL getValue() {
		return value;
	}

	public void setValue(VAL value) {
		this.value = value;
	}
	
}
