package core.aggregation;

import java.io.Reader;
import java.io.StringReader;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.eclipse.rdf4j.model.Model;
import org.eclipse.rdf4j.model.Resource;
import org.eclipse.rdf4j.rio.RDFFormat;
import org.eclipse.rdf4j.spring.support.RDF4JTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import core.model.Context;
import core.model.ContextImpl;
import core.model.ContextKind;
import core.model.ContextKindImpl;
import core.model.Subject;
import core.model.SubjectImpl;
import core.model.SubjectKind;
import core.model.SubjectKindImpl;
import core.model.SubjectKindStatement;
import core.model.SubjectKinds;
import fcalib.api.fca.Attribute;
import fcalib.api.fca.Computation;
import fcalib.api.fca.Concept;
import fcalib.api.fca.ObjectAPI;
import fcalib.api.utils.OutputPrinter;
import fcalib.lib.fca.FCAAttribute;
import fcalib.lib.fca.FCAFormalContext;
import fcalib.lib.fca.FCAObject;
import reactor.core.publisher.Flux;
import core.model.Property;
import core.model.PropertyImpl;
import core.model.PropertyKind;
import core.model.PropertyKindImpl;
import core.model.Statement;
import core.model.StatementImpl;
import core.model.Object;
import core.model.ObjectImpl;
import core.model.ObjectKind;
import core.model.ObjectKindImpl;
import core.model.Statements;


@Service
public class AggregationService {

	private RDF4JTemplate rdf4jTemplate;
	
	public AggregationService(@Autowired RDF4JTemplate rdf4jTemplate) {
		this.rdf4jTemplate = rdf4jTemplate;
	}

	public void loadRDFData(String data, RDFFormat format) {
		Reader reader = new StringReader(data);
		rdf4jTemplate.consumeConnection(con -> {
			try { con.add(reader, format, (Resource[])null); } catch(Throwable t) { t.printStackTrace(); }
		});
	}
	
	public void loadRepositoryStatements(String sparqlQuery, String[] sparqlRules /* SPIN Like*/) {

		if(sparqlRules != null) {
			for(String rule : sparqlRules) {
				Model model = rdf4jTemplate.graphQuery(rule)
						.evaluateAndConvert()
						.toModel();
				rdf4jTemplate.consumeConnection(con -> {
					try { con.add(model, (Resource[])null); } catch(Throwable t) { t.printStackTrace(); }
				});
			}
		}
		
		// FIXME: Query including contexts (quads)
		if(sparqlQuery == null) { // Retrieve all statements
			sparqlQuery = "CONSTRUCT {?s ?p ?o} WHERE { $s $p $o }";
		}
		
		Model model = rdf4jTemplate.graphQuery(sparqlQuery)
									.evaluateAndConvert()
									.toModel();

		Statements.getInstance().getStatements().clear();
		
		for(org.eclipse.rdf4j.model.Statement st : model) {
			
			// FIXME: Initial Context (Subject Hash?)
			String ctx = st.getContext() != null ? st.getContext().stringValue() : "urn:context:root";
			Context context = new ContextImpl(core.model.Resource.getContextResource(ctx));
			
			String sub = st.getSubject().stringValue();
			Subject subject = new SubjectImpl(core.model.Resource.getSubjectResource(sub));
			
			String pred = st.getPredicate().stringValue();
			Property property = new PropertyImpl(core.model.Resource.getPropertyResource(pred));
			
			// FIXME: Handle Literals
			String obj = st.getObject().isLiteral() ? st.getObject().stringValue().hashCode()+"" : st.getObject().stringValue();
			Object object = new ObjectImpl(core.model.Resource.getObjectResource(obj));

			StatementImpl stat = Statements.getInstance().addStatement(context, subject, property, object);

			// FIXME: Default initial Kinds
			
			ContextKind ck = ContextKindImpl.getInstance(context.getResource());
			ck.getInstances().add(context.getResource());
			ck.getAttributes(context.getResource()).add(property.getResource());
			ck.getValues(property.getResource()).add(object.getResource());
			context.setKind(ck);
			
			SubjectKind sk = SubjectKindImpl.getInstance(subject.getResource());
			sk.getInstances().add(subject.getResource());
			sk.getAttributes(subject.getResource()).add(property.getResource());
			sk.getValues(property.getResource()).add(object.getResource());
			subject.setKind(sk);
			
			PropertyKind pk = PropertyKindImpl.getInstance(property.getResource());
			pk.getInstances().add(property.getResource());
			pk.getAttributes(property.getResource()).add(subject.getResource());
			pk.getValues(subject.getResource()).add(object.getResource());
			property.setKind(pk);

			ObjectKind ok = ObjectKindImpl.getInstance(object.getResource());
			ok.getInstances().add(object.getResource());
			ok.getAttributes(object.getResource()).add(property.getResource());
			ok.getValues(property.getResource()).add(subject.getResource());
			object.setKind(ok);
			
		}
	}

	public Set<Statement> performAggregation() {

		// Subjects
		fcalib.api.fca.Context<String, String> fcaContext = new FCAFormalContext<String, String>() {};
		for(SubjectKind kind : SubjectKinds.getInstance().getSubjectKinds(null, null, null, null)) {
			for(core.model.Resource inst : kind.getInstances()) {
				ObjectAPI<String,String> ob1 = new FCAObject<>(inst.getIRI());
				for(core.model.Resource attr : kind.getAttributes(inst)) {
					Attribute<String,String> atr1 = new FCAAttribute<>(attr.getIRI());
					ob1.addAttribute(attr.getIRI());
					atr1.addObject(inst.getIRI());
				}
				fcaContext.addObject(ob1);
			}
		}
		
		// TODO:
		// Merge Occurrences Kinds by FCA Concepts (objects / attributes).
		
		System.out.println("DONE FCA");
		
		OutputPrinter.printCrosstableToConsole(fcaContext);
		OutputPrinter.printConceptsToConsole(fcaContext);
		
		System.out.println("DONE PRINT");

        List<List<Attribute<String,String>>> closures = Computation.computeAllClosures(fcaContext);
        List<Concept<String,String>> concepts = Computation.computeAllConcepts(closures, fcaContext);
        for(Concept<String,String> concept : concepts) {
        	// System.out.println(concept.getExtent().stream().map(ObjectAPI::getObjectID).collect(Collectors.toList())+";");
            System.out.println(concept.getIntent().stream().map(Attribute::getAttributeID).collect(Collectors.toList())+"\n");
        }
		
		return Statements.getInstance().getStatements();
	}
	
}
