package com.sebxama.functional.util;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class Primes {

	private static Primes instance;
	public static Primes getInstance() {
		if(instance == null)
			instance = new Primes();
		return instance;
	}
	
	private Long current;
	
	protected Primes() {
		current = 2l;
	}
	
	public Long nextPrime(Long val) {
		BigInteger valbi = BigInteger.valueOf(val);
		this.current = valbi.nextProbablePrime().longValue();
		return this.current;
	}
	
	public List<Long> primeFactors(Long product) {
		long n = product;
		List<Long> factors = new ArrayList<Long>();
		for(long i = 2; i <= n / i; i++) {
			while(n % i == 0) {
				factors.add(i);
				n /= i;
			}
		}
		if(n > 1) {
			factors.add(n);
		}
		return factors;
	}

	public static void main(String... args) {
		System.out.println(Primes.getInstance().primeFactors(21l));
	}
	
}
