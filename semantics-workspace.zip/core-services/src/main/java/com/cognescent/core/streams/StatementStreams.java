package com.cognescent.core.streams;

import com.cognescent.core.model.IRI;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.Statement;

public class StatementStreams {

	private Statement statement;
	
	public StatementStreams(Statement statement) {
		this.statement = statement;
	}
	
	public Iterable<Kind> mapKinds(Iterable<IRI> match) {
		// TODO: Use zipWith(T1: Statement (inst), T2: IRIs function (Embeddings), Result: Kinds. 
		return null;
	}
	
	public Iterable<IRI> mapIRIs(Iterable<Kind> match) {
		// TODO:
		return null;
	}
	
}
