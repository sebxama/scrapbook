package com.sebxama.functional.model;

public class SubjectKind extends Kind {

	public SubjectKind() {
		
	}

	public SubjectKind(Kind src) {
		super(src);
	}
	
}
