package core.model;

public interface SubjectKind extends Context, Subject, Property, Object, Kind {
	
	public Subject getInstance();
	
	public Property getAttribute();
	
	public Object getValue();
	
}
