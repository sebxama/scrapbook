package com.cognescent.core.streams;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementObject;
import com.cognescent.core.model.StatementPredicate;

import reactor.core.publisher.Flux;

public class PredicatesStream {

	private static PredicatesStream instance;
	public static PredicatesStream getInstance() {
		if(instance == null)
			instance = new PredicatesStream();
		return instance;
	}
	
	private Set<StatementPredicate> predicates;
	
	protected PredicatesStream() {
		this.predicates = new HashSet<StatementPredicate>();
	}
	
	public void addPredicate(StatementPredicate predicate) {
		this.predicates.add(predicate);
	}
	
	public void removePredicate(StatementPredicate predicate) {
		this.predicates.remove(predicate);
	}
	
	public Flux<StatementPredicate> getStream() {
		return Flux.fromIterable(this.predicates);
	}
	
}
