package com.cognescent.core.fca;

public class FCACore {

	public void test() {
		fr.lirmm.fca4j.algo.AlgoUtilities a = null;
	}
}
