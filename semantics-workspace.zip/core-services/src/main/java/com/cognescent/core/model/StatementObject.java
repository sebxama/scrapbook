package com.cognescent.core.model;

public class StatementObject extends IRIStatementOccurrence {

}
