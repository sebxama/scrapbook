package core.model;

import java.util.HashSet;
import java.util.Set;

public class IRI {

	private String iri;
	private Set<Statement> occurrences;
	
	public IRI(String iri) {
		this.iri = iri;
		this.occurrences = new HashSet<Statement>();
	}
	
	public String toString() {
		return this.iri;
	}
	
	public int hashCode() {
		return this.iri.hashCode();
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof IRI)
			return obj.hashCode() == this.hashCode();
		return false;
	}
	
	public Set<Statement> getOccurrences() {
		return this.occurrences;
	}

}
