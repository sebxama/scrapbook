package com.sebxama.alignment.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.sebxama.alignment.service.AlignmentService;

@SpringBootTest
class SpringBootServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
