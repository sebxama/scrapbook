package core.model;

public interface SubjectKind extends Property, Object, Kind {
	
}
