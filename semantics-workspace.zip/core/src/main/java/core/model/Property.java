package core.model;

public interface Property extends Context {

}
