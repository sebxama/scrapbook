package com.sebxama.functional.model.objectmapper.serializer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.sebxama.functional.model.Predicate;

public class PredicateSerializer extends StdSerializer<Predicate> {
    
    public PredicateSerializer() {
        this(null);
    }
  
    public PredicateSerializer(Class<Predicate> t) {
        super(t);
    }

    @Override
    public void serialize(Predicate value, JsonGenerator jgen, SerializerProvider provider) 
    	throws IOException, JsonProcessingException {
    	
		jgen.writeStartObject();
		jgen.writeStringField("occurrenceUri", value.getOccurrenceURI().getValue());
		jgen.writeObjectField("uri", value.getURI());
		jgen.writeStringField("statement", value.getStatement().getURI().getValue());
		jgen.writeObjectField("kind", value.getKind());
		jgen.writeEndObject();
    }

}
