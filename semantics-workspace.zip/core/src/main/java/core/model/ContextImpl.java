package core.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

public class ContextImpl extends ResourceOccurrenceImpl implements Context {
	
	public ContextImpl(Resource iri) {
		super(iri);
	}
	
	@JsonBackReference
	public ContextKind getContextKind() {
		return this.getContextStatement().getContextKind();
	}
	
}
