package com.sebxama.functional.model;

public class ContextKind extends Kind {

	public ContextKind() {
		
	}
	
}
