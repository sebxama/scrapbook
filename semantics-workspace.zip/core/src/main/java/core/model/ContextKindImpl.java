package core.model;

public class ContextKindImpl extends KindImpl<Context, Property, Object> implements ContextKind {
	
	public ContextKindImpl(Resource iri) {
		super(iri);
	}
	
}
