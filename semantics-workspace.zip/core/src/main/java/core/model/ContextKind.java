package core.model;

public interface ContextKind extends Kind {

	public Context getInstance();
	
	public Property getAttribute();
	
	public Object getValue();
	
}
