package com.cognescent.core.model;

public class ObjectKind extends Kind<StatementObject, StatementPredicate, StatementSubject> {

	public ObjectKind() {
		
	}
	
	public ObjectKind(StatementObject instance, StatementPredicate attribute, StatementSubject value) {
		super(instance, attribute, value);
	}
	
}
