package com.sebxama.functional.model.objectmapper.deserializer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.node.IntNode;
import com.sebxama.functional.model.ContextKind;
import com.sebxama.functional.model.URI;
import com.sebxama.functional.model.Value;
import com.sebxama.functional.model.ValueKind;
import com.sebxama.functional.service.RegistryService;

public class ValueKindDeserializer extends StdDeserializer<ValueKind> { 

    public ValueKindDeserializer() { 
        this(null); 
    } 

    public ValueKindDeserializer(Class<?> vc) { 
        super(vc); 
    }

    @Override
    public ValueKind deserialize(JsonParser jp, DeserializationContext ctxt)
    	throws IOException, JsonProcessingException {
        
    	RegistryService registry = RegistryService.getInstance();
    	JsonNode node = jp.getCodec().readTree(jp);
        String srcStr = node.get("source").asText();
        
        ValueKind src = registry.getValueKind(srcStr);

        JsonParser parser = node.findValue("uri").traverse();
        parser.setCodec(jp.getCodec());
        URI uri = parser.readValueAs(URI.class);
        
        ValueKind kind = registry.getValueKind(uri);
        kind.setSource(src);
        
        parser = node.findValue("contextOccurrences").traverse();
        parser.setCodec(jp.getCodec());
        String[] arr = parser.readValueAs(String[].class);
        for(String c : arr)
        	kind.getContextOccurrences().add(registry.getContext(c));
        
        parser = node.findValue("subjectOccurrences").traverse();
        parser.setCodec(jp.getCodec());
        arr = parser.readValueAs(String[].class);
        for(String c : arr)
        	kind.getSubjectOccurrences().add(registry.getSubject(c));

        parser = node.findValue("predicateOccurrences").traverse();
        parser.setCodec(jp.getCodec());
        arr = parser.readValueAs(String[].class);
        for(String c : arr)
        	kind.getPredicateOccurrences().add(registry.getPredicate(c));

        parser = node.findValue("objectOccurrences").traverse();
        parser.setCodec(jp.getCodec());
        arr = parser.readValueAs(String[].class);
        for(String c : arr)
        	kind.getObjectOccurrences().add(registry.getValue(c));
        
        return kind;
    }
}
