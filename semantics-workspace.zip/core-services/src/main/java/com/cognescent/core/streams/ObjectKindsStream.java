package com.cognescent.core.streams;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.ContextKind;
import com.cognescent.core.model.IRI;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.ObjectKind;
import com.cognescent.core.model.PredicateKind;
import com.cognescent.core.model.Statement;
import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.SubjectKind;

import reactor.core.publisher.Flux;

public class ObjectKindsStream {

	private static ObjectKindsStream instance;
	public static ObjectKindsStream getInstance() {
		if(instance == null)
			instance = new ObjectKindsStream();
		return instance;
	}
	
	private Set<ObjectKind> kinds;
	
	protected ObjectKindsStream() {
		this.kinds = new HashSet<ObjectKind>();
	}
	
	public void addObjectKind(ObjectKind kind) {
		this.kinds.add(kind);
	}
	
	public void removeObjectKind(ObjectKind kind) {
		this.kinds.remove(kind);
	}
	
	public Flux<ObjectKind> getStream() {
		return Flux.fromIterable(this.kinds);
	}
	
//	public Iterable<Statement> mapStatements(Iterable<IRI> match) {
//		// TODO:
//		return null;
//	}
//	
//	public Iterable<IRI> mapIRIs(Iterable<Statement> match) {
//		// TODO:
//		return null;
//	}
	
}
