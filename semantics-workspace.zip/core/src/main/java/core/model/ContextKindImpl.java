package core.model;

import java.util.HashMap;
import java.util.Map;

public class ContextKindImpl extends ResourceImpl<ContextKind> implements ContextKind {

	private static Map<IRI, ContextKind> ctxs = new HashMap<IRI, ContextKind>();
	
	private Map<Statement, Context> instances;
	private Map<Statement, Property> attributes;
	private Map<Statement, Object> values;
	
	public ContextKindImpl(IRI iri) {
		super(iri);
		setResource(this);
		this.instances = new HashMap<Statement, Context>();
		this.attributes = new HashMap<Statement, Property>();
		this.values = new HashMap<Statement, Object>();
	}

	public Context getInstance(Statement ctx) {
		return instances.get(ctx);
	}

	public Property getAttribute(Statement ctx) {
		return attributes.get(ctx);
	}

	public Object getValue(Statement ctx) {
		return values.get(ctx);
	}

	public void setInstance(Statement stat, Context ctx) {
		this.instances.put(stat, ctx);
	}

	public void setAttribute(Statement stat, Property prop) {
		this.attributes.put(stat, prop);
	}

	public void setValue(Statement stat, Object val) {
		this.values.put(stat, val);
	}
	
	public static ContextKind getOrCreate(IRI iri) {
		ContextKind ret = ctxs.get(iri);
		if(ret == null) {
			ret = new ContextKindImpl(iri);
			ctxs.put(iri, ret);
		}
		return ret;
	}
	
}
