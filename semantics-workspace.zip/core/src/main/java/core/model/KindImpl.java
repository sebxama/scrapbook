package core.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class KindImpl extends ResourceOccurrenceImpl implements Kind {
	
	private Set<Resource> instances;
	private Map<Resource, Set<Resource>> attributes;
	private Map<Resource, Set<Resource>> values;
	
	public KindImpl(Resource iri) {
		super(iri);
		this.instances = new HashSet<>();
		this.attributes = new HashMap<>();
		this.values = new HashMap<>();
	}

	public Set<Resource> getInstances() {
		return instances;
	}

	public Set<Resource> getAttributes(Resource instance) {
		Set<Resource> ret = attributes.get(instance);
		if(ret == null) {
			ret = new HashSet<Resource>();
			attributes.put(instance, ret);
		}
		return ret;
	}

	public Set<Resource> getValues(Resource attribute) {
		Set<Resource> ret = values.get(attribute);
		if(ret == null) {
			ret = new HashSet<Resource>();
			values.put(attribute, ret);
		}
		return ret;
	}

	public String toString() {
		String ret = this.getClass().getCanonicalName() + " : " + this.getResource().toString();
		return ret;
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
