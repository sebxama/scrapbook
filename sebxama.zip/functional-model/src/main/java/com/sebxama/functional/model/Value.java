package com.sebxama.functional.model;

public class Value implements URIOccurrence {

	private URI uri;
	private Statement statement;
	private ValueKind kind;
	
	public Value(URI uri, Statement statement) {
		uri.getObjectOccurrences().add(this);
		this.uri = uri;
		this.statement = statement;
	}
	
	public URI getURI() {
		return this.uri;
	}
	
	public Statement getStatement() {
		return this.statement;
	}
	
	public void setKind(ValueKind kind) {
		kind.getURIOccurrences().add(this);
		this.kind = kind;
	}
	
	public ValueKind getKind() {
		return this.kind;
	}
	
}
