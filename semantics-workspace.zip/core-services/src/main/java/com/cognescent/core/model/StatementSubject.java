package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

public class StatementSubject extends IRIStatementOccurrence {

	private static Map<IRI, StatementSubject> subjects = new HashMap<IRI, StatementSubject>();
	
	public static StatementSubject get(IRI key) {
		StatementSubject subj = subjects.get(key);
		if(subj == null) {
			subj = new StatementSubject();
			subj.setIRI(key);
			subjects.put(key, subj);
		}
		return subj;
	}
	
}
