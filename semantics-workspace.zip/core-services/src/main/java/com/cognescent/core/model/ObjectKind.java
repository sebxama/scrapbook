package com.cognescent.core.model;

import com.cognescent.core.streams.ObjectKindsStream;

public class ObjectKind extends Kind<StatementObject, StatementPredicate, StatementSubject> {

	protected ObjectKind() {
		
	}
	
	public ObjectKind(StatementContext type, StatementObject instance, StatementPredicate attribute, StatementSubject value) {
		super(type, instance, attribute, value);
		ObjectKindsStream.getInstance().addObjectKind(this);
	}
	
}
