package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

/*
 * TODO: Kinds IRIStatementOccurrence / Context, IRIs
 */
public class Kinds {

	private static Kinds instance;
	public static Kinds getInstance() {
		if(instance == null)
			instance = new Kinds();
		return instance;
	}
	
	private Map<IRI, ContextKind> contextKinds;
	private Map<IRI, SubjectKind> subjectKinds;
	private Map<IRI, PredicateKind> predicateKinds;
	private Map<IRI, ObjectKind> objectKinds;

	protected Kinds() {
		contextKinds = new HashMap<IRI, ContextKind>();
		subjectKinds = new HashMap<IRI, SubjectKind>();
		predicateKinds = new HashMap<IRI, PredicateKind>();
		objectKinds = new HashMap<IRI, ObjectKind>();
	}
	
	public ContextKind getContextKind(IRI iri) {
		ContextKind ret = contextKinds.get(iri);
		if(ret == null) {
			ret = new ContextKind();
			ret.setIRI(iri);
			contextKinds.put(iri, ret);
		}
		return ret;
	}

	public SubjectKind getSubjectKind(IRI iri) {
		SubjectKind ret = subjectKinds.get(iri);
		if(ret == null) {
			ret = new SubjectKind();
			ret.setIRI(iri);
			subjectKinds.put(iri, ret);
		}
		return ret;
	}
	
	public PredicateKind getPredicateKind(IRI iri) {
		PredicateKind ret = predicateKinds.get(iri);
		if(ret == null) {
			ret = new PredicateKind();
			ret.setIRI(iri);
			predicateKinds.put(iri, ret);
		}
		return ret;
	}
	
	public ObjectKind getObjectKind(IRI iri) {
		ObjectKind ret = objectKinds.get(iri);
		if(ret == null) {
			ret = new ObjectKind();
			ret.setIRI(iri);
			objectKinds.put(iri, ret);
		}
		return ret;
	}
	
}
