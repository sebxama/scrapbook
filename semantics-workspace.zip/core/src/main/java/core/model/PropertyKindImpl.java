package core.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

public class PropertyKindImpl extends KindImpl<Property, Subject, Object> implements PropertyKind {
	
	public PropertyKindImpl(Resource iri) {
		super(iri);
	}
	
	@Override
	@JsonBackReference
	public PropertyKind getPropertyKind() {
		return this.getContextStatement().getPropertyKind();
	}

	@Override
	@JsonBackReference
	public ContextKind getContextKind() {
		return this.getContextStatement().getContextKind();
	}
	
	/**
	 * Relationship domain.
	 */
	@Override
	@JsonBackReference
	public SubjectKind getSubjectKind() {
		return this.getContextStatement().getSubjectKind();
	}

	/**
	 * Relationship range.
	 */
	@Override
	@JsonBackReference
	public ObjectKind getObjectKind() {
		return this.getContextStatement().getObjectKind();
	}
	
}
