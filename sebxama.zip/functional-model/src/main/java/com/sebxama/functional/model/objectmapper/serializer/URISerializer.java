package com.sebxama.functional.model.objectmapper.serializer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.sebxama.functional.model.URI;

public class URISerializer extends StdSerializer<URI> {
    
    public URISerializer() {
        this(null);
    }
  
    public URISerializer(Class<URI> t) {
        super(t);
    }

    @Override
    public void serialize(URI value, JsonGenerator jgen, SerializerProvider provider)
    	throws IOException, JsonProcessingException {
 
        jgen.writeStartObject();
        jgen.writeStringField("value", value.getValue());
        jgen.writeNumberField("primeID", value.getPrimeID());
        jgen.writeEndObject();
    }

}
