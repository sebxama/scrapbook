package core.model;

public interface Subject extends ResourceOccurrence {
	
}
