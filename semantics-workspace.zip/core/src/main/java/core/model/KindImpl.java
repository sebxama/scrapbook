package core.model;

public abstract class KindImpl<INST extends ResourceOccurrence, ATTR extends ResourceOccurrence, VAL extends ResourceOccurrence> extends ResourceOccurrenceImpl implements Kind {
	
	private INST instance;
	private ATTR attribute;
	private VAL value;
	
	public KindImpl(Resource iri) {
		super(iri);
	}

	public INST getInstance() {
		return this.instance;
	}

	public ATTR getAttribute() {
		return this.attribute;
	}

	public VAL getValue() {
		return this.value;
	}

	public void setInstance(INST res) {
		this.instance = res;
	}

	public void setAttribute(ATTR res) {
		this.attribute = res;
	}

	public void setValue(VAL res) {
		this.value = res;
	}

	public String toString() {
		String ret = this.getClass().getCanonicalName() + " : " + this.getResource().toString();
		return ret;
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
