package core.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ObjectKinds {

	private static ObjectKinds instance;
	public static ObjectKinds getInstance() {
		if(instance == null)
			instance = new ObjectKinds();
		return instance;
	}
	
	protected ObjectKinds() {
		
	}

	// TODO:
	public Set<ObjectKind> getObjectKinds(Context context, Object instance, Property attribute, Subject value) {
		Set<ObjectKind> ret = new HashSet<ObjectKind>();
		for(Statement stat : Statements.getInstance().getStatements(context.getResource(), value.getResource(), attribute.getResource(), instance.getResource()))
			ret.add(stat.getObjectKind());
		return ret;
	}

	/**
	 * FCA Concepts context lattice building. Kind Instance: Axis,
	 * Kind Attribute: FCA Context objects, Kind Value: FCA Context attributes.
	 * @return Kinds aggregated by distinct Objects Resource (IRI).
	 */
	public Map<Resource, Set<ObjectKind>> getObjectAggregatedKinds() {
		Map<Resource, Set<ObjectKind>> ret = new HashMap<Resource, Set<ObjectKind>>();
		for(Object obj : Objects.getInstance().getObjects()) {
			Set<ObjectKind> set = ret.get(obj.getResource());
			if(set == null)
				set = new HashSet<ObjectKind>();
			set.add(obj.getObjectKind());
			ret.put(obj.getResource(), set);
		}
		return ret;
	}

}
