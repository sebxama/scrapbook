package core.model;

public class PropertyKindImpl extends KindImpl<Property, Subject, Object> implements PropertyKind {
	
	public PropertyKindImpl(Resource iri) {
		super(iri);
	}
	
	public PropertyKind getPropertyKind() {
		return this.getContextStatement().getPropertyKind();
	}

	/**
	 * Relationship domain.
	 */
	@Override
	public SubjectKind getSubjectKind() {
		return this.getContextStatement().getSubjectKind();
	}

	/**
	 * Relationship range.
	 */
	@Override
	public ObjectKind getObjectKind() {
		return this.getContextStatement().getObjectKind();
	}
	
}
