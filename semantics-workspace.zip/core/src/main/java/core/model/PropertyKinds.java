package core.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class PropertyKinds {

	private static PropertyKinds instance;
	public static PropertyKinds getInstance() {
		if(instance == null)
			instance = new PropertyKinds();
		return instance;
	}
	
	protected PropertyKinds() {
		
	}

	// TODO:
	public Set<PropertyKind> getPropertyKinds(Context context, Property instance, Subject attribute, Object value) {
		Set<PropertyKind> ret = new HashSet<PropertyKind>();
		for(Statement stat : Statements.getInstance().getStatements(context.getIRI(), attribute.getIRI(), instance.getIRI(), value.getIRI())) {
			PropertyKindImpl sk = new PropertyKindImpl(stat.getContext().getIRI());
			sk.setInstance(stat.getProperty());
			sk.setAttribute(stat.getSubject());
			sk.setValue(stat.getObject());
			sk.setContextStatement(stat);
			ret.add(sk);
		}
		return ret;
	}
	
	// TODO: ContextKinds: Context instance, Property attribute, Object value.
	public Map<Context, PropertyKind> getAggregatedKinds() {
		Map<Context, PropertyKind> ret = new HashMap<Context, PropertyKind>();
		return ret;
	}

}
