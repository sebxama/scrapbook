package com.cognescent.core.model;

import com.cognescent.core.streams.ContextKindsStream;

public class ContextKind extends Kind<StatementContext, StatementSubject, StatementObject> {

	protected ContextKind() {
		
	}
	
	public ContextKind(StatementContext type, StatementContext instance, StatementSubject attribute, StatementObject value) {
		super(type, instance, attribute, value);
		ContextKindsStream.getInstance().addContextKind(this);
	}
	
}
