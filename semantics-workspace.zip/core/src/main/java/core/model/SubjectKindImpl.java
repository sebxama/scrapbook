package core.model;

import java.util.HashMap;
import java.util.Map;

public class SubjectKindImpl extends ResourceImpl<SubjectKind> implements SubjectKind {

	private static Map<IRI, SubjectKind> kinds = new HashMap<IRI, SubjectKind>();
	
	private Map<Statement, Subject> instances;
	private Map<Statement, Property> attributes;
	private Map<Statement, Object> values;
	
	protected SubjectKindImpl(IRI iri) {
		super(iri);
		setResource(this);
		this.instances = new HashMap<Statement, Subject>();
		this.attributes = new HashMap<Statement, Property>();
		this.values = new HashMap<Statement, Object>();
	}

	public Subject getInstance(Statement ctx) {
		return instances.get(ctx);
	}

	public Property getAttribute(Statement ctx) {
		return attributes.get(ctx);
	}

	public Object getValue(Statement ctx) {
		return values.get(ctx);
	}

	public void setInstance(Statement ctx, Subject subj) {
		this.instances.put(ctx, subj);
	}

	public void setAttribute(Statement ctx, Property prop) {
		this.attributes.put(ctx, prop);
	}

	public void setValue(Statement ctx, Object obj) {
		this.values.put(ctx, obj);
	}

	public static SubjectKind getOrCreate(IRI iri) {
		SubjectKind ret = kinds.get(iri);
		if(ret == null) {
			ret = new SubjectKindImpl(iri);
			kinds.put(iri, ret);
		}
		return ret;
	}

}
