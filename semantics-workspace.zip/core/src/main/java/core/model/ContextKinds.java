package core.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ContextKinds {

	private static ContextKinds instance;
	public static ContextKinds getInstance() {
		if(instance == null)
			instance = new ContextKinds();
		return instance;
	}
	
	protected ContextKinds() {
		
	}

	// TODO:
	public Set<ContextKind> getContextKinds(Context context, Context instance, Property attribute, Object value) {
		Set<ContextKind> ret = new HashSet<ContextKind>();
		for(Statement stat : Statements.getInstance().getStatements(context.getResource(), instance.getResource(), attribute.getResource(), value.getResource())) {
			ContextKindImpl ck = new ContextKindImpl(stat.getContext().getResource());
			ck.setInstance(stat.getContext());
			ck.setAttribute(stat.getProperty());
			ck.setValue(stat.getObject());
			ck.setContextStatement(stat);
			stat.setContextKind(ck);
			ret.add(ck);
		}
		return ret;
	}
	
	// TODO: ContextKinds: Context instance, Property attribute, Object value.
	public Map<Context, ContextKind> getAggregatedKinds() {
		Map<Context, ContextKind> ret = new HashMap<Context, ContextKind>();
		return ret;
	}

}
