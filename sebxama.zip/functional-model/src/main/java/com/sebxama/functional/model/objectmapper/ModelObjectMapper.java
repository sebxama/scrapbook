package com.sebxama.functional.model.objectmapper;

public class ModelObjectMapper {

}
