package com.cognescent.core.streams;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementObject;

import reactor.core.publisher.Flux;

public class ObjectsStream {

	private static ObjectsStream instance;
	public static ObjectsStream getInstance() {
		if(instance == null)
			instance = new ObjectsStream();
		return instance;
	}
	
	private Set<StatementObject> objects;
	
	protected ObjectsStream() {
		this.objects = new HashSet<StatementObject>();
	}
	
	public void addObject(StatementObject object) {
		this.objects.add(object);
	}

	public void removeObject(StatementObject object) {
		this.objects.remove(object);
	}
	
	public Flux<StatementObject> getStream() {
		return Flux.fromIterable(this.objects);
	}
	
}
