package core.model;

public class IRI {

	private String iri;
	
	public IRI(String iri) {
		this.iri = iri;
	}
	
	public String toString() {
		return this.iri;
	}
	
	public int hashCode() {
		return this.iri.hashCode();
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof IRI)
			return obj.hashCode() == this.hashCode();
		return false;
	}
	
}
