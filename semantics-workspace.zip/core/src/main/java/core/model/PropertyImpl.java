package core.model;

public class PropertyImpl extends ResourceOccurrenceImpl implements Property {
	
	private PropertyKind kind;
	
	public PropertyImpl(Resource iri) {
		super(iri);
	}
	
	public void setPropertyKind(PropertyKind kind) {
		this.kind = kind;
	}
	
	public PropertyKind getPropertyKind() {
		return this.kind;
	}
	
}
