package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

public class StatementContext extends IRIStatementOccurrence {

	private static Map<IRI, StatementContext> contexts = new HashMap<IRI, StatementContext>();

	protected StatementContext() {

	}
	
	public static StatementContext getByIRI(IRI key) {
		StatementContext ctx = contexts.get(key);
		if(ctx == null) {
			ctx = new StatementContext();
			ctx.setIRI(key);
			contexts.put(key, ctx);
		}
		return ctx;
	}

	public String toString() {
		return "{ \"className\": \""+this.getClass().getCanonicalName()+"\", \"IRI\" : \""+this.getIRI().getValue()+"\"}";
	}
	
	public int hashCode() {
		return (this.getClass().getCanonicalName() + ":" + this.getIRI().getValue()).hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}

}
