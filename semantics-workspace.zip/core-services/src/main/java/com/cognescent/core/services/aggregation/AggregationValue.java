package com.cognescent.core.services.aggregation;

import java.util.HashMap;
import java.util.Map;

import com.cognescent.core.model.IRI;
import com.cognescent.core.model.IRIStatementOccurrence;
import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementObject;
import com.cognescent.core.model.StatementPredicate;
import com.cognescent.core.model.StatementSubject;
import com.cognescent.core.services.aggregation.AggregationAttribute.ContextAggregationAttribute;
import com.cognescent.core.services.aggregation.AggregationAttribute.ObjectAggregationAttribute;
import com.cognescent.core.services.aggregation.AggregationAttribute.PredicateAggregationAttribute;
import com.cognescent.core.services.aggregation.AggregationAttribute.SubjectAggregationAttribute;
import com.cognescent.core.services.aggregation.AggregationInstance.SubjectAggregationInstance;

public abstract class AggregationValue<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {

	private static Map<IRI, AggregationValue.ContextAggregationValue> contextAggregations
		= new HashMap<IRI, AggregationValue.ContextAggregationValue>();
	private static Map<IRI, AggregationValue.SubjectAggregationValue> subjectAggregations
		= new HashMap<IRI, AggregationValue.SubjectAggregationValue>();
	private static Map<IRI, AggregationValue.PredicateAggregationValue> predicateAggregations
		= new HashMap<IRI, AggregationValue.PredicateAggregationValue>();
	private static Map<IRI, AggregationValue.ObjectAggregationValue> objectAggregations
		= new HashMap<IRI, AggregationValue.ObjectAggregationValue>();
	
	private IRI iri;
	private VAL value;
	private Map<AggregationAttribute<INST, ATTR, VAL>, AggregationInstance<INST, ATTR, VAL>> instances;
	
	public AggregationValue(VAL value) {
		this.iri = value.getIRI();
		this.value = value;
		this.instances = new HashMap<AggregationAttribute<INST, ATTR, VAL>, AggregationInstance<INST, ATTR, VAL>>();
	}
	
	public VAL getValue() {
		return this.value;
	}

	public IRI getIRI() {
		return iri;
	}

	public void setIRI(IRI iri) {
		this.iri = iri;
	}
	
	public Map<AggregationAttribute<INST, ATTR, VAL>, AggregationInstance<INST, ATTR, VAL>> getInstances() {
		return this.instances;
	}
	
	public static ContextAggregationValue getContextAggregationValue(StatementObject obj) {
		ContextAggregationValue ret = contextAggregations.get(obj.getIRI());
		if(ret == null) {
			ret = new ContextAggregationValue(obj);
			contextAggregations.put(obj.getIRI(), ret);
		}
		return ret;
	}

	public static SubjectAggregationValue getSubjectAggregationValue(StatementObject obj) {
		SubjectAggregationValue ret = subjectAggregations.get(obj.getIRI());
		if(ret == null) {
			ret = new SubjectAggregationValue(obj);
			subjectAggregations.put(obj.getIRI(), ret);
		}
		return ret;
	}

	public static PredicateAggregationValue getPredicateAggregationValue(StatementObject obj) {
		PredicateAggregationValue ret = predicateAggregations.get(obj.getIRI());
		if(ret == null) {
			ret = new PredicateAggregationValue(obj);
			predicateAggregations.put(obj.getIRI(), ret);
		}
		return ret;
	}

	public static ObjectAggregationValue getObjectAggregationValue(StatementSubject subj) {
		ObjectAggregationValue ret = objectAggregations.get(subj.getIRI());
		if(ret == null) {
			ret = new ObjectAggregationValue(subj);
			objectAggregations.put(subj.getIRI(), ret);
		}
		return ret;
	}
	
	static class ContextAggregationValue extends AggregationValue<StatementContext, StatementSubject, StatementObject> {
		
		public ContextAggregationValue(StatementObject obj) {
			super(obj);
			contextAggregations.put(obj.getIRI(), this);
		}
		
		public String toString() {
			return "{\"className\": \""+this.getClass().getCanonicalName()+"\", "+ 
						"\"IRI\" : \""+this.getIRI().getValue()+"\", " +
						"\"value\" : "+this.getValue().toString() + "}";
		}
		
		public int hashCode() {
			return (this.getClass().getCanonicalName() + ":" + this.getIRI().getValue()).hashCode();
		}
		
		public boolean equals(Object obj) {
			return this.hashCode() == obj.hashCode();
		}

		public static ContextAggregationValue getByIRI(IRI iri) {
			return getContextAggregationValue(StatementObject.getByIRI(iri));
		}

	}
	
	static class SubjectAggregationValue extends AggregationValue<StatementSubject, StatementPredicate, StatementObject> {

		public SubjectAggregationValue(StatementObject obj) {
			super(obj);
			subjectAggregations.put(obj.getIRI(), this);
		}
		
		public String toString() {
			return "{\"className\": \""+this.getClass().getCanonicalName()+"\", "+ 
						"\"IRI\" : \""+this.getIRI().getValue()+"\", " +
						"\"value\" : "+this.getValue().toString() + "}";
		}
		
		public int hashCode() {
			return (this.getClass().getCanonicalName() + ":" + this.getIRI().getValue()).hashCode();
		}
		
		public boolean equals(Object obj) {
			return this.hashCode() == obj.hashCode();
		}

		public static SubjectAggregationValue getByIRI(IRI iri) {
			return getSubjectAggregationValue(StatementObject.getByIRI(iri));
		}

	}
	
	static class PredicateAggregationValue extends AggregationValue<StatementPredicate, StatementSubject, StatementObject> {

		public PredicateAggregationValue(StatementObject obj) {
			super(obj);
			predicateAggregations.put(obj.getIRI(), this);
		}
		
		public String toString() {
			return "{\"className\": \""+this.getClass().getCanonicalName()+"\", "+ 
						"\"IRI\" : \""+this.getIRI().getValue()+"\", " +
						"\"value\" : "+this.getValue().toString() + "}";
		}
		
		public int hashCode() {
			return (this.getClass().getCanonicalName() + ":" + this.getIRI().getValue()).hashCode();
		}
		
		public boolean equals(Object obj) {
			return this.hashCode() == obj.hashCode();
		}

		public static PredicateAggregationValue getByIRI(IRI iri) {
			return getPredicateAggregationValue(StatementObject.getByIRI(iri));
		}
		
	}
	
	static class ObjectAggregationValue extends AggregationValue<StatementObject, StatementPredicate, StatementSubject> {

		public ObjectAggregationValue(StatementSubject val) {
			super(val);
			objectAggregations.put(val.getIRI(), this);
		}
		
		public String toString() {
			return "{\"className\": \""+this.getClass().getCanonicalName()+"\", "+ 
						"\"IRI\" : \""+this.getIRI().getValue()+"\", " +
						"\"value\" : "+this.getValue().toString() + "}";
		}
		
		public int hashCode() {
			return (this.getClass().getCanonicalName() + ":" + this.getIRI().getValue()).hashCode();
		}
		
		public boolean equals(Object obj) {
			return this.hashCode() == obj.hashCode();
		}

		public static ObjectAggregationValue getByIRI(IRI iri) {
			return getObjectAggregationValue(StatementSubject.getByIRI(iri));
		}
		
	}

}
