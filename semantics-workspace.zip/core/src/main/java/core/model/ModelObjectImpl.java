package core.model;

public class ModelObjectImpl extends ResourceOccurrenceImpl implements ModelObject {
	
	public ModelObjectImpl(Resource iri) {
		super(iri);
	}
	
}
