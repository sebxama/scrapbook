package com.cognescent.core.streams;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.ContextKind;
import com.cognescent.core.model.IRI;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.Statement;
import com.cognescent.core.model.StatementContext;

import reactor.core.publisher.Flux;

public class ContextKindsStream {

	private static ContextKindsStream instance;
	public static ContextKindsStream getInstance() {
		if(instance == null)
			instance = new ContextKindsStream();
		return instance;
	}
	
	private Set<ContextKind> kinds;
	
	protected ContextKindsStream() {
		this.kinds = new HashSet<ContextKind>();
	}
	
	public void addContextKind(ContextKind kind) {
		this.kinds.add(kind);
	}
	
	public void removeContextKind(ContextKind kind) {
		this.kinds.remove(kind);
	}
	
	public Flux<ContextKind> getStream() {
		return Flux.fromIterable(this.kinds);
	}
	
//	public Iterable<Statement> mapStatements(Iterable<IRI> match) {
//		// TODO:
//		return null;
//	}
//	
//	public Iterable<IRI> mapIRIs(Iterable<Statement> match) {
//		// TODO:
//		return null;
//	}
	
}
