package core.model;

public interface Statement extends Context, Subject, Property, Object {

	public Context getContext();
	
	public Subject getSubject();
	
	public Property getProperty();
	
	public Object getObject();
	
}
