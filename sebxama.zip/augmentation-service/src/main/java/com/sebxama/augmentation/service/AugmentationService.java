package com.sebxama.augmentation.service;

import org.eclipse.rdf4j.spring.support.RDF4JTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.sebxama.augmentation.repository.ServiceRepository;
import com.sebxama.functional.model.Statement;
import com.sebxama.functional.model.dto.Quad;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AugmentationService {

	@Autowired
	RDF4JTemplate rdfTemplate;
	
	@Autowired
	IndexService indexService;
	
	@Autowired
	NamingService namingService;
	
	@Autowired
	RegistryService registryService;

	@Autowired
	ServiceRepository serviceRepository;
	
	@Autowired
	WebClient.Builder wcBuilder;
	
	public Flux<Quad> perform(Flux<Quad> stream) {

		stream.flatMap(quad -> {
			System.out.println("Calling Aggregation...");
			Statement st = registryService.getStatement(quad);
			Statement[] sts = {st};
			Flux<Statement> src = Flux.fromArray(sts); 
			wcBuilder
			.build()
			.post()
			.uri("http://localhost:8383/aggregation/perform/")
			.body(src, Statement.class)
			.retrieve()
			.bodyToFlux(Statement.class)
			.flatMap(stat -> {
				System.out.println("Calling Alignment...");
				wcBuilder
				.build()
				.post()
				.uri("http://localhost:8484/alignment/perform/")
				.body(stat, Statement.class)
				.retrieve()
				.bodyToFlux(Statement.class)
				.flatMap(stat2 -> {
					System.out.println("Calling Activation...");
					wcBuilder
					.build()
					.post()
					.uri("http://localhost:8585/activation/perform/")
					.body(stat2, Statement.class)
					.retrieve()
					.bodyToFlux(Statement.class)
					.flatMap(stat3 -> {
						System.out.println("Statement (Activation): "+stat3);
						return Mono.just(stat3);
					}).subscribe();	
					return Mono.just(stat2);
				}).subscribe();
				return Mono.just(stat);
			}).subscribe();
			return Mono.just(src);
		}).subscribe();
		
		return stream;
	}
	
}
