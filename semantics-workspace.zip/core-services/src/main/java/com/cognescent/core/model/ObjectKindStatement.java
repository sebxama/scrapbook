package com.cognescent.core.model;

import com.cognescent.core.streams.ContextKindsStream;

public class ObjectKindStatement extends KindStatement<StatementObject, StatementPredicate, StatementSubject> {
	
	public ObjectKindStatement(Kind<StatementObject, StatementPredicate, StatementSubject> kind, StatementObject instance, StatementPredicate attribute, StatementSubject value) {
		super(kind, instance, attribute, value);
		kind.addStatement(this);
	}

}
