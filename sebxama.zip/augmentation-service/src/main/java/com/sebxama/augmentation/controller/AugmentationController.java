package com.sebxama.augmentation.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sebxama.augmentation.service.AugmentationService;
import com.sebxama.functional.model.Statement;
import com.sebxama.functional.model.dto.Quad;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/augmentation")
public class AugmentationController {

	@Autowired
	AugmentationService augmentationService;
	
	@GetMapping("/ping")
	@ResponseStatus(HttpStatus.OK)
	public Mono<String> ping() {
		return Mono.just("OK");
	}

	@PostMapping("/perform")
	public Mono<Quad> perform(Quad quad) {
		return augmentationService.perform(quad);
	}
	
	@GetMapping("/testQuads")
	@ResponseStatus(HttpStatus.OK)
	public Mono<Quad> testQuads() {
		Quad quad1 = new Quad("http://example.org/statement", "http://example.org/context", "http://example.org/subject", "http://example.org/predicate", "http://example.org/object");
		return augmentationService.perform(quad1);
	}

}
