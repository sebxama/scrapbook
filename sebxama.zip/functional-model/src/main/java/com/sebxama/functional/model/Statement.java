package com.sebxama.functional.model;

public class Statement {

	private URI uri;
	private Context context;
	private Subject subject;
	private Predicate predicate;
	private Value object;
	
	public Statement(URI context, URI subject, URI predicate, URI object) {
		this.context = new Context(context, this);
		this.subject = new Subject(subject, this);
		this.predicate = new Predicate(predicate, this);
		this.object = new Value(object, this);
	}

	public URI getURI() {
		return this.uri;
	}
	
	public void setURI(URI uri) {
		this.uri = uri;
	}
	
	public Context getContext() {
		return context;
	}

	public Subject getSubject() {
		return subject;
	}

	public Predicate getPredicate() {
		return predicate;
	}

	public Value getValue() {
		return object;
	}
	
}
