package com.cognescent.core.model;

public class ContextKind extends Kind<StatementContext, StatementSubject, StatementObject> {

	public ContextKind() {
		
	}
	
	public ContextKind(StatementContext instance, StatementSubject attribute, StatementObject value) {
		super(instance, attribute, value);
	}
	
}
