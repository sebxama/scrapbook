/*
BSD 3-Clause License

Copyright (c) 2022 LIRMM
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

   * Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the
distribution.
   * Neither the name of Google Inc. nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package fr.lirmm.fca4j.algo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveTask;
import java.util.logging.Level;
import java.util.logging.Logger;

import fr.lirmm.fca4j.core.IBinaryContext;
import fr.lirmm.fca4j.core.Implication;
import fr.lirmm.fca4j.iset.ISet;
import fr.lirmm.fca4j.iset.ISetFactory;
import fr.lirmm.fca4j.util.Chrono;

/**
 * The Class ClosureDirectWithForkJoinPool.
 *
 * @author agutierr
 */
public class ClosureDirectWithForkJoinPool implements ClosureStrategy {
	private MODE computeIntentMODE,computeExtentMODE;
    private static final int DEFAULT_THRESHOLD = 50;
    protected IBinaryContext matrix;
    protected ISetFactory factory;
    protected int threshold=DEFAULT_THRESHOLD;

    /**
     * Instantiates a new closure direct with fork join pool.
     *
     * @param matrix the matrix
     */
    public ClosureDirectWithForkJoinPool(IBinaryContext matrix) {
        this.matrix = matrix;
        this.factory = matrix.getFactory();
    }
    
    /**
     * Instantiates a new closure direct with fork join pool.
     *
     * @param matrix the matrix
     * @param threshold the threshold
     */
    public ClosureDirectWithForkJoinPool(IBinaryContext matrix,int threshold) {
        this.matrix = matrix;
        this.factory = matrix.getFactory();
        this.threshold=threshold;
    }

    /**
     * Closure.
     *
     * @param fermeture the fermeture
     * @param attrSet the attr set
     * @param lastAttrSet the last attr set
     * @param lastExtent the last extent
     * @return the i set
     */
    @Override
    public ISet closure(ISet fermeture, ISet attrSet,ISet lastAttrSet,ISet lastExtent) {
        ISet extent = computeExtent(attrSet);
        fermeture.addAll(attrSet);
        ISet intent = computeIntent(extent);
        fermeture.addAll(intent);
        return extent;
    }

    /**
     * Compute intent.
     *
     * @param objects the objects
     * @return the i set
     */
    public ISet computeIntent(ISet objects) {
        ComputeTask2 myRecursiveTask;
            myRecursiveTask = new ComputeTask2(objects,0, matrix.getAttributeCount(),false,MODE.CollectWithContainsAll);
        return ForkJoinPool.commonPool().invoke(myRecursiveTask);
    }
    
    /**
     * Compute extent.
     *
     * @param attributes the attributes
     * @return the i set
     */
    public ISet computeExtent(ISet attributes) {
         ComputeTask2 myRecursiveTask;
        if (matrix.getObjectCount() < attributes.cardinality()) 
            myRecursiveTask = new ComputeTask2(attributes,0, matrix.getObjectCount(),true,MODE.CollectWithContainsAll);
        else
            myRecursiveTask = new ComputeTask2(attributes,0, matrix.getAttributeCount(),true,MODE.BuiltWithIntersection);
        return ForkJoinPool.commonPool().invoke(myRecursiveTask);
    }

    /**
     * Inits the.
     *
     * @param chrono the chrono
     */
    @Override
    public void init(Chrono chrono) {
    }

    /**
     * Name.
     *
     * @return the string
     */
    @Override
    public String name() {
        return "ForkJoinPool Parallelism: "+ ForkJoinPool.commonPool().getParallelism();
    }

    /**
     * Notify.
     *
     * @param implication the implication
     */
    @Override
    public void notify(Implication implication) {
    }
	
	/**
	 * Threshold.
	 *
	 * @return the int
	 */
	@Override
	public int threshold() {
		return threshold;
	}


    private class ComputeTask2  extends RecursiveTask<ISet> {
        protected final int beg;
        protected final int end;
        protected final ISet elements;
        protected MODE mode;
        protected boolean forExtent;

        public ComputeTask2(ISet elements, int beg, int end,boolean forExtent,MODE mode) {
            this.beg = beg;
            this.end = end;
            this.elements = elements;
            this.mode=mode;
            this.forExtent=forExtent;
        }

        ISet computeByIntersection() {
            int size = forExtent ? matrix.getObjectCount() : matrix.getAttributeCount();
            ISet set = factory.createSet(size);
            set.fill(size);
            if (end - beg > threshold) {
                Collection<ComputeTask2> results = ForkJoinTask.invokeAll(createSubtasks());
                try {
                    for (ComputeTask2 task : results) {
                        set.retainAll(task.get());
                    }
                } catch (Exception ex) {
                    Logger.getLogger(ClosureDirectWithForkJoinPool.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                for (int i = beg; i < end; i++) {
                    if (elements.contains(i)) {
                        if (forExtent) {
                            set.retainAll(matrix.getExtent(i));
                        } else {
                            set.retainAll(matrix.getIntent(i));
                        }
                    }
                }
            }
            return set;
        }

        ISet computeByUnion() {
            int size = forExtent ? matrix.getObjectCount() : matrix.getAttributeCount();
            ISet set = factory.createSet(size);
            if (end - beg > threshold) {
                Collection<ComputeTask2> results = ForkJoinTask.invokeAll(createSubtasks());
                try {
                    for (ComputeTask2 task : results) {
                        set.addAll(task.get());
                    }
                } catch (Exception ex) {
                    Logger.getLogger(ClosureDirectWithForkJoinPool.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                for (int i = beg; i < end; i++) {
                    if (forExtent) {
                        if (matrix.getIntent(i).containsAll(elements)) {
                            set.add(i);
                        }
                    } else {
                        if (matrix.getExtent(i).containsAll(elements)) {
                            set.add(i);
                        }
                    }
                }
            }
            return set;

        }
        Collection<ComputeTask2> createSubtasks() {
            List<ComputeTask2> dividedTasks = new ArrayList<>();
            dividedTasks.add(new ComputeTask2(elements, beg, (beg + end) / 2,forExtent,mode));
            dividedTasks.add(new ComputeTask2(elements, (beg + end) / 2, end,forExtent,mode));
            return dividedTasks;
        }

        @Override
        protected ISet compute() {            
           switch(mode){
               case CollectWithContainsAll:
                   return computeByUnion();
               case BuiltWithIntersection:
                   return computeByIntersection();
           }
           return null;
        }
    }


    /**
     * The Enum MODE.
     */
    enum MODE {
        CollectWithContainsAll, BuiltWithIntersection
    };

	/**
	 * Sets the context.
	 *
	 * @param ctx the new context
	 */
	@Override
	public void setContext(IBinaryContext ctx) {
		matrix=ctx;
		
	}
	
	/**
	 * Shutdown.
	 */
	@Override
	public void shutdown() {
		
	}
}
