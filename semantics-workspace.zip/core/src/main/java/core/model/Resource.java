package core.model;

import java.util.Set;

public interface Resource {

	public IRI getIRI();
	
}
