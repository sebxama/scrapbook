package com.sebxama.functional.model;

import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sebxama.functional.model.objectmapper.deserializer.ValueDeserializer;
import com.sebxama.functional.model.objectmapper.serializer.ValueSerializer;

@JsonDeserialize(using = ValueDeserializer.class)
@JsonSerialize(using = ValueSerializer.class)
public class Value implements URIOccurrence {

	private URI occurrenceURI;
	private URI uri;
	private Statement statement;
	private ValueKind kind;
	private Set<Property> properties;
	
	public Value() {
		this.properties = new HashSet<Property>();
	}

	public Set<Property> getProperties() {
		return this.properties;
	}
	
	public URI getOccurrenceURI() {
		return this.occurrenceURI;
	}
	
	public void setOccurrenceURI(URI uri) {
		this.occurrenceURI = uri;
	}
	
	public URI getURI() {
		return this.uri;
	}
	
	public void setURI(URI uri) {
		uri.getObjectOccurrences().add(this);
		this.uri = uri;
	}
	
	public Statement getStatement() {
		return this.statement;
	}
	
	public void setStatement(Statement stat) {
		this.statement = stat;
	}

	public ValueKind getKind() {
		return this.kind;
	}
	
	public void setKind(ValueKind kind) {
		kind.getObjectOccurrences().add(this);
		kind.getURI().getObjectOccurrences().add(this);
		this.kind = kind;
	}
	
	public String toString() {
		return "Value; URI: " + this.uri; 
	}
	
}
