package com.sebxama.functional.model;

import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sebxama.functional.model.objectmapper.deserializer.PredicateDeserializer;
import com.sebxama.functional.model.objectmapper.serializer.PredicateSerializer;

@JsonDeserialize(using = PredicateDeserializer.class)
@JsonSerialize(using = PredicateSerializer.class)
public class Predicate implements URIOccurrence {
	
	private URI occurrenceURI;
	private URI uri;
	private Statement statement;
	private PredicateKind kind;
	private Set<Property> properties;
	
	public Predicate() {
		this.properties = new HashSet<Property>();
	}

	public Set<Property> getProperties() {
		return this.properties;
	}
	
	public URI getOccurrenceURI() {
		return this.occurrenceURI;
	}
	
	public void setOccurrenceURI(URI uri) {
		this.occurrenceURI = uri;
	}
	
	public URI getURI() {
		return this.uri;
	}
	
	public void setURI(URI uri) {
		uri.getPredicateOccurrences().add(this);
		this.uri = uri;
	}
	
	public Statement getStatement() {
		return this.statement;
	}
	
	public void setStatement(Statement stat) {
		this.statement = stat;
	}

	public PredicateKind getKind() {
		return this.kind;
	}
	
	public void setKind(PredicateKind kind) {
		kind.getPredicateOccurrences().add(this);
		kind.getURI().getPredicateOccurrences().add(this);
		this.kind = kind;
	}

	public String toString() {
		return "Predicate; URI: " + this.uri; 
	}

}
