package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

import com.cognescent.core.streams.SubjectsStream;

public class StatementSubject extends IRIStatementOccurrence {

	private static Map<IRI, StatementSubject> subjects = new HashMap<IRI, StatementSubject>();
	
	protected StatementSubject() {
		SubjectsStream.getInstance().addSubject(this);
	}
	
	public static StatementSubject get(IRI key) {
		StatementSubject subj = subjects.get(key);
		if(subj == null) {
			subj = new StatementSubject();
			subj.setIRI(key);
			subjects.put(key, subj);
		}
		return subj;
	}
	
}
