package com.sebxama.functional.model.objectmapper.serializer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.sebxama.functional.model.ValueKind;

public class ValueKindSerializer extends StdSerializer<ValueKind> {
    
    public ValueKindSerializer() {
        this(null);
    }
  
    public ValueKindSerializer(Class<ValueKind> t) {
        super(t);
    }

    @Override
    public void serialize(
    		ValueKind value, JsonGenerator jgen, SerializerProvider provider) 
      throws IOException, JsonProcessingException{
 
        jgen.writeStartObject();
        jgen.writeNumberField("id", 1);
        jgen.writeStringField("itemName", "");
        jgen.writeNumberField("owner", 1);
        jgen.writeEndObject();
    }

}
