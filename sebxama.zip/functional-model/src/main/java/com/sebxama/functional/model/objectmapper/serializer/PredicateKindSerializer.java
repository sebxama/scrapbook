package com.sebxama.functional.model.objectmapper.serializer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.sebxama.functional.model.PredicateKind;

public class PredicateKindSerializer extends StdSerializer<PredicateKind> {
    
    public PredicateKindSerializer() {
        this(null);
    }
  
    public PredicateKindSerializer(Class<PredicateKind> t) {
        super(t);
    }

    @Override
    public void serialize(PredicateKind value, JsonGenerator jgen, SerializerProvider provider)
    	throws IOException, JsonProcessingException {
 
        jgen.writeStartObject();
        jgen.writeStringField("source", value.getSource().getURI().getValue());
        jgen.writeObjectField("uri", value.getURI());
        jgen.writeEndObject();
    }

}
