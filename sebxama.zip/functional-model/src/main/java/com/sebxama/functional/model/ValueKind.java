package com.sebxama.functional.model;

public class ValueKind extends Kind {

	public ValueKind(String uri) {
		super(uri);
	}
	
}
