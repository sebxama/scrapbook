package core.model;

public class SubjectKindImpl extends KindImpl<Subject, Property, Object> implements SubjectKind {

	public SubjectKindImpl(Resource iri) {
		super(iri);
	}
	
	public SubjectKind getSubjectKind() {
		return this.getContextStatement().getSubjectKind();
	}

	/**
	 * Relationship domain.
	 */
	@Override
	public PropertyKind getPropertyKind() {
		return this.getContextStatement().getPropertyKind();
	}

	/**
	 * Relationship range.
	 */
	@Override
	public ObjectKind getObjectKind() {
		return this.getContextStatement().getObjectKind();
	}

}
