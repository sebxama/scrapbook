package com.cognescent.core.model;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.cognescent.core.streams.IRIsStream;

public class IRI {

	private static Map<String, IRI> iris = new HashMap<String, IRI>();
	
	private String value;
	private BigInteger embedding;
	private Set<IRIStatementOccurrence> occurrences;
	
	public IRI() {
		this.occurrences = new HashSet<IRIStatementOccurrence>();
		IRIsStream.getInstance().addIRI(this);
	}
	
	public IRI(String value) {
		this();
		this.value = value;
	}

	public static IRI get(String value) {
		IRI iri = iris.get(value);
		if(iri == null) {
			iri = new IRI(value);
			iris.put(value, iri);
		}
		return iri;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return this.value;
	}
	
	public void setEmbedding(BigInteger embedding) {
		this.embedding = embedding;
	}
	
	public BigInteger getEmbedding() {
		return this.embedding;
	}
	
	public void setOccurrences(Set<IRIStatementOccurrence> set) {
		this.occurrences = set;
	}
	
	public Set<IRIStatementOccurrence> getOccurrences() {
		return this.occurrences;
	}
	
}
