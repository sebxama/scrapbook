package core.model;

/**
 * Aggregated Kinds Statements. Reification.
 *
 */
public class SubjectKindStatement extends ResourceOccurrenceImpl implements Statement {
	
	private SubjectKind context;
	private SubjectKind subject;
	private PropertyKind property;
	private ObjectKind object;
	
	protected SubjectKindStatement(Resource iri) {
		super(iri);
	}
	
	/**
	 * Super Kind
	 */
	@Override
	public SubjectKind getContext() {
		return context;
	}

	/**
	 * Kind
	 */
	@Override
	public SubjectKind getSubject() {
		return subject;
	}

	/**
	 * Aggregated Domain
	 */
	@Override
	public PropertyKind getProperty() {
		return property;
	}

	/**
	 * Aggregated Range
	 */
	@Override
	public ObjectKind getObject() {
		return object;
	}

	public void setContext(SubjectKind context) {
		this.context = context;
	}

	public void setSubject(SubjectKind subject) {
		this.subject = subject;
	}

	public void setProperty(PropertyKind property) {
		this.property = property;
	}

	public void setObject(ObjectKind object) {
		this.object = object;
	}

	@Override
	public ContextKind getContextKind() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SubjectKind getSubjectKind() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PropertyKind getPropertyKind() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ObjectKind getObjectKind() {
		// TODO Auto-generated method stub
		return null;
	}

}
