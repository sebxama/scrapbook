package core.model;

import java.util.HashMap;
import java.util.Map;

public class SubjectImpl extends ResourceImpl<Subject> implements Subject {

	private static Map<IRI, Subject> subjs = new HashMap<IRI, Subject>();
	
	public SubjectImpl(IRI iri) {
		super(iri);
		setResource(this);
	}
	
	public static Subject getOrCreate(IRI iri) {
		Subject ret = subjs.get(iri);
		if(ret == null) {
			ret = new SubjectImpl(iri);
			subjs.put(iri, ret);
		}
		return ret;
	}

}
