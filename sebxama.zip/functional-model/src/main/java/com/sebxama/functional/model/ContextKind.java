package com.sebxama.functional.model;

public class ContextKind extends Kind {

	public ContextKind() {
		
	}
	
	public ContextKind(Kind src) {
		super(src);
	}

}
