package com.sebxama.augmentation.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

import org.eclipse.rdf4j.spring.support.RDF4JTemplate;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.kafka.core.reactive.ReactiveKafkaProducerTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClient.UriSpec;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sebxama.augmentation.repository.ServiceRepository;
import com.sebxama.functional.model.Context;
import com.sebxama.functional.model.ContextKind;
import com.sebxama.functional.model.Kind;
import com.sebxama.functional.model.Predicate;
import com.sebxama.functional.model.PredicateKind;
import com.sebxama.functional.model.Statement;
import com.sebxama.functional.model.Subject;
import com.sebxama.functional.model.SubjectKind;
import com.sebxama.functional.model.URI;
import com.sebxama.functional.model.Value;
import com.sebxama.functional.model.ValueKind;
import com.sebxama.functional.model.dto.Quad;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class RegistryService {

	@Autowired
	RDF4JTemplate rdfTemplate;
	
	@Autowired
	PrimesIDService idsService;
	
	@Autowired
	ServiceRepository serviceRepository;
	
	private Map<String, URI> URIs;
	private Map<URI, Statement> statements;
	
	public RegistryService() {
		this.URIs = new HashMap<String, URI>();
		this.statements = new HashMap<URI, Statement>();
	}
	
	public URI getURI(String value) {
		URI ret = URIs.get(value);
		if(ret == null) {
			ret = new URI(value);
			ret.setPrimeID(idsService.getURIPrimeID(value));
			URIs.put(value, ret);
		}
		return ret;
	}

	public Set<URI> getURIs() {
		Set<URI> ret = new HashSet<URI>(URIs.values());
		return ret;
	}
	
	public Statement getStatement(Quad input) {
		URI context = getURI(input.getContext());
		URI subject = getURI(input.getSubject());
		URI predicate = getURI(input.getPredicate());
		URI object = getURI(input.getObject());
		URI id = getURI("urn:statement:"+context.getPrimeID()+":"+subject.getPrimeID()+":"+predicate.getPrimeID()+":"+object.getPrimeID());
		Statement ret = statements.get(id);
		if(ret == null) {
			ret = new Statement();
			ret.setURI(id);
			Context ctx = new Context();
			ctx.setURI(context);
			ctx.setStatement(ret);
			ret.setContext(ctx);
			Subject subj = new Subject();
			subj.setURI(subject);
			subj.setStatement(ret);
			ret.setSubject(subj);
			Predicate pred = new Predicate();
			pred.setURI(predicate);
			pred.setStatement(ret);
			ret.setPredicate(pred);
			Value val = new Value();
			val.setURI(object);
			val.setStatement(ret);
			ret.setValue(val);
			statements.put(id, ret);
		}
		return ret;		
	}

	public Set<Statement> getStatements() {
		Set<Statement> ret = new HashSet<Statement>(statements.values());
		return ret;
	}

	public void putStatement(Statement stat) {
		this.statements.put(stat.getURI(), stat);
	}
	
	public Statement getStatement(URI uri) {
		return this.statements.get(uri);
	}

}
