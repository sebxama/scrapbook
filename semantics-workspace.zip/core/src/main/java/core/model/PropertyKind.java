package core.model;

public interface PropertyKind extends Subject, Object, Kind {

	public Property getInstance();
	
	public Subject getAttribute();
	
	public Object getValue();
	
}
