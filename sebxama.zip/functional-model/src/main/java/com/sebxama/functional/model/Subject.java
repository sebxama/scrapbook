package com.sebxama.functional.model;

public class Subject {

	private URI uri;
	private Statement statement;
	private SubjectKind kind;
	
	public Subject(URI uri, Statement statement) {
		uri.getSubjectOccurrences().add(statement);
		this.uri = uri;
		this.statement = statement;
	}
	
	public URI getURI() {
		return this.uri;
	}
	
	public Statement getStatement() {
		return this.statement;
	}
	
	public void setKind(SubjectKind kind) {
		kind.getOccurrences().add(this.uri);
		kind.getSubjectOccurrences().add(this.statement);
		this.kind = kind;
	}
	
	public SubjectKind getKind() {
		return this.kind;
	}
	
}
