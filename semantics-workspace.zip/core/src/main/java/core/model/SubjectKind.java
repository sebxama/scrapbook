package core.model;

public interface SubjectKind extends Property, Object, Kind {
	
	public Subject getInstance();
	
	public Property getAttribute();
	
	public Object getValue();
	
}
