package com.sebxama.functional.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sebxama.functional.model.objectmapper.deserializer.PredicateKindDeserializer;
import com.sebxama.functional.model.objectmapper.serializer.PredicateKindSerializer;

@JsonDeserialize(using = PredicateKindDeserializer.class)
@JsonSerialize(using = PredicateKindSerializer.class)
public class PredicateKind extends Kind {

	public PredicateKind() {
		
	}
	
	public PredicateKind(Kind src) {
		super(src);
	}

	@Override
	@SuppressWarnings("unchecked")
	public Set<Subject> getAttributes() {
		Set<Subject> ret = new HashSet<Subject>();
		for(Predicate pred : super.getPredicateOccurrences()) {
			ret.add(pred.getStatement().getSubject());
		}
		return ret;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Map<Subject, Set<Value>> getAttributeValues() {
		Map<Subject, Set<Value>> ret = new HashMap<Subject, Set<Value>>();
		Set<Subject> subjs = getAttributes();
		for(Subject subj : subjs) {
			Set<Value> vals = new HashSet<Value>();
			for(Subject occur : subj.getURI().getSubjectOccurrences()) {
				vals.add(occur.getStatement().getValue());
			}
			ret.put(subj, vals);
		}
		return ret;
	}
	
}
