package com.sebxama.functional.model;

import java.util.HashSet;
import java.util.Set;

public class URI {

	private String value;
	private Set<Statement> contextOccurrences;
	private Set<Statement> subjectOccurrences;
	private Set<Statement> predicateOccurrences;
	private Set<Statement> objectOccurrences;
	
	public URI(String value) {
		this.value = value;
		this.contextOccurrences = new HashSet<Statement>();
		this.subjectOccurrences = new HashSet<Statement>();
		this.predicateOccurrences = new HashSet<Statement>();
		this.objectOccurrences = new HashSet<Statement>();
	}
	
	public String getValue() {
		return this.value;
	}
	
	public Set<Statement> getContextOccurrences() {
		return this.contextOccurrences;
	}

	public Set<Statement> getSubjectOccurrences() {
		return this.subjectOccurrences;
	}
	
	public Set<Statement> getPredicateOccurrences() {
		return this.predicateOccurrences;
	}
	
	public Set<Statement> getObjectOccurrences() {
		return this.objectOccurrences;
	}
	
	@Override
	public String toString() {
		return this.value;
	}
	
	@Override
	public int hashCode() {
		return this.value.hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof URI)
			if(obj.hashCode() == this.hashCode())
				return true;
		return false;
	}
	
}
