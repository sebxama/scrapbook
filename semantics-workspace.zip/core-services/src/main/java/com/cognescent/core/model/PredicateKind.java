package com.cognescent.core.model;

import com.cognescent.core.streams.PredicateKindsStream;

public class PredicateKind extends Kind<StatementPredicate, StatementSubject, StatementObject> {

	protected PredicateKind() {
		
	}
	
	public PredicateKind(StatementContext type, StatementPredicate instance, StatementSubject attribute, StatementObject value) {
		super(type, instance, attribute, value);
		PredicateKindsStream.getInstance().addPredicateKind(this);
	}
	
}
