package com.cognescent.core.model;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.streams.ContextKindsStream;

public class ContextKind extends Kind<StatementContext, StatementSubject, StatementObject> {

	protected ContextKind() {
		ContextKindsStream.getInstance().addContextKind(this);		
	}

}
