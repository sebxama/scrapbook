package com.cognescent.core.services.aggregation;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.IRIStatementOccurrence;
import com.cognescent.core.model.Kind;

public class AggregationInstance<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {

	private INST instance;
	private Set<AggregationAttribute<INST, ATTR, VAL>> attributes;
	
	public AggregationInstance(INST instance) {
		this.instance = instance;
		this.attributes = new HashSet<AggregationAttribute<INST, ATTR, VAL>>();
	}
	
	public INST getInstance() {
		return this.instance;
	}
	
	public Set<AggregationAttribute<INST, ATTR, VAL>> getAggregationAttributes() {
		return this.attributes;
	}
	
}
