package core.activation;

import java.util.Set;

import org.springframework.stereotype.Service;

import core.model.KindStatement;

@Service
public class ActivationService {

	public Set<KindStatement> performSubjectKindsActivation(Set<KindStatement> stats) {
		// TODO
		return null;
	}
	
}
