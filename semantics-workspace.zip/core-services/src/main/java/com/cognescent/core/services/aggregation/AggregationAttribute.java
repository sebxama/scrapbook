package com.cognescent.core.services.aggregation;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.IRIStatementOccurrence;

public class AggregationAttribute<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {

	private ATTR attribute;
	private Set<AggregationValue<INST, ATTR, VAL>> values;
	
	public AggregationAttribute(ATTR attribute) {
		this.attribute = attribute;
		this.values = new HashSet<AggregationValue<INST, ATTR, VAL>>();
	}
	
	public Set<AggregationValue<INST, ATTR, VAL>> getAggregationValues() {
		return this.values;
	}
	
	public ATTR getAttribute() {
		return this.attribute;
	}
	
}
