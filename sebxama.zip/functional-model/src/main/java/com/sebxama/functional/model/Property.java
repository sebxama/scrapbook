package com.sebxama.functional.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sebxama.functional.model.objectmapper.deserializer.PropertyDeserializer;
import com.sebxama.functional.model.objectmapper.serializer.PropertySerializer;

@JsonDeserialize(using = PropertyDeserializer.class)
@JsonSerialize(using = PropertySerializer.class)
public class Property {

	private URIOccurrence occurrence;
	private URI attribute;
	private URI value;
	
	public Property() {
		
	}

	public URIOccurrence getURIOccurrence() {
		return occurrence;
	}

	public void setURIOccurrence(URIOccurrence occurrence) {
		this.occurrence = occurrence;
	}

	public URI getAttribute() {
		return attribute;
	}

	public void setAttribute(URI attribute) {
		this.attribute = attribute;
	}

	public URI getValue() {
		return value;
	}

	public void setValue(URI value) {
		this.value = value;
	}
	
}
