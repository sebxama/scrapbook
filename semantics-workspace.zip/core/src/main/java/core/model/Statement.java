package core.model;

public interface Statement extends SubjectKind, PropertyKind, ObjectKind {

	public Context getContext();
	
	public Subject getSubject();
	
	public Property getProperty();
	
	public Object getObject();
	
}
