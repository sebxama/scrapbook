package com.sebxama.functional.model.objectmapper.deserializer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.node.IntNode;
import com.sebxama.functional.model.Context;
import com.sebxama.functional.model.ContextKind;
import com.sebxama.functional.model.Property;
import com.sebxama.functional.model.Statement;
import com.sebxama.functional.model.URI;
import com.sebxama.functional.service.RegistryService;

public class PropertyDeserializer extends StdDeserializer<Property> { 

    public PropertyDeserializer() { 
        this(null); 
    } 

    public PropertyDeserializer(Class<?> vc) { 
        super(vc); 
    }

    @Override
    public Property deserialize(JsonParser jp, DeserializationContext ctxt)
    	throws IOException, JsonProcessingException {
        
    	RegistryService registry = RegistryService.getInstance();
    	JsonNode node = jp.getCodec().readTree(jp);
        String occurrence = node.get("uri").asText();
        String attribute = node.get("attribute").asText();
        String value = node.get("value").asText();
        URI occurUri = registry.getURI(occurrence);
        URI attrUri = registry.getURI(attribute);
        URI valUri = registry.getURI(value);
        
        Property prop = new Property();
        prop.setURI(occurUri);
        prop.setAttribute(attrUri);
        prop.setValue(valUri);

        return prop;
    }
}
