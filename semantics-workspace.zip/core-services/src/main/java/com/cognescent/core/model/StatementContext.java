package com.cognescent.core.model;

public class StatementContext extends IRIStatementOccurrence {

}
