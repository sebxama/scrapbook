package com.sebxama.functional.function;

import java.util.function.BiFunction;
import java.util.function.Function;

import com.sebxama.functional.model.URI;

public abstract class ModelBiFunction implements BiFunction<URI, URI, URI>{

	private URI strategy;
	
	protected ModelBiFunction(URI strategy) {
		this.strategy = strategy;
	}
	
	@Override
	public URI apply(URI t, URI u) {
		// TODO Auto-generated method stub
		return null;
	}

}
