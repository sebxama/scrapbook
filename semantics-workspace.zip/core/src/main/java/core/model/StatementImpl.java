package core.model;

import java.util.HashMap;
import java.util.Map;

public class StatementImpl extends ResourceImpl<Statement> implements Statement {

	private static Map<IRI, Statement> stats = new HashMap<IRI, Statement>();
	
	private Context context;
	private Subject subject;
	private Property property;
	private Object object;
	
	private Resource instance;
	private Resource attribute;
	private Resource value;
	
	protected StatementImpl(IRI iri) {
		super(iri);
		setResource(this);
	}

	public Resource getInstance(Statement ctx) {
		return instance;
	}

	public Resource getAttribute(Statement ctx) {
		return attribute;
	}

	public Resource getValue(Statement ctx) {
		return value;
	}

	public Context getContext() {
		return context;
	}

	public Subject getSubject() {
		return subject;
	}

	public Property getProperty() {
		return property;
	}

	public Object getObject() {
		return object;
	}

	public void setContext(Context context) {
		this.context = context;
		context.getIRI().getOccurrences().add(this);
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
		subject.getIRI().getOccurrences().add(this);
	}

	public void setProperty(Property property) {
		this.property = property;
		property.getIRI().getOccurrences().add(this);
	}

	public void setObject(Object object) {
		this.object = object;
		object.getIRI().getOccurrences().add(this);
	}

	public void setInstance(Statement ctx, Subject subj) {
		this.instance = subj;
	}

	public void setAttribute(Statement ctx, Property prop) {
		this.attribute = prop;
	}

	public void setValue(Statement ctx, Object obj) {
		this.value = obj;
	}

}
