package core.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;

public class ObjectKindImpl extends KindImpl implements ObjectKind {

	static Map<Resource, ObjectKind> instances = new HashMap<>();
	public static ObjectKind getInstance(Resource key) {
		ObjectKind ret = instances.get(key);
		if(ret == null) {
			ret = new ObjectKindImpl(key);
			instances.put(key, ret);
		}
		return ret;
	}
	
	private ObjectKindImpl(Resource iri) {
		super(iri);
	}

	@Override
	public Set<Object> getInstanceObjects(Resource instance) {
		return Objects.getInstance().getObjects(null, null, null, instance);
	}

	@Override
	public Set<Property> getAttributeProperties(Resource attribute) {
		return Properties.getInstance().getProperties(null, null, attribute, null);
	}

	@Override
	public Set<Subject> getValueSubjects(Resource value) {
		return Subjects.getInstance().getSubjects(null, value, null, null);
	}
	
}
