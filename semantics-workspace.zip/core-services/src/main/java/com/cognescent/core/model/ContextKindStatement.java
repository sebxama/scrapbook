package com.cognescent.core.model;

import com.cognescent.core.streams.ContextKindsStream;

public class ContextKindStatement extends KindStatement<StatementContext, StatementSubject, StatementObject> {
	
	public ContextKindStatement(Kind<StatementContext, StatementSubject, StatementObject> kind, StatementContext instance, StatementSubject attribute, StatementObject value) {
		super(kind, instance, attribute, value);
		kind.addStatement(this);
	}
	
}
