package core.model;

public class ObjectKindImpl extends KindImpl<Object, Property, Subject> implements ObjectKind {
	
	public ObjectKindImpl(Resource iri) {
		super(iri);
	}
	
}
