package core.model;

import java.util.HashSet;
import java.util.Set;

public class Objects {

	private static Objects instance;
	public static Objects getInstance() {
		if(instance == null)
			instance = new Objects();
		return instance;
	}
	
	protected Objects() {
		
	}
	
	public Set<Object> getObjects() {
		Set<Object> ret = new HashSet<Object>();
		for(Statement stat : Statements.getInstance().getStatements())
			ret.add(stat.getObject());
		return ret;
	}

	public Set<Object> getObjects(Resource context, Resource subject, Resource property, Resource object) {
		Set<Object> ret = new HashSet<Object>();
		for(Statement stat : Statements.getInstance().getStatements(context, subject, property, object))
			ret.add(stat.getObject());
		return ret;
	}
	
}
