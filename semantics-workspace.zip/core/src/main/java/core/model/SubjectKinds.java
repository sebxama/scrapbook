package core.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SubjectKinds {

	private static SubjectKinds instance;
	public static SubjectKinds getInstance() {
		if(instance == null)
			instance = new SubjectKinds();
		return instance;
	}
	
	protected SubjectKinds() {
		
	}

	// TODO:
	public Set<SubjectKind> getSubjectKinds(Resource context, Resource instance, Resource attribute, Resource value) {
		Set<SubjectKind> ret = new HashSet<SubjectKind>();
		for(Statement stat : Statements.getInstance().getStatements(context, instance, attribute, value))
			ret.add(stat.getSubjectKind());
		return ret;
	}
	
	/**
	 * FCA Concepts context lattice building. Resource: FCA Context,
	 * Kind Instance: FCA Context objects, Kind Attribute: FCA Context attributes.
	 * @return Kinds aggregated by distinct Subjects Resource (IRI) for Statement
	 *         Occurrences Kinds Merge.
	 */
	public Map<Resource, Set<SubjectKind>> getSubjectAggregatedKinds() {
		Map<Resource, Set<SubjectKind>> ret = new HashMap<Resource, Set<SubjectKind>>();
		for(Subject subj : Subjects.getInstance().getSubjects()) {
			Set<SubjectKind> set = ret.get(subj.getResource());
			if(set == null)
				set = new HashSet<SubjectKind>();
			set.add(subj.getSubjectKind());
			ret.put(subj.getResource(), set);
		}
		return ret;
	}
	
	/**
	 * Once Aggregated (FCA), Context Statements Kinds merged / updated.
	 * Populate corresponding Kind Statements from Kinds in Context Statements.
	 * @return Aggregated Kind Statements.
	 */
	public Set<SubjectKindStatement> getSubjectKindStatements() {
		Set<SubjectKindStatement> ret = new HashSet<SubjectKindStatement>();
		Set<SubjectKind> kinds = getSubjectKinds(null, null, null, null);
		for(SubjectKind kind : kinds) {
			Resource iri = Resource.getKindStatementResource(kind.getContextKind(), kind.getSubjectKind(), kind.getPropertyKind(), kind.getObjectKind());
			SubjectKindStatement stat = new SubjectKindStatement(iri);
			stat.setContext(kind.getSubjectKind());
			stat.setSubject(kind.getSubjectKind());
			stat.setProperty(kind.getPropertyKind());
			stat.setObject(kind.getObjectKind());
			ret.add(stat);
		}
		return ret;
	}
	
}
