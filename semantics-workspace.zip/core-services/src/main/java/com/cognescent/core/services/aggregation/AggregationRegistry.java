package com.cognescent.core.services.aggregation;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.cognescent.core.model.IRIStatementOccurrence;
import com.cognescent.core.model.Kind;

public class AggregationRegistry<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {

	private static AggregationRegistry instance;
	public static AggregationRegistry getInstance() {
		if(instance == null)
			instance = new AggregationRegistry();
		return instance;
	}
	
	private Map<String, AggregationKind<INST, ATTR, VAL>> kinds;
	private Map<String, AggregationInstance<INST, ATTR, VAL>> instances;
	private Map<String, AggregationAttribute<INST, ATTR, VAL>> attributes;
	private Map<String, AggregationValue<INST, ATTR, VAL>> values;
	
	protected AggregationRegistry() {
		kinds = new HashMap<String, AggregationKind<INST, ATTR, VAL>>();
		instances = new HashMap<String, AggregationInstance<INST, ATTR, VAL>>();
		attributes = new HashMap<String, AggregationAttribute<INST, ATTR, VAL>>();
		values = new HashMap<String, AggregationValue<INST, ATTR, VAL>>();
	}
	
	public AggregationKind<INST, ATTR, VAL> getAggregationKind(String iri, Kind<INST, ATTR, VAL> val) {
		AggregationKind ret = kinds.get(iri);
		if(ret == null) {
			ret = new AggregationKind(val);
			kinds.put(iri, ret);
		}
		return ret;
	}
	
	public AggregationInstance getAggregationInstance(String iri, INST val) {
		AggregationInstance<INST, ATTR, VAL> ret = instances.get(iri);
		if(ret == null) {
			ret = new AggregationInstance<INST, ATTR, VAL>(val);
			instances.put(iri, ret);
		}
		return ret;
	}

	public AggregationAttribute getAggregationAttribute(String iri, ATTR val) {
		AggregationAttribute<INST, ATTR, VAL> ret = attributes.get(iri);
		if(ret == null) {
			ret = new AggregationAttribute<INST, ATTR, VAL>(val);
			attributes.put(iri, ret);
		}
		return ret;
	}
	
	public AggregationValue getAggregationValue(String iri, VAL val) {
		AggregationValue<INST, ATTR, VAL> ret = values.get(iri);
		if(ret == null) {
			ret = new AggregationValue<INST, ATTR, VAL>(val);
			values.put(iri, ret);
		}
		return ret;
	}
	
}
