package core.model;

/**
 * Resource (IRI) Occurrence in Context Statement.
 *
 */
public interface ResourceOccurrence {

	public Resource getResource();
	
	public Statement getContextStatement();

	public void setContextStatement(Statement stat);
	
}
