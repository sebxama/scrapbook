package core.model;

public interface PropertyKind extends Subject, Object, Kind {
	
}
