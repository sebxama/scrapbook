package core.model.alignment;

// Infer relationships / properties
public class Alignment {

}
