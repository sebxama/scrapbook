package com.cognescent.core.model;

public class Statement /* extends IRIStatementOccurrence */{

	private StatementContext context;
	private StatementSubject subject;
	private StatementPredicate predicate;
	private StatementObject object;
	
	public Statement() {
		
	}

	public StatementContext getContext() {
		return context;
	}

	public void setContext(StatementContext context) {
		this.context = context;
	}

	public StatementSubject getSubject() {
		return subject;
	}

	public void setSubject(StatementSubject subject) {
		this.subject = subject;
	}

	public StatementPredicate getPredicate() {
		return predicate;
	}

	public void setPredicate(StatementPredicate predicate) {
		this.predicate = predicate;
	}

	public StatementObject getObject() {
		return object;
	}

	public void setObject(StatementObject object) {
		this.object = object;
	}
	
}
