package com.sebxama.functional.model;

import java.util.Set;

public interface URIOccurrence {

	public URI getOccurrenceURI();
	public URI getURI();
	public Statement getStatement();
	public Kind getKind();
	public Set<Property> getProperties();

}
