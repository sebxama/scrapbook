package com.sebxama.functional.model;

public class Predicate {

	private URI uri;
	private Statement statement;
	private PredicateKind kind;
	
	public Predicate(URI uri, Statement statement) {
		uri.getPredicateOccurrences().add(this);
		this.uri = uri;
		this.statement = statement;
	}
	
	public URI getURI() {
		return this.uri;
	}
	
	public Statement getStatement() {
		return this.statement;
	}
	
	public void setKind(PredicateKind kind) {
		kind.getOccurrences().add(this.uri);
		kind.getPredicateOccurrences().add(this);
		this.kind = kind;
	}
	
	public PredicateKind getKind() {
		return this.kind;
	}
	
}
