package core.activation;

import java.util.Set;

import org.springframework.stereotype.Service;

import core.model.KindStatementImpl;

@Service
public class ActivationService {

	public Set<KindStatementImpl> performSubjectKindsActivation(Set<KindStatementImpl> stats) {
		// TODO
		return null;
	}
	
}
