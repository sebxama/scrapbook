package core.model;

import java.util.HashMap;
import java.util.Map;

public class ContextImpl extends ResourceImpl<Context> implements Context {

	private static Map<IRI, Context> ctxs = new HashMap<IRI, Context>();
	
	public ContextImpl(IRI iri) {
		super(iri);
		setResource(this);
	}
	
	public static Context getOrCreate(IRI iri) {
		Context ret = ctxs.get(iri);
		if(ret == null) {
			ret = new ContextImpl(iri);
			ctxs.put(iri, ret);
		}
		return ret;
	}

}
