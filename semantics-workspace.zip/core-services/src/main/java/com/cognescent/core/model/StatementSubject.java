package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

import com.cognescent.core.streams.SubjectsStream;

public class StatementSubject extends IRIStatementOccurrence {

	private static Map<IRI, StatementSubject> subjects = new HashMap<IRI, StatementSubject>();
	
	protected StatementSubject() {
		SubjectsStream.getInstance().addSubject(this);
	}
	
	public static StatementSubject getByIRI(IRI key) {
		StatementSubject subj = subjects.get(key);
		if(subj == null) {
			subj = new StatementSubject();
			subj.setIRI(key);
			subjects.put(key, subj);
		}
		return subj;
	}
	
	public String toString() {
		return "{ \"className\": \""+this.getClass().getCanonicalName()+"\", \"IRI\" : \""+this.getIRI().getValue()+"\"}";
	}
	
	public int hashCode() {
		return (this.getClass().getCanonicalName() + ":" + this.getIRI().getValue()).hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}

}
