package com.cognescent.core.services;

public class AlignmentService {

}
