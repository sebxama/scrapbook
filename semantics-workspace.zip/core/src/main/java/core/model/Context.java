package core.model;

public interface Context extends Resource {

}
