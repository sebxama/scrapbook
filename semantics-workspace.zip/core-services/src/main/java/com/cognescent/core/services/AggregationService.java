package com.cognescent.core.services;

public class AggregationService {

}
