package core.model;

import java.util.HashSet;
import java.util.Set;

public abstract class ResourceImpl<TYPE> implements Resource {

	private IRI iri;
	private TYPE resource;
	
	public ResourceImpl(IRI iri) {
		this.iri = iri;
	}
	
	public IRI getIRI() {
		return iri;
	}
	
	public void setResource(TYPE res) {
		this.resource = res;
	}
	
	public TYPE getResource() {
		return this.resource;
	}
	
	public String toString() {
		String ret = this.getClass().getCanonicalName() + " : " + this.getIRI().toString();
		return ret;
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
