package core.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SubjectKinds {

	private static SubjectKinds instance;
	public static SubjectKinds getInstance() {
		if(instance == null)
			instance = new SubjectKinds();
		return instance;
	}
	
	protected SubjectKinds() {
		
	}

	// TODO:
	public Set<SubjectKind> getSubjectKinds(Context context, Subject instance, Property attribute, Object value) {
		Set<SubjectKind> ret = new HashSet<SubjectKind>();
		for(Statement stat : Statements.getInstance().getStatements(context.getIRI(), instance.getIRI(), attribute.getIRI(), value.getIRI())) {
			SubjectKindImpl sk = new SubjectKindImpl(stat.getContext().getIRI());
			sk.setInstance(stat.getSubject());
			sk.setAttribute(stat.getProperty());
			sk.setValue(stat.getObject());
			sk.setContextStatement(stat);
			ret.add(sk);
		}
		return ret;
	}
	
	// TODO: ContextKinds: Context instance, Property attribute, Object value.
	public Map<Context, SubjectKind> getAggregatedKinds() {
		Map<Context, SubjectKind> ret = new HashMap<Context, SubjectKind>();
		return ret;
	}

}
