package com.cognescent.core.model;

public class ContextKind extends Kind<StatementContext, StatementSubject, StatementObject> {

}
