package com.sebxama.augmentation.service;

import org.eclipse.rdf4j.spring.RDF4JConfig;
import org.eclipse.rdf4j.spring.support.RDF4JTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Service;

public class RDF4JService {

	private RDF4JTemplate rdfTemplate;
	
	public RDF4JService(@Autowired RDF4JTemplate template) {
		this.rdfTemplate = template;
	}

	public RDF4JTemplate getRDF4JTemplate() {
		return this.rdfTemplate;
	}
	
}
