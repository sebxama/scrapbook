package com.cognescent.core.model;

public class SubjectKindStatement extends KindStatement<StatementSubject, StatementPredicate, StatementObject> {
	
	public SubjectKindStatement(Kind<StatementSubject, StatementPredicate, StatementObject> kind, StatementSubject instance, StatementPredicate attribute, StatementObject value) {
		super(kind, instance, attribute, value);
		kind.addStatement(this);
	}

	public String toString() {
		return "{\"className\": \""+this.getClass().getName()+"\", "+ 
					"\"kind\" : "+this.getKind().toString()+", " +
					"\"instance\" : + "+this.getInstance().toString()+", " +
					"\"attribute\" : + "+this.getAttribute().toString()+", " +
					"\"value\" : + "+this.getValue().toString() + "}";
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
