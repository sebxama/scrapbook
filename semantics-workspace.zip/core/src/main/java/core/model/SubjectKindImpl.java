package core.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

public class SubjectKindImpl extends KindImpl<Subject, Property, Object> implements SubjectKind {

	public SubjectKindImpl(Resource iri) {
		super(iri);
	}
	
	@Override
	@JsonBackReference
	public SubjectKind getSubjectKind() {
		return this.getContextStatement().getSubjectKind();
	}
	
	@Override
	@JsonBackReference
	public ContextKind getContextKind() {
		return this.getContextStatement().getContextKind();
	}
	
	/**
	 * Relationship domain.
	 */
	@Override
	@JsonBackReference
	public PropertyKind getPropertyKind() {
		return this.getContextStatement().getPropertyKind();
	}

	/**
	 * Relationship range.
	 */
	@Override
	@JsonBackReference
	public ObjectKind getObjectKind() {
		return this.getContextStatement().getObjectKind();
	}

}
