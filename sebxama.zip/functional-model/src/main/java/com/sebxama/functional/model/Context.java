package com.sebxama.functional.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sebxama.functional.model.objectmapper.deserializer.ContextDeserializer;
import com.sebxama.functional.model.objectmapper.serializer.ContextSerializer;

@JsonDeserialize(using = ContextDeserializer.class)
@JsonSerialize(using = ContextSerializer.class)
public class Context implements URIOccurrence {

	private URI uri;
	private Statement statement;
	private ContextKind kind;

	public Context() {
		
	}
	
	public URI getURI() {
		return this.uri;
	}
	
	public void setURI(URI uri) {
		uri.getContextOccurrences().add(this);
		this.uri = uri;
	}
	
	public Statement getStatement() {
		return this.statement;
	}
	
	public void setStatement(Statement stat) {
		this.statement = stat;
	}

	public ContextKind getKind() {
		return this.kind;
	}
	
	public void setKind(ContextKind kind) {
		kind.getContextOccurrences().add(this);
		this.kind = kind;
	}
	
	public String toString() {
		return "Context; URI: " + this.uri; 
	}
	
}
