package com.cognescent.core.model;

import com.cognescent.core.streams.ContextKindsStream;

public class PredicateKindStatement extends KindStatement<StatementPredicate, StatementSubject, StatementObject> {
	
	public PredicateKindStatement(Kind<StatementPredicate, StatementSubject, StatementObject> kind, StatementPredicate instance, StatementSubject attribute, StatementObject value) {
		super(kind, instance, attribute, value);
		kind.addStatement(this);
	}
	
	public String toString() {
		return "{\"className\": \""+this.getClass().getCanonicalName()+"\", "+ 
					"\"kind\" : "+this.getKind().toString()+", " +
					"\"statement\" : + "+this.getStatement().toString()+", " +
					"\"instance\" : + "+this.getInstance().toString()+", " +
					"\"attribute\" : + "+this.getAttribute().toString()+", " +
					"\"value\" : + "+this.getValue().toString() + "}";
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
