package com.sebxama.augmentation.boot;

import java.util.ArrayList;
import java.util.List;

import org.apache.kafka.clients.consumer.ConsumerRecord;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.kafka.core.reactive.ReactiveKafkaConsumerTemplate;
import org.springframework.kafka.core.reactive.ReactiveKafkaProducerTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.sebxama.augmentation.service.AugmentationService;
import com.sebxama.augmentation.service.IndexService;
import com.sebxama.augmentation.service.NamingService;
import com.sebxama.augmentation.service.RegistryService;
import com.sebxama.functional.model.dto.Quad;

import reactor.core.Disposable;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.kafka.receiver.ReceiverRecord;

@Configuration
public class KafkaListener {

	@Autowired
	ReactiveKafkaConsumerTemplate<String, String> receiverTemplate;

	@Autowired
	ReactiveKafkaProducerTemplate<String, String> producerTemplate;

	@Autowired
	WebClient.Builder wcBuilder;

	@Autowired
	AugmentationService augmentationService;

    @EventListener(ApplicationStartedEvent.class)
    public Disposable startKafkaConsumer() {
        return receiverTemplate.receiveAutoAck()
        // .delayElements(Duration.ofSeconds(2L)) // BACKPRESSURE
        .doOnNext(consumerRecord -> 
        	System.out.println("received key={"+consumerRecord.key()+"}, value={"+consumerRecord.value()+"} from topic={"+consumerRecord.topic()+"}, offset={"+consumerRecord.offset()+"}"))
        .map(consumerRecord -> this.handleEvent(consumerRecord.key(), consumerRecord.value()))
        .doOnNext(dto -> System.out.println("successfully consumed {"+dto.getClass().getSimpleName()+"}={"+dto+"}"))
        .doOnError(throwable -> System.out.println("error: {"+throwable.getMessage()+"}"))
        .subscribe();
    }

    private Mono<String> handleEvent(String key, String record) {
    	// Services business layer handling
    	System.out.println("handleEvent; KEY: "+key+"; RECORD: "+record);
    	ObjectMapper mapper = new ObjectMapper();
    	try {
    		Quad quad = mapper.readValue(record, Quad.class);
    		List<Quad> quads = new ArrayList<Quad>();
    		quads.add(quad);
    		Flux<Quad> flux = Flux.fromIterable(quads);
    		Flux<Quad> ret = augmentationService.perform(flux);
    		return Mono.just(record);
    	} catch(Throwable t) {
    		t.printStackTrace();
    		return Mono.just(t.getMessage());
    	}
    }

}
