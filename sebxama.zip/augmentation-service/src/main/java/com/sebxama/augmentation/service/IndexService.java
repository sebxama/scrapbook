package com.sebxama.augmentation.service;

import java.util.Optional;
import java.util.function.Function;

import org.eclipse.rdf4j.spring.support.RDF4JTemplate;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.kafka.core.reactive.ReactiveKafkaProducerTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClient.UriSpec;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sebxama.augmentation.repository.ServiceRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class IndexService {

	@Autowired
	RDF4JService rdfTemplate;
	
	@Autowired
	PrimesIDService idsService;
	
	@Autowired
	ServiceRepository serviceRepository;

	@Autowired
	ReactiveKafkaProducerTemplate<String, String> rkpt;

}
