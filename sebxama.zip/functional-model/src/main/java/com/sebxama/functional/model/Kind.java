package com.sebxama.functional.model;

import java.util.HashSet;
import java.util.Set;

public abstract class Kind {

	private URI uri;
	private Set<URIOccurrence> occurrences;
	
	public Kind() {
		this.occurrences = new HashSet<URIOccurrence>();
	}
	
	public URI getURI() {
		return this.uri;
	}
	
	public void setURI(URI uri) {
		this.uri = uri;
	}
	
	public Set<URIOccurrence> getURIOccurrences() {
		return this.occurrences;
	}
	
}
