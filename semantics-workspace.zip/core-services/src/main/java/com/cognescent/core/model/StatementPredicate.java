package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

public class StatementPredicate extends IRIStatementOccurrence {

	private static Map<IRI, StatementPredicate> predicates = new HashMap<IRI, StatementPredicate>();

	protected StatementPredicate() {

	}
	
	public static StatementPredicate getByIRI(IRI key) {
		StatementPredicate pred = predicates.get(key);
		if(pred == null) {
			pred = new StatementPredicate();
			pred.setIRI(key);
			predicates.put(key, pred);
		}
		return pred;
	}
	
	public String toString() {
		return "{ \"className\": \""+this.getClass().getCanonicalName()+"\", \"IRI\" : \""+this.getIRI().getValue()+"\"}";
	}
	
	public int hashCode() {
		return (this.getClass().getCanonicalName() + ":" + this.getIRI().getValue()).hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}

}
