package com.sebxama.functional.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SubjectKind extends Kind {

	public SubjectKind() {
		
	}

	public SubjectKind(Kind src) {
		super(src);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public Set<Predicate> getAttributes() {
		Set<Predicate> ret = new HashSet<Predicate>();
		for(Subject subj : super.getSubjectOccurrences()) {
			ret.add(subj.getStatement().getPredicate());
		}
		return ret;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Map<Predicate, Set<Value>> getAttributeValues() {
		Map<Predicate, Set<Value>> ret = new HashMap<Predicate, Set<Value>>();
		Set<Predicate> attrs = getAttributes();
		for(Predicate pred : attrs) {
			Set<Value> vals = new HashSet<Value>();
			for(Predicate occur : pred.getURI().getPredicateOccurrences()) {
				vals.add(occur.getStatement().getValue());
			}
			ret.put(pred, vals);
		}
		return ret;
	}

}
