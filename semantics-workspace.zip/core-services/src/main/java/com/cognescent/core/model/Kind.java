package com.cognescent.core.model;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.streams.KindsStream;

public abstract class Kind<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {

	private StatementContext type;
	private Set<IRIStatementOccurrence> statementOccurrences;
	private Set<KindStatement<INST, ATTR, VAL>> kindStatements;
	
	protected Kind() {
		KindsStream.getInstance().addKind(this);
		statementOccurrences = new HashSet<IRIStatementOccurrence>();
		kindStatements = new HashSet<KindStatement<INST, ATTR, VAL>>();
	}

	public void setType(StatementContext type) {
		this.type = type;
	}
	
	public StatementContext getType() {
		return this.type;
	}
	
	public Set<IRIStatementOccurrence> getStatementOccurrences() {
		return this.statementOccurrences;
	}
	
	public void addStatement(KindStatement<INST, ATTR, VAL> stat) {
		this.kindStatements.add(stat);
	}
	
	public Set<KindStatement<INST, ATTR, VAL>> getStatements(INST inst, ATTR attr, VAL val) {
		Set<KindStatement<INST, ATTR, VAL>> ret = new HashSet<KindStatement<INST, ATTR, VAL>>();
		for(KindStatement<INST, ATTR, VAL> i : this.kindStatements) {
			if(inst != null && attr != null && val != null) {
				if(i.getInstance().getIRI().equals(inst.getIRI()))
					if(i.getAttribute().getIRI().equals(attr.getIRI()))
						if(i.getValue().getIRI().equals(val.getIRI()))
							ret.add(i);
			}
			if(inst != null && attr != null && val == null) {
				if(i.getInstance().getIRI().equals(inst.getIRI()))
					if(i.getAttribute().getIRI().equals(attr.getIRI()))
						ret.add(i);				
			}
			if(inst != null && attr == null && val == null) {
				if(i.getInstance().getIRI().equals(inst.getIRI()))
					ret.add(i);
			}
			if(inst != null && attr == null && val != null) {
				if(i.getInstance().getIRI().equals(inst.getIRI()))
					if(i.getValue().getIRI().equals(val.getIRI()))
						ret.add(i);
			}
			if(inst == null && attr == null && val == null) {
				ret.add(i);
			}
		}
		return ret;
	}

	
}
