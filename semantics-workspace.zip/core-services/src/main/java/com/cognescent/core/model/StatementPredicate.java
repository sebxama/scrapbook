package com.cognescent.core.model;

public class StatementPredicate extends IRIStatementOccurrence {

}
