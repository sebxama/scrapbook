package com.cognescent.core.streams;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.ContextKind;
import com.cognescent.core.model.IRI;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.Statement;
import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.SubjectKind;

import reactor.core.publisher.Flux;

public class SubjectKindsStream {

	private static SubjectKindsStream instance;
	public static SubjectKindsStream getInstance() {
		if(instance == null)
			instance = new SubjectKindsStream();
		return instance;
	}
	
	private Set<SubjectKind> kinds;
	
	protected SubjectKindsStream() {
		this.kinds = new HashSet<SubjectKind>();
	}
	
	public void addSubjectKind(SubjectKind kind) {
		this.kinds.add(kind);
	}
	
	public void removeSubjectKind(SubjectKind kind) {
		this.kinds.remove(kind);
	}
	
	public Flux<SubjectKind> getStream() {
		return Flux.fromIterable(this.kinds);
	}
	
//	public Iterable<Statement> mapStatements(Iterable<IRI> match) {
//		// TODO:
//		return null;
//	}
//	
//	public Iterable<IRI> mapIRIs(Iterable<Statement> match) {
//		// TODO:
//		return null;
//	}
	
}
