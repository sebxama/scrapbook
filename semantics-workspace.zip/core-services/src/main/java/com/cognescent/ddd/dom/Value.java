package com.cognescent.ddd.dom;

public class Value extends Entity {

	public Value() {
		super();
	}
	
	public Value(String iri) {
		super(iri);
	}
	
}
