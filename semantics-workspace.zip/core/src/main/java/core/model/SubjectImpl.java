package core.model;

public class SubjectImpl extends ResourceOccurrenceImpl implements Subject {

	private SubjectKind kind;
	
	public SubjectImpl(Resource iri) {
		super(iri);
	}
	
	public SubjectKind getSubjectKind() {
		return this.kind;
	}
	
	public void setSubjectKind(SubjectKind kind) {
		this.kind = kind;
	}
	
}
