package com.cognescent.core.model;

public class SubjectKind extends Kind<StatementSubject, StatementPredicate, StatementObject> {

	public SubjectKind() {
		
	}
	
	public SubjectKind(StatementSubject instance, StatementPredicate attribute, StatementObject value) {
		super(instance, attribute, value);
	}
	
}
