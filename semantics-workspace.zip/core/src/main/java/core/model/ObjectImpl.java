package core.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

public class ObjectImpl extends ResourceOccurrenceImpl implements Object {
	
	public ObjectImpl(Resource iri) {
		super(iri);
	}
	
	@JsonBackReference
	public ObjectKind getObjectKind() {
		return this.getContextStatement().getObjectKind();
	}
	
}
