package com.cognescent.core.services.aggregation;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.IRIStatementOccurrence;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.StatementContext;

public class AggregationKind<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {
	
	private StatementContext type; // Kind ID URI
	private Kind<INST, ATTR, VAL> kind;
	private Set<AggregationInstance<INST, ATTR, VAL>> instances;
	
	public AggregationKind(Kind<INST, ATTR, VAL> kind) {
		this.kind = kind;
		this.type = kind.getType();
		this.instances = new HashSet<AggregationInstance<INST, ATTR, VAL>>();
	}
	
	public Set<AggregationInstance<INST, ATTR, VAL>> getAggregationInstances() {
		return this.instances;
	}
	
	public void setKind(Kind<INST, ATTR, VAL> kind) {
		this.kind = kind;
	}
	
	public Kind<INST, ATTR, VAL> getKind() {
		return this.kind;
	}
	
	// FIXME: Retrieve Instances (INST) AggregationKind Occurrences
	public Set<AggregationInstance<INST, ATTR, VAL>> getByInstance(INST inst) {
		Set<AggregationInstance<INST, ATTR, VAL>> ret = new HashSet<AggregationInstance<INST, ATTR, VAL>>();
		for(AggregationInstance<INST, ATTR, VAL> i : this.instances)
			if(i.getInstance().getIRI().getValue().equals(inst.getIRI().getValue()))
				ret.add(i);
		return ret;
	}

	// FIXME: Retrieve Instances (has ATTR) AggregationKind Occurrences
	public Set<AggregationInstance<INST, ATTR, VAL>> getByAttribute(ATTR attr) {
		Set<AggregationInstance<INST, ATTR, VAL>> ret = new HashSet<AggregationInstance<INST, ATTR, VAL>>();
		for(AggregationInstance<INST, ATTR, VAL> i : this.instances)
			for(AggregationAttribute<INST, ATTR, VAL> j : i.getAggregationAttributes())
				if(j.getAttribute().getIRI().getValue().equals(attr.getIRI().getValue()))
					ret.add(i);
		return ret;
	}

	// FIXME: Retrieve Instances (has VAL) AggregationKind Occurrences
	public Set<AggregationInstance<INST, ATTR, VAL>> getByValue(VAL val) {
		Set<AggregationInstance<INST, ATTR, VAL>> ret = new HashSet<AggregationInstance<INST, ATTR, VAL>>();
		for(AggregationInstance<INST, ATTR, VAL> i : this.instances)
			for(AggregationAttribute<INST, ATTR, VAL> j : i.getAggregationAttributes())
				for(AggregationValue<INST, ATTR, VAL> k : j.getAggregationValues())
					if(k.getValue().getIRI().getValue().equals(val.getIRI().getValue()))
						ret.add(i);
		return ret;
	}
	
}
