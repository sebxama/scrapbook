package core.model;

import java.util.Set;

public interface ObjectKind extends Context, Subject, Property, Object, Kind {

	public Set<Object> getInstanceObjects(Resource resource);
	
	public Set<Property> getAttributeProperties(Resource resource);
	
	public Set<Subject> getValueSubjects(Resource resource);
	
}
