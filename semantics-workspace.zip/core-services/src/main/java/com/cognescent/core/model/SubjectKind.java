package com.cognescent.core.model;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class SubjectKind extends Kind<StatementSubject, StatementPredicate, StatementObject> {

	private static Map<IRI, SubjectKind> subjectKinds = new HashMap<IRI, SubjectKind>();
	
	protected SubjectKind() {

	}
	
	public static SubjectKind getByIRI(IRI iri) {
		SubjectKind ret = subjectKinds.get(iri);
		if(ret == null) {
			ret = new SubjectKind();
			ret.setIRI(iri);
			subjectKinds.put(iri, ret);
		}
		return ret;
	}
	
	public static Collection<SubjectKind> getSubjectKinds() {
		return subjectKinds.values();
	}
	
	public String toString() {
		return "{\"className\": \""+this.getClass().getCanonicalName()+"\", "+ 
					"\"IRI\" : "+this.getIRI().getValue()+", " +
					"\"parent\" : + "+ (this.getParent() != null ? this.getParent().toString() : "{}") +", " +
					"\"instances\" : + "+this.getInstances().toString()+", " +
					"\"attributes\" : + "+this.getAttributes().toString() + ", " +
					"\"values\" : + "+this.getValues().toString() + "}";
	}
	
	public int hashCode() {
		return (this.getClass().getCanonicalName() + ":" + this.getIRI().getValue()).hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}

}
