package com.sebxama.functional.model;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public abstract class Kind {

	private Kind source;
	private URI uri;
	private Set<Context> contextOccurrences;
	private Set<Subject> subjectOccurrences;
	private Set<Predicate> predicateOccurrences;
	private Set<Value> objectOccurrences;
	
	public Kind() {
		this.source = this;
		this.contextOccurrences = new HashSet<Context>();
		this.subjectOccurrences = new HashSet<Subject>();
		this.predicateOccurrences = new HashSet<Predicate>();
		this.objectOccurrences = new HashSet<Value>();
	}
	
	public Kind(Kind src) {
		this();
		this.source = src;
	}

	public Kind getSource() {
		return this.source;
	}
	
	public URI getURI() {
		return this.source.uri;
	}
	
	public void setURI(URI uri) {
		this.source.uri = uri;
	}
	
	public Set<Context> getContextOccurrences() {
		return this.source.contextOccurrences;
	}

	public Set<Subject> getSubjectOccurrences() {
		return this.source.subjectOccurrences;
	}
	
	public Set<Predicate> getPredicateOccurrences() {
		return this.source.predicateOccurrences;
	}
	
	public Set<Value> getObjectOccurrences() {
		return this.source.objectOccurrences;
	}
	
	public abstract <A> Set<A> getAttributes();
	
	public abstract <A, V> Map<A, Set<V>> getAttributeValues();

}
