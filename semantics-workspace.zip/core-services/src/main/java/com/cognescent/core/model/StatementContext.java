package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

import com.cognescent.core.streams.ContextsStream;

public class StatementContext extends IRIStatementOccurrence {

	private static Map<IRI, StatementContext> contexts = new HashMap<IRI, StatementContext>();

	protected StatementContext() {
		ContextsStream.getInstance().addContext(this);
	}
	
	public static StatementContext get(IRI key) {
		StatementContext ctx = contexts.get(key);
		if(ctx == null) {
			ctx = new StatementContext();
			ctx.setIRI(key);
			contexts.put(key, ctx);
		}
		return ctx;
	}
	
}
