package com.sebxama.functional.model;

public interface URIOccurrence {

	public URI getOccurrenceURI();
	public URI getURI();
	public Statement getStatement();
	public Kind getKind();

}
