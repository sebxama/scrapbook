package com.cognescent.core.model;

public class ContextKindStatement extends KindStatement<StatementContext, StatementSubject, StatementObject> {
	
	public ContextKindStatement(Kind<StatementContext, StatementSubject, StatementObject> kind, StatementContext instance, StatementSubject attribute, StatementObject value) {
		super(kind, instance, attribute, value);
		kind.addStatement(this);
	}

	public String toString() {
		return "{\"className\": \""+this.getClass().getName()+"\", "+ 
					"\"kind\" : "+this.getKind().toString()+", " +
					"\"instance\" : + "+this.getInstance().toString()+", " +
					"\"attribute\" : + "+this.getAttribute().toString()+", " +
					"\"value\" : + "+this.getValue().toString() + "}";
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
