package com.cognescent.core.model;

public class ObjectKind extends Kind<StatementObject, StatementPredicate, StatementSubject> {

}
