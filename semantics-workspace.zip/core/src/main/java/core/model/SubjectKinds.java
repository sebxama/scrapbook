package core.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SubjectKinds {

	private static SubjectKinds instance;
	public static SubjectKinds getInstance() {
		if(instance == null)
			instance = new SubjectKinds();
		return instance;
	}
	
	protected SubjectKinds() {
		
	}

	// TODO:
	public Set<SubjectKind> getSubjectKinds(Context context, Subject instance, Property attribute, Object value) {
		Set<SubjectKind> ret = new HashSet<SubjectKind>();
		for(Statement stat : Statements.getInstance().getStatements(context.getResource(), instance.getResource(), attribute.getResource(), value.getResource()))
			ret.add(stat.getSubjectKind());
		return ret;
	}
	
	/**
	 * FCA Concepts context lattice building. Kind Instance: Axis,
	 * Kind Attribute: FCA Context objects, Kind Value: FCA Context attributes.
	 * @return Kinds aggregated by distinct Subjects Resource (IRI).
	 */
	public Map<Resource, Set<SubjectKind>> getSubjectAggregatedKinds() {
		Map<Resource, Set<SubjectKind>> ret = new HashMap<Resource, Set<SubjectKind>>();
		for(Subject subj : Subjects.getInstance().getSubjects()) {
			Set<SubjectKind> set = ret.get(subj.getResource());
			if(set == null)
				set = new HashSet<SubjectKind>();
			set.add(subj.getSubjectKind());
			ret.put(subj.getResource(), set);
		}
		return ret;
	}
	
}
