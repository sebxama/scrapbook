package core.model;

public class SubjectKindImpl extends KindImpl<Subject, Property, Object> implements SubjectKind {

	public SubjectKindImpl(Resource iri) {
		super(iri);
	}
	
}
