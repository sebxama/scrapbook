package core.model;

public interface Context extends ResourceOccurrence {
	
}
