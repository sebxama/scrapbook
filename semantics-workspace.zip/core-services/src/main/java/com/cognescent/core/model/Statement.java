package com.cognescent.core.model;

public class Statement /* extends IRIStatementOccurrence */ {

	private StatementContext context;
	private StatementSubject subject;
	private StatementPredicate predicate;
	private StatementObject object;
	
	public Statement() {
		
	}
	
	public Statement(String contextIRI, String subjectIRI, String predicateIRI, String objectIRI) {
		IRI context = IRI.get(contextIRI);
		IRI subject = IRI.get(subjectIRI);
		IRI predicate = IRI.get(predicateIRI);
		IRI object = IRI.get(objectIRI);
		StatementContext statementContext = StatementContext.get(context);
		StatementSubject statementSubject = StatementSubject.get(subject);
		StatementPredicate statementPredicate = StatementPredicate.get(predicate);
		StatementObject statementObject = StatementObject.get(object);
		context.getOccurrences().add(statementContext);
		subject.getOccurrences().add(statementSubject);
		predicate.getOccurrences().add(statementPredicate);
		object.getOccurrences().add(statementObject);
		statementContext.getStatementOccurrences().add(this);
		statementSubject.getStatementOccurrences().add(this);
		statementPredicate.getStatementOccurrences().add(this);
		statementObject.getStatementOccurrences().add(this);
		this.context = statementContext;
		this.subject = statementSubject;
		this.predicate = statementPredicate;
		this.object = statementObject;
	}
	
	public Statement(IRI context, IRI subject, IRI predicate, IRI object) {
		StatementContext statementContext = StatementContext.get(context);
		StatementSubject statementSubject = StatementSubject.get(subject);
		StatementPredicate statementPredicate = StatementPredicate.get(predicate);
		StatementObject statementObject = StatementObject.get(object);
		context.getOccurrences().add(statementContext);
		subject.getOccurrences().add(statementSubject);
		predicate.getOccurrences().add(statementPredicate);
		object.getOccurrences().add(statementObject);
		statementContext.getStatementOccurrences().add(this);
		statementSubject.getStatementOccurrences().add(this);
		statementPredicate.getStatementOccurrences().add(this);
		statementObject.getStatementOccurrences().add(this);		
		this.context = statementContext;
		this.subject = statementSubject;
		this.predicate = statementPredicate;
		this.object = statementObject;
	}

	public Statement(StatementContext context, StatementSubject subject, StatementPredicate predicate, StatementObject object) {
		context.getStatementOccurrences().add(this);
		subject.getStatementOccurrences().add(this);
		predicate.getStatementOccurrences().add(this);
		object.getStatementOccurrences().add(this);		
		this.context = context;
		this.subject = subject;
		this.predicate = predicate;
		this.object = object;
	}
	
	public StatementContext getContext() {
		return context;
	}

	public void setContext(StatementContext context) {
		this.context = context;
	}

	public StatementSubject getSubject() {
		return subject;
	}

	public void setSubject(StatementSubject subject) {
		this.subject = subject;
	}

	public StatementPredicate getPredicate() {
		return predicate;
	}

	public void setPredicate(StatementPredicate predicate) {
		this.predicate = predicate;
	}

	public StatementObject getObject() {
		return object;
	}

	public void setObject(StatementObject object) {
		this.object = object;
	}
	
	// TODO: For later aggregation
	public ContextKind getContextKind() {
		ContextKind kind = new ContextKind(this.context, this.subject, this.object);
		return kind;
	}
	
	// TODO: For later aggregation
	public SubjectKind getSubjectKind() {
		SubjectKind kind = new SubjectKind(this.subject, this.predicate, this.object);
		return kind;
	}
	
	// TODO: For later aggregation
	public PredicateKind getPredicateKind() {
		PredicateKind kind = new PredicateKind(this.predicate, this.subject, this.object);
		return kind;
	}
	
	// TODO: For later aggregation
	public ObjectKind getObjectKind() {
		ObjectKind kind = new ObjectKind(this.object, this.predicate, this.subject);
		return kind;
	}
	
}
