package fcalib.lib.fca;

/**
 * Implementation of an Expert for a Formal Context.
 * @author Leon Geis
 */
//TODO Expert Implementation
public class FCAExpert<O,A> {

}
