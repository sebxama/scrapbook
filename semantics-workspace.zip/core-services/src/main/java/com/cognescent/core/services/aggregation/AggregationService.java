package com.cognescent.core.services.aggregation;

import com.cognescent.core.model.Statement;
import com.cognescent.core.model.StatementObject;
import com.cognescent.core.model.StatementPredicate;
import com.cognescent.core.model.StatementSubject;
import com.cognescent.core.model.SubjectKind;

import reactor.core.publisher.Flux;

public class AggregationService {

	public void performAggregation(Flux<Statement> statementsFlux) {
		
		Statement stat = null;
		SubjectKind kind = stat.getSubjectKind();
		
		// AggregationRegistry: Retrieve IRI string identified entities. Creates new if not exists. 
		
		// Employee
		AggregationKind<StatementSubject, StatementPredicate, StatementObject> aggregation
			= AggregationRegistry.getInstance().getAggregationKind(kind.getType().getIRI().getValue(), kind);
		
		// aPerson
		AggregationInstance<StatementSubject, StatementPredicate, StatementObject> subject 
			= AggregationRegistry.getInstance().getAggregationInstance(stat.getSubject().getIRI().getValue(), stat.getSubject());
		aggregation.getAggregationInstances().add(subject);
		
		// worksFor
		AggregationAttribute<StatementSubject, StatementPredicate, StatementObject> predicate 
			= AggregationRegistry.getInstance().getAggregationAttribute(stat.getPredicate().getIRI().getValue(), stat.getPredicate());
		subject.getAggregationAttributes().add(predicate);

		// employeer
		AggregationValue<StatementSubject, StatementPredicate, StatementObject> object 
			= AggregationRegistry.getInstance().getAggregationValue(stat.getObject().getIRI().getValue(), stat.getObject());
		predicate.getAggregationValues().add(object);
		
	}
	
}
