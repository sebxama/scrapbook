package core.model;

public interface PropertyKind extends Context, Subject, Property, Object, Kind {

	public Property getInstance();
	
	public Subject getAttribute();
	
	public Object getValue();
	
}
