package core.model;

import java.util.Set;

public interface PropertyKind extends Context, Subject, Property, Object, Kind {

	public Set<Property> getInstanceProperties(Resource resource);
	
	public Set<Subject> getAttributeSubjects(Resource resource);
	
	public Set<Object> getValueObjects(Resource resource);
	
}
