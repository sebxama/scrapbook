package core.model;

public interface ObjectKind extends Subject, Property, Kind {

	public Object getInstance();
	
	public Property getAttribute();
	
	public Subject getValue();
	
}
