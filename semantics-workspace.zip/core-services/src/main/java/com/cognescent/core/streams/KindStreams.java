package com.cognescent.core.streams;

import com.cognescent.core.model.IRI;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.Statement;

public class KindStreams {

	private Kind kind;
	
	public KindStreams(Kind kind) {
		this.kind = kind;
	}
	
	public Iterable<Statement> mapStatements(Iterable<IRI> match) {
		// TODO:
		return null;
	}
	
	public Iterable<IRI> mapIRIs(Iterable<Statement> match) {
		// TODO:
		return null;
	}
	
}
