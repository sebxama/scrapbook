package com.cognescent.core.model;

import java.util.HashMap;
import java.util.Map;

public class StatementObject extends IRIStatementOccurrence {

	private static Map<IRI, StatementObject> objects = new HashMap<IRI, StatementObject>();
	
	public static StatementObject get(IRI key) {
		StatementObject obj = objects.get(key);
		if(obj == null) {
			obj = new StatementObject();
			obj.setIRI(key);
			objects.put(key, obj);
		}
		return obj;
	}
	
}
