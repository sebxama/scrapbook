package core.model;

public interface Subject extends ResourceOccurrence {
	
	public SubjectKind getSubjectKind();
	
}
