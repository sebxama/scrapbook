package core.model;

public abstract class KindImpl<INST extends ResourceOccurrence, ATTR extends ResourceOccurrence, VAL extends ResourceOccurrence> implements Kind {

	private Resource iri;
	private Statement context;
	
	private INST instance;
	private ATTR attribute;
	private VAL value;
	
	public KindImpl(Resource iri) {
		this.iri = iri;
	}
	
	public Resource getResource() {
		return this.iri;
	}

	public Statement getContextStatement() {
		return this.context;
	}
	
	public void setContextStatement(Statement stat) {
		this.context = stat;
	}

	public INST getInstance() {
		return this.instance;
	}

	public ATTR getAttribute() {
		return this.attribute;
	}

	public VAL getValue() {
		return this.value;
	}

	public void setInstance(INST res) {
		this.instance = res;
	}

	public void setAttribute(ATTR res) {
		this.attribute = res;
	}

	public void setValue(VAL res) {
		this.value = res;
	}

	public String toString() {
		String ret = this.getClass().getCanonicalName() + " : " + this.getResource().toString() + "["+this.context.getResource().toString()+"]";
		return ret;
	}
	
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
