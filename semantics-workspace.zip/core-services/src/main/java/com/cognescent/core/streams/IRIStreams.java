package com.cognescent.core.streams;

import com.cognescent.core.model.IRI;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.Statement;

public class IRIStreams {

	private IRI iri;
	
	public IRIStreams(IRI iri) {
		this.iri = iri;
	}
	
	public Iterable<Kind> mapStatements(Iterable<Statement> match) {
		// TODO:
		return null;
	}
	
	public Iterable<Statement> mapKinds(Iterable<Kind> match) {
		// TODO:
		return null;
	}
	
}
