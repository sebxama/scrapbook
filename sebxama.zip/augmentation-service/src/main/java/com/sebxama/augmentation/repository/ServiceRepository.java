package com.sebxama.augmentation.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.sebxama.augmentation.model.Espectador;

import reactor.core.publisher.Flux;

@Repository
public interface ServiceRepository extends R2dbcRepository<Espectador, Integer> {

	Flux<Espectador> findByNombreContaining(String nombre);

}
