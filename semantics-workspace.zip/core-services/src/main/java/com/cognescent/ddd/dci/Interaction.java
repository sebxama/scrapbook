package com.cognescent.ddd.dci;

public class Interaction {

	private Data data;
	private Context context;
	
	// TODO: Actor / Role bindings. Perform streams.
	
}
