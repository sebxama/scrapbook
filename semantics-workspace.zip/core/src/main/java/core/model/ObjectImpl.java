package core.model;

public class ObjectImpl extends ResourceOccurrenceImpl implements Object {
	
	public ObjectImpl(Resource iri) {
		super(iri);
	}
	
}
