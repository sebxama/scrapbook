package com.sebxama.functional.service;

public class IndexService {

	private static IndexService instance;
	public static IndexService getInstance() {
		if(instance == null)
			instance = new IndexService();
		return instance;
	}
	
}
