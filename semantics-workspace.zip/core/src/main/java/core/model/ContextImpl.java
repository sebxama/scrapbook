package core.model;

public class ContextImpl extends ResourceOccurrenceImpl implements Context {
	
	public ContextImpl(Resource iri) {
		super(iri);
	}
	
}
