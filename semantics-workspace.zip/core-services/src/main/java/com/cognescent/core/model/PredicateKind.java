package com.cognescent.core.model;

import com.cognescent.core.streams.PredicateKindsStream;

public class PredicateKind extends Kind<StatementPredicate, StatementSubject, StatementObject> {

	protected PredicateKind() {
		PredicateKindsStream.getInstance().addPredicateKind(this);	
	}
	
}
