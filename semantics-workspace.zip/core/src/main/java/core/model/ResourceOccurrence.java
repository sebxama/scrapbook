package core.model;

public interface ResourceOccurrence {

	public Resource getIRI();
	
	public Statement getContextStatement();

	public void setContextStatement(Statement stat);
	
}
