package core.model;

import java.util.HashMap;
import java.util.Map;

public class PropertyImpl extends ResourceImpl<Property> implements Property {

	private static Map<IRI, Property> props = new HashMap<IRI, Property>();

	public PropertyImpl(IRI iri) {
		super(iri);
		setResource(this);
	}

	public static Property getOrCreate(IRI iri) {
		Property ret = props.get(iri);
		if(ret == null) {
			ret = new PropertyImpl(iri);
			props.put(iri, ret);
		}
		return ret;
	}
	
}
