package com.sebxama.functional.function;

import java.util.function.Function;

import com.sebxama.functional.model.URI;

public abstract class ModelFunction implements Function<URI, URI>{

	private URI strategy;
	
	protected ModelFunction(URI strategy) {
		this.strategy = strategy;
	}
	
	@Override
	public URI apply(URI t) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
