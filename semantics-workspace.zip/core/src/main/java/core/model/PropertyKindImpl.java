package core.model;

import java.util.HashMap;
import java.util.Map;

public class PropertyKindImpl extends ResourceImpl<PropertyKind> implements PropertyKind {

	private static Map<IRI, PropertyKind> props = new HashMap<IRI, PropertyKind>();
	
	private Map<Statement, Property> instances;
	private Map<Statement, Subject> attributes;
	private Map<Statement, Object> values;
	
	public PropertyKindImpl(IRI iri) {
		super(iri);
		setResource(this);
		this.instances = new HashMap<Statement, Property>();
		this.attributes = new HashMap<Statement, Subject>();
		this.values = new HashMap<Statement, Object>();
	}

	public Property getInstance(Statement ctx) {
		return instances.get(ctx);
	}

	public Subject getAttribute(Statement ctx) {
		return attributes.get(ctx);
	}

	public Object getValue(Statement ctx) {
		return values.get(ctx);
	}

	public void setInstance(Statement ctx, Property prop) {
		this.instances.put(ctx, prop);
	}

	public void setAttribute(Statement ctx, Subject subj) {
		this.attributes.put(ctx, subj);
	}

	public void setValue(Statement ctx, Object obj) {
		this.values.put(ctx, obj);
	}
	
	public static PropertyKind getOrCreate(IRI iri) {
		PropertyKind ret = props.get(iri);
		if(ret == null) {
			ret = new PropertyKindImpl(iri);
			props.put(iri, ret);
		}
		return ret;
	}
	
}
