package core.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Resource {

	private static Map<String, Resource> resources = new HashMap<String, Resource>();
	private String iri;
	
	private Resource(String iri) {
		this.iri = iri;
	}
	
	public static Resource get(String iri) {
		Resource res = resources.get(iri);
		if(res == null) {
			res = new Resource(iri);
			resources.put(iri, res);
		}
		return res;
	}
	
	public String getIRI() {
		return this.iri;
	}
	
	public String toString() {
		return this.iri;
	}
	
	public int hashCode() {
		return this.iri.hashCode();
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof Resource)
			return obj.hashCode() == this.hashCode();
		return false;
	}

}
