package com.sebxama.functional.model;

import java.util.HashSet;
import java.util.Set;

public class Kind extends URI {

	private Set<URI> occurrences;
	
	public Kind(String uri) {
		super(uri);
		this.occurrences = new HashSet<URI>();
	}
	
	public Set<URI> getOccurrences() {
		return this.occurrences;
	}
	
}
