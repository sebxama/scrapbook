package com.sebxama.augmentation.service;

import org.eclipse.rdf4j.spring.support.RDF4JTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.sebxama.augmentation.repository.ServiceRepository;
import com.sebxama.functional.model.Statement;
import com.sebxama.functional.model.dto.Quad;

import reactor.core.publisher.Flux;

@Service
public class AugmentationService {

	@Autowired
	RDF4JTemplate rdfTemplate;
	
	@Autowired
	IndexService indexService;
	
	@Autowired
	NamingService namingService;
	
	@Autowired
	RegistryService registryService;

	@Autowired
	ServiceRepository serviceRepository;
	
	@Autowired
	WebClient.Builder wcBuilder;
	
	public Flux<Quad> perform(Flux<Quad> stream) {
		// TODO:
		// 0. Datasources Quads (AugmentationController)
		// 1. Statements from Quads: RegistryService::getStatement(Quad) : stats
		// 2. AggregationService::perform(Statements stats) : aggreggate
		// 3. AlignmentService::perform(Statements aggregate) : align
		// 4. ActivationService::perform(Statements align) : activate
		// 5. Update Registry, Naming, Index (Model). Return Quads for Datasources sync
		// 6. Consumers :: Templates, Post Context (Kind) Statements
		
		return null;
	}
	
}
