package com.cognescent.core.services.alignment;

public class AlignmentService {

	public void performAlignment() {
		
		// Align Statement Kinds, Kinds Resources (IRI: IRIStatementOccurrence CSPO).
		// Infer / materialize inferred / missing links over aggregated Model.
		
	}
	
}
