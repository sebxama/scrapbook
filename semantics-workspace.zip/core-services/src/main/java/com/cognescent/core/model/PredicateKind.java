package com.cognescent.core.model;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.cognescent.core.streams.PredicateKindsStream;

public class PredicateKind extends Kind<StatementPredicate, StatementSubject, StatementObject> {

	private static Map<IRI, PredicateKind> predicateKinds = new HashMap<IRI, PredicateKind>();
	
	protected PredicateKind() {
		PredicateKindsStream.getInstance().addPredicateKind(this);	
	}

	public static PredicateKind getByIRI(IRI iri) {
		PredicateKind ret = predicateKinds.get(iri);
		if(ret == null) {
			ret = new PredicateKind();
			ret.setIRI(iri);
			predicateKinds.put(iri, ret);
		}
		return ret;
	}
	
	public static Collection<PredicateKind> getPredicateKinds() {
		return predicateKinds.values();
	}
	
	public String toString() {
		return "{\"className\": \""+this.getClass().getCanonicalName()+"\", "+ 
					"\"IRI\" : "+this.getIRI().getValue()+", " +
					"\"parent\" : + "+this.getParent().toString()+", " +
					"\"instances\" : + "+this.getInstances().toString()+", " +
					"\"attributes\" : + "+this.getAttributes().toString() + ", " +
					"\"values\" : + "+this.getValues().toString() + "}";
	}
	
	public int hashCode() {
		return (this.getClass().getCanonicalName() + ":" + this.getIRI().getValue()).hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
