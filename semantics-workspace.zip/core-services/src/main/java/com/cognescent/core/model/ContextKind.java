package com.cognescent.core.model;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ContextKind extends Kind<StatementContext, StatementSubject, StatementObject> {

	private static Map<IRI, ContextKind> contextKinds = new HashMap<IRI, ContextKind>();
	
	protected ContextKind() {

	}

	public static ContextKind getByIRI(IRI iri) {
		ContextKind ret = contextKinds.get(iri);
		if(ret == null) {
			ret = new ContextKind();
			ret.setIRI(iri);
			contextKinds.put(iri, ret);
		}
		return ret;
	}
	
	public static Collection<ContextKind> getContextKinds() {
		return contextKinds.values();
	}
	
	public String toString() {
		return "{\"className\": \""+this.getClass().getCanonicalName()+"\", "+ 
					"\"IRI\" : \""+this.getIRI().getValue()+"\", " +
					"\"parent\" : "+ (this.getParent() != null ? this.getParent().toString() : "{}") +", " +
					"\"instances\" : "+this.getInstances().toString()+", " +
					"\"attributes\" : "+this.getAttributes().toString() + ", " +
					"\"values\" : "+this.getValues().toString() + "}";
	}
	
	public int hashCode() {
		return (this.getClass().getCanonicalName() + ":" + this.getIRI().getValue()).hashCode();
	}
	
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}

}
