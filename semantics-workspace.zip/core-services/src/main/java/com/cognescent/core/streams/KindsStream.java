package com.cognescent.core.streams;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.IRI;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.Statement;
import com.cognescent.core.model.StatementContext;

import reactor.core.publisher.Flux;

public class KindsStream {

	private static KindsStream instance;
	public static KindsStream getInstance() {
		if(instance == null)
			instance = new KindsStream();
		return instance;
	}
	
	private Set<Kind> kinds;
	
	protected KindsStream() {
		this.kinds = new HashSet<Kind>();
	}
	
	public void addKind(Kind kind) {
		this.kinds.add(kind);
	}
	
	public void removeKind(Kind kind) {
		this.kinds.remove(kind);
	}
	
	public Flux<Kind> getStream() {
		return Flux.fromIterable(this.kinds);
	}
	
//	public Iterable<Statement> mapStatements(Iterable<IRI> match) {
//		// TODO:
//		return null;
//	}
//	
//	public Iterable<IRI> mapIRIs(Iterable<Statement> match) {
//		// TODO:
//		return null;
//	}
	
}
