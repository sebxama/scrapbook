package core.model.activation;

// Infer state / flow: contexts / interactions.
public class Activation {

}
