package com.sebxama.augmentation.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

import org.eclipse.rdf4j.spring.support.RDF4JTemplate;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.kafka.core.reactive.ReactiveKafkaProducerTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClient.UriSpec;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sebxama.augmentation.repository.ServiceRepository;
import com.sebxama.functional.model.ContextKind;
import com.sebxama.functional.model.Kind;
import com.sebxama.functional.model.PredicateKind;
import com.sebxama.functional.model.Statement;
import com.sebxama.functional.model.SubjectKind;
import com.sebxama.functional.model.URI;
import com.sebxama.functional.model.ValueKind;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class RegistryService {

	@Autowired
	RDF4JService rdfTemplate;
	
	@Autowired
	PrimesIDService idsService;
	
	@Autowired
	ServiceRepository espectadorRepository;

	@Autowired
	ReactiveKafkaProducerTemplate<String, String> rkpt;
	
	private Map<String, URI> URIs;
	private Map<URI, ContextKind> contextKinds;
	private Map<URI, SubjectKind> subjectKinds;
	private Map<URI, PredicateKind> predicateKinds;
	private Map<URI, ValueKind> valueKinds;
	private Map<URI, Statement> statements;
	
	public RegistryService() {
		this.URIs = new HashMap<String, URI>();
		this.contextKinds = new HashMap<URI, ContextKind>();
		this.subjectKinds = new HashMap<URI, SubjectKind>();
		this.predicateKinds = new HashMap<URI, PredicateKind>();
		this.valueKinds = new HashMap<URI, ValueKind>();
		this.statements = new HashMap<URI, Statement>();
	}
	
	public URI getURI(String value) {
		URI ret = URIs.get(value);
		if(ret == null) {
			ret = new URI(value);
			ret.setPrimeID(idsService.getURIPrimeID(value));
			URIs.put(value, ret);
		}
		return ret;
	}

	public Set<URI> getURIs() {
		Set<URI> ret = new HashSet<URI>(URIs.values());
		return ret;
	}
	
	public Statement getStatement(URI context, URI subject, URI predicate, URI object) {
		URI id = getURI("urn:statement:"+context.getPrimeID()+":"+subject.getPrimeID()+":"+predicate.getPrimeID()+":"+object.getPrimeID());
		Statement ret = statements.get(id);
		if(ret == null) {
			ret = new Statement(context, subject, predicate, object);
			statements.put(id, ret);
			// TODO: Sync RDF4JTemplate
		}
		return ret;		
	}

	public Set<Statement> getStatements() {
		Set<Statement> ret = new HashSet<Statement>(statements.values());
		return ret;
	}
	
	public ContextKind getContextKind(URI uri) {
		ContextKind ret = contextKinds.get(uri);
		if(ret == null) {
			ret = new ContextKind();
			ret.setURI(uri);
			contextKinds.put(uri, ret);
		}
		return ret;
	}
	
	public Set<ContextKind> getContextKinds() {
		Set<ContextKind> ret = new HashSet<ContextKind>(contextKinds.values());
		return ret;
	}

	public SubjectKind getSubjectKind(URI uri) {
		SubjectKind ret = subjectKinds.get(uri);
		if(ret == null) {
			ret = new SubjectKind();
			ret.setURI(uri);
			subjectKinds.put(uri, ret);
		}
		return ret;
	}

	public Set<SubjectKind> getSubjectKinds() {
		Set<SubjectKind> ret = new HashSet<SubjectKind>(subjectKinds.values());
		return ret;
	}
	
	public PredicateKind getPredicateKind(URI uri) {
		PredicateKind ret = predicateKinds.get(uri);
		if(ret == null) {
			ret = new PredicateKind();
			ret.setURI(uri);
			predicateKinds.put(uri, ret);
		}
		return ret;
	}

	public Set<PredicateKind> getPredicateKinds() {
		Set<PredicateKind> ret = new HashSet<PredicateKind>(predicateKinds.values());
		return ret;
	}
	
	public ValueKind getValueKind(URI uri) {
		ValueKind ret = (ValueKind) valueKinds.get(uri);
		if(ret == null) {
			ret = new ValueKind();
			ret.setURI(uri);
			valueKinds.put(uri, ret);
		}
		return ret;
	}
	
}
