package com.cognescent.core.streams;

import java.util.HashSet;
import java.util.Set;

import com.cognescent.core.model.ContextKind;
import com.cognescent.core.model.IRI;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.PredicateKind;
import com.cognescent.core.model.Statement;
import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.SubjectKind;

import reactor.core.publisher.Flux;

public class PredicateKindsStream {

	private static PredicateKindsStream instance;
	public static PredicateKindsStream getInstance() {
		if(instance == null)
			instance = new PredicateKindsStream();
		return instance;
	}
	
	private Set<PredicateKind> kinds;
	
	protected PredicateKindsStream() {
		this.kinds = new HashSet<PredicateKind>();
	}
	
	public void addPredicateKind(PredicateKind kind) {
		this.kinds.add(kind);
	}
	
	public void removePredicateKind(PredicateKind kind) {
		this.kinds.remove(kind);
	}
	
	public Flux<PredicateKind> getStream() {
		return Flux.fromIterable(this.kinds);
	}
	
//	public Iterable<Statement> mapStatements(Iterable<IRI> match) {
//		// TODO:
//		return null;
//	}
//	
//	public Iterable<IRI> mapIRIs(Iterable<Statement> match) {
//		// TODO:
//		return null;
//	}
	
}
