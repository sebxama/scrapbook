package com.sebxama.functional.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sebxama.functional.model.objectmapper.deserializer.SubjectDeserializer;
import com.sebxama.functional.model.objectmapper.serializer.SubjectSerializer;

@JsonDeserialize(using = SubjectDeserializer.class)
@JsonSerialize(using = SubjectSerializer.class)
public class Subject implements URIOccurrence {

	private URI occurrenceURI;
	private URI uri;
	private Statement statement;
	private SubjectKind kind;
	
	public Subject() {

	}
	
	public URI getOccurrenceURI() {
		return this.occurrenceURI;
	}
	
	public void setOccurrenceURI(URI uri) {
		this.occurrenceURI = uri;
	}
	
	public URI getURI() {
		return this.uri;
	}
	
	public void setURI(URI uri) {
		uri.getSubjectOccurrences().add(this);
		this.uri = uri;
	}
	
	public Statement getStatement() {
		return this.statement;
	}
	
	public void setStatement(Statement stat) {
		this.statement = stat;
	}

	public SubjectKind getKind() {
		return this.kind;
	}
	
	public void setKind(SubjectKind kind) {
		kind.getSubjectOccurrences().add(this);
		kind.getURI().getSubjectOccurrences().add(this);
		this.kind = kind;
	}

	public String toString() {
		return "Subject; URI: " + this.uri; 
	}
	
}
