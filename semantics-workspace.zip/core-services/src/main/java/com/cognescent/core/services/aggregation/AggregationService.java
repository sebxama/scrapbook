package com.cognescent.core.services.aggregation;

import java.util.Set;

import com.cognescent.core.model.Statement;
import com.cognescent.core.model.StatementObject;
import com.cognescent.core.model.StatementPredicate;
import com.cognescent.core.model.StatementSubject;
import com.cognescent.core.model.Statements;
import com.cognescent.core.model.SubjectKind;

public class AggregationService {

	/*
	 * TODO: Kinds IRIStatementOccurrence / Context, IRIs
	 */
	public void performAggregation(Set<Statement> statements) {
		
		// 1. Aggregation: One Context per instance
		// 2. Merge Contexts: Contexts from lesser Attribute
		//    set count to same / increased Attribute set count
		//    Instances: compare contains relationship. new Kinds
		//    (unseen Attributes). Multiple Kinds (Occurrences).
		// 3. Materialize merged / aggregated Contexts (Kinds)
		//    into Model Kinds / KindStatements.
		
		// Subjects
		for(Statement stat : statements) {
			
			StatementSubject subj = stat.getSubject();
			AggregationKind.SubjectAggregationKind ctx = AggregationKind.getSubjectAggregationKind(subj.getIRI().getValue());
			AggregationInstance.SubjectAggregationInstance inst = AggregationInstance.getSubjectAggregationInstance(subj);
			inst.getRoles().put(stat, ctx);
			ctx.getInstances().add(inst);
			
			for(Statement stat2 : Statements.getInstance().getStatements(null, subj, null, null)) {
			
				StatementPredicate pred = stat2.getPredicate();
				AggregationAttribute.SubjectAggregationAttribute attr = AggregationAttribute.getSubjectAggregationAttribute(pred);
				
				for(Statement stat3 : Statements.getInstance().getStatements(null, subj, pred, null)) {
					
					StatementObject obj = stat3.getObject();
					AggregationValue.SubjectAggregationValue val = AggregationValue.getSubjectAggregationValue(obj);
					val.getInstances().put(attr, inst);
					attr.getValues().put(inst, val);
					
				}
			}
		}
		
	}
	
}
