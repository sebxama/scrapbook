package com.sebxama.functional.model.objectmapper.deserializer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.node.IntNode;
import com.sebxama.functional.model.Context;
import com.sebxama.functional.model.ContextKind;
import com.sebxama.functional.model.Property;
import com.sebxama.functional.model.Statement;
import com.sebxama.functional.model.Subject;
import com.sebxama.functional.model.SubjectKind;
import com.sebxama.functional.model.URI;
import com.sebxama.functional.service.RegistryService;

public class SubjectDeserializer extends StdDeserializer<Subject> { 

    public SubjectDeserializer() { 
        this(null); 
    } 

    public SubjectDeserializer(Class<?> vc) { 
        super(vc); 
    }

    @Override
    public Subject deserialize(JsonParser jp, DeserializationContext ctxt)
    	throws IOException, JsonProcessingException {
        
    	RegistryService registry = RegistryService.getInstance();
    	JsonNode node = jp.getCodec().readTree(jp);
        String statementUri = node.get("statement").asText();
        URI stmtUri = registry.getURI(statementUri);

        JsonParser parser = node.findValue("occurrenceUri").traverse();
        parser.setCodec(jp.getCodec());
        URI occUri = parser.readValueAs(URI.class);
        
        parser = node.findValue("uri").traverse();
        parser.setCodec(jp.getCodec());
        URI uri = parser.readValueAs(URI.class);

        parser = node.findValue("kind").traverse();
        parser.setCodec(jp.getCodec());
        SubjectKind kind = parser.readValueAs(SubjectKind.class);
        
        Subject ctx = registry.getSubject(uri);
        ctx.setOccurrenceURI(occUri);
        Statement stat = registry.getStatement(stmtUri);
        stat.setSubject(ctx);
        ctx.setStatement(stat);
        ctx.setURI(uri);
        ctx.setKind(kind);
        
        return ctx;
    }
}
