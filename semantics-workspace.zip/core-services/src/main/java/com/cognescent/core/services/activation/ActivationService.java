package com.cognescent.core.services.activation;

/**
 * Learn Interactions
 *
 */
public class ActivationService {

	public void performActivation() {
		
		// Front end API. Populate Domain Driven DOM (Dynamic Object Model).
		// Expose DCI (Data, Context, Interactions) Actors / Roles dynamic
		// Workflow API.
		
	}
	
}
