package com.cognescent.core.services.aggregation;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.cognescent.core.model.IRI;
import com.cognescent.core.model.IRIStatementOccurrence;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementObject;
import com.cognescent.core.model.StatementPredicate;
import com.cognescent.core.model.StatementSubject;
import com.cognescent.core.services.aggregation.AggregationInstance.ContextAggregationInstance;

/*
 * TODO: Kinds IRIStatementOccurrence / Context, IRIs
 */
public abstract class AggregationKind<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {
	
	private static Map<IRI, ContextAggregationKind> contextAggregations 
		= new HashMap<IRI, ContextAggregationKind>();
	private static Map<IRI, SubjectAggregationKind> subjectAggregations
		= new HashMap<IRI, SubjectAggregationKind>();
	private static Map<IRI, PredicateAggregationKind> predicateAggregations
		= new HashMap<IRI, PredicateAggregationKind>();
	private static Map<IRI, ObjectAggregationKind> objectAggregations
		= new HashMap<IRI, ObjectAggregationKind>();
	
	private IRI iri;
	private AggregationKind<INST, ATTR, VAL> parent;
	private Set<AggregationInstance<INST, ATTR, VAL>> instances;
	private Set<AggregationAttribute<INST, ATTR, VAL>> attributes;
	private Set<AggregationValue<INST, ATTR, VAL>> values;
	
	protected AggregationKind(IRI iri) {
		this.iri = iri;
		this.instances = new HashSet<AggregationInstance<INST, ATTR, VAL>>();
		this.attributes = new HashSet<AggregationAttribute<INST, ATTR, VAL>>();
		this.values = new HashSet<AggregationValue<INST, ATTR, VAL>>();
	}

	public IRI getIRI() {
		return iri;
	}

	public void setIRI(IRI iri) {
		this.iri = iri;
	}

	public AggregationKind<INST, ATTR, VAL> getParent() {
		return parent;
	}

	public void setParent(AggregationKind<INST, ATTR, VAL> parent) {
		this.parent = parent;
	}

	public Set<AggregationInstance<INST, ATTR, VAL>> getInstances() {
		return instances;
	}

	public Set<AggregationAttribute<INST, ATTR, VAL>> getAttributes() {
		return attributes;
	}

	public Set<AggregationValue<INST, ATTR, VAL>> getValues() {
		return values;
	}
	
	public static Collection<ContextAggregationKind> getContextAggregationKinds() {
		return contextAggregations.values();
	}

	public static void putContextAggregationKind(IRI iri, ContextAggregationKind kind) {
		contextAggregations.put(iri, kind);
	}
	
	public static ContextAggregationKind getContextAggregationKind(IRI iri) {
		ContextAggregationKind ret = contextAggregations.get(iri);
		if(ret == null) {
			ret = new ContextAggregationKind(iri);
			contextAggregations.put(iri, ret);
		}
		return ret;
	}

	public static Collection<SubjectAggregationKind> getSubjectAggregationKinds() {
		return subjectAggregations.values();
	}
	
	public static void putSubjectAggregationKind(IRI iri, SubjectAggregationKind kind) {
		subjectAggregations.put(iri, kind);
	}
	
	public static SubjectAggregationKind getSubjectAggregationKind(IRI iri) {
		SubjectAggregationKind ret = subjectAggregations.get(iri);
		if(ret == null) {
			ret = new SubjectAggregationKind(iri);
			subjectAggregations.put(iri, ret);
		}
		return ret;
	}

	public static Collection<PredicateAggregationKind> getPredicateAggregationKinds() {
		return predicateAggregations.values();
	}

	public static void putPredicateAggregationKind(IRI iri, PredicateAggregationKind kind) {
		predicateAggregations.put(iri, kind);
	}
	
	public static PredicateAggregationKind getPredicateAggregationKind(IRI iri) {
		PredicateAggregationKind ret = predicateAggregations.get(iri);
		if(ret == null) {
			ret = new PredicateAggregationKind(iri);
			predicateAggregations.put(iri, ret);
		}
		return ret;
	}

	public static Collection<ObjectAggregationKind> getObjectAggregationKinds() {
		return objectAggregations.values();
	}
	
	public static void putObjectAggregationKind(IRI iri, ObjectAggregationKind kind) {
		objectAggregations.put(iri, kind);
	}
	
	public static ObjectAggregationKind getObjectAggregationKind(IRI iri) {
		ObjectAggregationKind ret = objectAggregations.get(iri);
		if(ret == null) {
			ret = new ObjectAggregationKind(iri);
			objectAggregations.put(iri, ret);
		}
		return ret;
	}
	
	static class ContextAggregationKind extends AggregationKind<StatementContext, StatementSubject, StatementObject> {

		public ContextAggregationKind(IRI iri) {
			super(iri);
			contextAggregations.put(iri, this);
		}

		public String toString() {
			return "{ \"className\": \""+this.getClass().getName()+"\", \"IRI\" : \""+this.getIRI().getValue()+"\"}";
		}
		
		public int hashCode() {
			return this.toString().hashCode();
		}
		
		public boolean equals(Object obj) {
			return this.hashCode() == obj.hashCode();
		}

	}
	
	static class SubjectAggregationKind extends AggregationKind<StatementSubject, StatementPredicate, StatementObject> {

		public SubjectAggregationKind(IRI iri) {
			super(iri);
			super.subjectAggregations.put(iri, this);
		}

		public String toString() {
			return "{ \"className\": \""+this.getClass().getName()+"\", \"IRI\" : \""+this.getIRI().getValue()+"\"}";
		}
		
		public int hashCode() {
			return this.toString().hashCode();
		}
		
		public boolean equals(Object obj) {
			return this.hashCode() == obj.hashCode();
		}
		
	}
	
	static class PredicateAggregationKind extends AggregationKind<StatementPredicate, StatementSubject, StatementObject> {

		public PredicateAggregationKind(IRI iri) {
			super(iri);
			super.predicateAggregations.put(iri, this);
		}

		public String toString() {
			return "{ \"className\": \""+this.getClass().getName()+"\", \"IRI\" : \""+this.getIRI().getValue()+"\"}";
		}
		
		public int hashCode() {
			return this.toString().hashCode();
		}
		
		public boolean equals(Object obj) {
			return this.hashCode() == obj.hashCode();
		}
		
	}
	
	static class ObjectAggregationKind extends AggregationKind<StatementObject, StatementPredicate, StatementSubject> {

		public ObjectAggregationKind(IRI iri) {
			super(iri);
			super.objectAggregations.put(iri, this);
		}

		public String toString() {
			return "{ \"className\": \""+this.getClass().getName()+"\", \"IRI\" : \""+this.getIRI().getValue()+"\"}";
		}
		
		public int hashCode() {
			return this.toString().hashCode();
		}
		
		public boolean equals(Object obj) {
			return this.hashCode() == obj.hashCode();
		}

	}

}
