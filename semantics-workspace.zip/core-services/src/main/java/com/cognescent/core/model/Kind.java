package com.cognescent.core.model;

public abstract class Kind<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {

	private INST instance;
	private ATTR attribute;
	private VAL value;
	
	public Kind() {
		
	}

	public INST getInstance() {
		return instance;
	}

	public void setInstance(INST instance) {
		this.instance = instance;
	}

	public ATTR getAttribute() {
		return attribute;
	}

	public void setAttribute(ATTR attribute) {
		this.attribute = attribute;
	}

	public VAL getValue() {
		return value;
	}

	public void setValue(VAL value) {
		this.value = value;
	}
	
}
