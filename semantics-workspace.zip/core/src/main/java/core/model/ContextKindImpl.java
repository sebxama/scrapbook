package core.model;

import java.util.HashMap;
import java.util.Map;

public class ContextKindImpl extends KindImpl<Context, Property, Object> implements ContextKind {
	
	public ContextKindImpl(Resource iri) {
		super(iri);
	}
	
}
