package com.cognescent.core.services.aggregation;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.cognescent.core.model.IRI;
import com.cognescent.core.model.IRIStatementOccurrence;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementObject;
import com.cognescent.core.model.StatementPredicate;
import com.cognescent.core.model.StatementSubject;

/*
 * TODO: Kinds IRIStatementOccurrence / Context, IRIs
 */
public class AggregationKind<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {
	
	private static Map<String, ContextAggregationKind> contextAggregations 
		= new HashMap<String, ContextAggregationKind>();
	private static Map<String, SubjectAggregationKind> subjectAggregations
		= new HashMap<String, SubjectAggregationKind>();
	private static Map<String, PredicateAggregationKind> predicateAggregations
		= new HashMap<String, PredicateAggregationKind>();
	private static Map<String, ObjectAggregationKind> objectAggregations
		= new HashMap<String, ObjectAggregationKind>();
	
	private String iri;
	private AggregationKind<INST, ATTR, VAL> parent;
	private Set<AggregationInstance<INST, ATTR, VAL>> instances;
	private Set<AggregationAttribute<INST, ATTR, VAL>> attributes;
	private Set<AggregationValue<INST, ATTR, VAL>> values;
	
	protected AggregationKind(String iri) {
		this.iri = iri;
		this.instances = new HashSet<AggregationInstance<INST, ATTR, VAL>>();
		this.attributes = new HashSet<AggregationAttribute<INST, ATTR, VAL>>();
		this.values = new HashSet<AggregationValue<INST, ATTR, VAL>>();
	}

	public String getIRI() {
		return iri;
	}

	public void setIRI(String iri) {
		this.iri = iri;
	}

	public AggregationKind<INST, ATTR, VAL> getParent() {
		return parent;
	}

	public void setParent(AggregationKind<INST, ATTR, VAL> parent) {
		this.parent = parent;
	}

	public Set<AggregationInstance<INST, ATTR, VAL>> getInstances() {
		return instances;
	}

	public Set<AggregationAttribute<INST, ATTR, VAL>> getAttributes() {
		return attributes;
	}

	public Set<AggregationValue<INST, ATTR, VAL>> getValues() {
		return values;
	}
	
	public static ContextAggregationKind getContextAggregationKind(String iri) {
		ContextAggregationKind ret = contextAggregations.get(iri);
		if(ret == null) {
			ret = new ContextAggregationKind(iri);
			contextAggregations.put(iri, ret);
		}
		return ret;
	}

	public static SubjectAggregationKind getSubjectAggregationKind(String iri) {
		SubjectAggregationKind ret = subjectAggregations.get(iri);
		if(ret == null) {
			ret = new SubjectAggregationKind(iri);
			subjectAggregations.put(iri, ret);
		}
		return ret;
	}

	public static PredicateAggregationKind getPredicateAggregationKind(String iri) {
		PredicateAggregationKind ret = predicateAggregations.get(iri);
		if(ret == null) {
			ret = new PredicateAggregationKind(iri);
			predicateAggregations.put(iri, ret);
		}
		return ret;
	}

	public static ObjectAggregationKind getObjectAggregationKind(String iri) {
		ObjectAggregationKind ret = objectAggregations.get(iri);
		if(ret == null) {
			ret = new ObjectAggregationKind(iri);
			objectAggregations.put(iri, ret);
		}
		return ret;
	}
	
	static class ContextAggregationKind extends AggregationKind<StatementContext, StatementSubject, StatementObject> {

		public ContextAggregationKind(String iri) {
			super(iri);
			super.contextAggregations.put(iri, this);
		}
		
	}
	
	static class SubjectAggregationKind extends AggregationKind<StatementSubject, StatementPredicate, StatementObject> {

		public SubjectAggregationKind(String iri) {
			super(iri);
			super.subjectAggregations.put(iri, this);
		}
		
	}
	
	static class PredicateAggregationKind extends AggregationKind<StatementPredicate, StatementSubject, StatementObject> {

		public PredicateAggregationKind(String iri) {
			super(iri);
			super.predicateAggregations.put(iri, this);
		}
		
	}
	
	static class ObjectAggregationKind extends AggregationKind<StatementObject, StatementPredicate, StatementSubject> {

		public ObjectAggregationKind(String iri) {
			super(iri);
			super.objectAggregations.put(iri, this);
		}
		
	}
	
}