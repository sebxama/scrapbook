package com.sebxama.augmentation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sebxama.augmentation.service.AugmentationService;
import com.sebxama.functional.model.Statement;
import com.sebxama.functional.model.dto.Quad;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/augmentation")
public class AugmentationController {

	@Autowired
	AugmentationService augmentationService;
	
	@GetMapping("/ping")
	@ResponseStatus(HttpStatus.OK)
	public Mono<String> ping() {
		return Mono.just("OK");
	}

	@PostMapping("/perform")
	@ResponseStatus(HttpStatus.OK)
	public Flux<Quad> perform(Flux<Quad> stream) {
		return augmentationService.perform(stream);
	}
	
}
