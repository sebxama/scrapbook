package com.cognescent.core.services.aggregation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.cognescent.core.model.ContextKind;
import com.cognescent.core.model.IRI;
import com.cognescent.core.model.IRIStatementOccurrence;
import com.cognescent.core.model.Kind;
import com.cognescent.core.model.Kinds;
import com.cognescent.core.model.Statement;
import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementObject;
import com.cognescent.core.model.StatementPredicate;
import com.cognescent.core.model.StatementSubject;
import com.cognescent.core.model.Statements;
import com.cognescent.core.model.SubjectKind;
import com.cognescent.core.services.aggregation.AggregationKind.ContextAggregationKind;
import com.cognescent.core.services.aggregation.AggregationKind.ObjectAggregationKind;
import com.cognescent.core.services.aggregation.AggregationKind.PredicateAggregationKind;
import com.cognescent.core.services.aggregation.AggregationKind.SubjectAggregationKind;

public class AggregationService {

	/*
	 * TODO: Kinds IRIStatementOccurrence / Context, Placeholder IRIs (Statement)
	 */
	public void performAggregation() {

		// 1. Aggregation: One Context per instance
		// 2. Merge Contexts: Contexts from lesser Attribute
		//    set count to same / increased Attribute set count
		//    Instances: compare contains relationship. Sub Kinds
		//    Attribute sets contains super Kind Attribute sets. 
		//    new Kinds (unseen Attributes). Multiple Kinds (Occurrences).
		// 3. Materialize merged / aggregated Contexts (Kinds)
		//    into Model Kinds / KindStatements.

		// Contexts
		for(StatementContext ctx : Statements.getInstance().getStatementContexts()) {

			AggregationKind.ContextAggregationKind kind = AggregationKind.getContextAggregationKind(ctx.getIRI());
			AggregationInstance.ContextAggregationInstance inst = AggregationInstance.getContextAggregationInstance(ctx);
			kind.getInstances().add(inst);

			for(Statement stat2 : Statements.getInstance().getStatements(ctx, null, null, null)) {

				inst.getRoles().put(stat2, kind);
				StatementSubject subj = stat2.getSubject();
				AggregationAttribute.ContextAggregationAttribute attr = AggregationAttribute.getContextAggregationAttribute(subj);
				kind.getAttributes().add(attr);
				
				for(Statement stat3 : Statements.getInstance().getStatements(ctx, subj, null, null)) {

					StatementObject obj = stat3.getObject();
					AggregationValue.ContextAggregationValue val = AggregationValue.getContextAggregationValue(obj);
					val.getInstances().put(attr, inst);
					attr.getValues().put(inst, val);
					kind.getValues().add(val);

				}
			}
		}

		List<ContextAggregationKind> sortedContextKinds = new ArrayList<ContextAggregationKind>(AggregationKind.getContextAggregationKinds());
		Collections.sort(sortedContextKinds, new Comparator<ContextAggregationKind>() {
			@Override
			public int compare(ContextAggregationKind o1, ContextAggregationKind o2) {
				if(o1.getAttributes().size() < o2.getAttributes().size())
					return -1;
				if(o1.getAttributes().size() > o2.getAttributes().size())
					return 1;
				return 0;
			}
		});
		
		aggregateContextKinds(sortedContextKinds);
		
		// Subjects
		for(StatementSubject subj : Statements.getInstance().getStatementSubjects()) {

			AggregationKind.SubjectAggregationKind kind = AggregationKind.getSubjectAggregationKind(subj.getIRI());
			AggregationInstance.SubjectAggregationInstance inst = AggregationInstance.getSubjectAggregationInstance(subj);
			kind.getInstances().add(inst);

			for(Statement stat2 : Statements.getInstance().getStatements(null, subj, null, null)) {

				inst.getRoles().put(stat2, kind);
				StatementPredicate pred = stat2.getPredicate();
				AggregationAttribute.SubjectAggregationAttribute attr = AggregationAttribute.getSubjectAggregationAttribute(pred);
				kind.getAttributes().add(attr);
				
				for(Statement stat3 : Statements.getInstance().getStatements(null, subj, pred, null)) {

					StatementObject obj = stat3.getObject();
					AggregationValue.SubjectAggregationValue val = AggregationValue.getSubjectAggregationValue(obj);
					val.getInstances().put(attr, inst);
					attr.getValues().put(inst, val);
					kind.getValues().add(val);
					
				}
			}
		}

		List<SubjectAggregationKind> sortedSubjectKinds = new ArrayList<SubjectAggregationKind>(AggregationKind.getSubjectAggregationKinds());
		Collections.sort(sortedSubjectKinds, new Comparator<SubjectAggregationKind>() {
			@Override
			public int compare(SubjectAggregationKind o1, SubjectAggregationKind o2) {
				if(o1.getAttributes().size() < o2.getAttributes().size())
					return -1;
				if(o1.getAttributes().size() > o2.getAttributes().size())
					return 1;
				return 0;
			}
		});
		
		// Predicates
		for(StatementPredicate pred : Statements.getInstance().getStatementPredicates()) {

			AggregationKind.PredicateAggregationKind kind = AggregationKind.getPredicateAggregationKind(pred.getIRI());
			AggregationInstance.PredicateAggregationInstance inst = AggregationInstance.getPredicateAggregationInstance(pred);
			kind.getInstances().add(inst);

			for(Statement stat2 : Statements.getInstance().getStatements(null, null, pred, null)) {

				inst.getRoles().put(stat2, kind);
				StatementSubject subj = stat2.getSubject();
				AggregationAttribute.PredicateAggregationAttribute attr = AggregationAttribute.getPredicateAggregationAttribute(subj);
				kind.getAttributes().add(attr);
				
				for(Statement stat3 : Statements.getInstance().getStatements(null, subj, pred, null)) {

					StatementObject obj = stat3.getObject();
					AggregationValue.PredicateAggregationValue val = AggregationValue.getPredicateAggregationValue(obj);
					val.getInstances().put(attr, inst);
					attr.getValues().put(inst, val);
					kind.getValues().add(val);
					
				}
			}
		}

		List<PredicateAggregationKind> sortedPredicateKinds = new ArrayList<PredicateAggregationKind>(AggregationKind.getPredicateAggregationKinds());
		Collections.sort(sortedPredicateKinds, new Comparator<PredicateAggregationKind>() {
			@Override
			public int compare(PredicateAggregationKind o1, PredicateAggregationKind o2) {
				if(o1.getAttributes().size() < o2.getAttributes().size())
					return -1;
				if(o1.getAttributes().size() > o2.getAttributes().size())
					return 1;
				return 0;
			}
		});
		
		// Objects
		for(StatementObject obj : Statements.getInstance().getStatementObjects()) {

			AggregationKind.ObjectAggregationKind kind = AggregationKind.getObjectAggregationKind(obj.getIRI());
			AggregationInstance.ObjectAggregationInstance inst = AggregationInstance.getObjectAggregationInstance(obj);
			kind.getInstances().add(inst);

			for(Statement stat2 : Statements.getInstance().getStatements(null, null, null, obj)) {

				inst.getRoles().put(stat2, kind);
				StatementPredicate pred = stat2.getPredicate();
				AggregationAttribute.ObjectAggregationAttribute attr = AggregationAttribute.getObjectAggregationAttribute(pred);
				kind.getAttributes().add(attr);
				
				for(Statement stat3 : Statements.getInstance().getStatements(null, null, pred, obj)) {

					StatementSubject subj = stat3.getSubject();
					AggregationValue.ObjectAggregationValue val = AggregationValue.getObjectAggregationValue(subj);
					val.getInstances().put(attr, inst);
					attr.getValues().put(inst, val);
					kind.getValues().add(val);

				}
			}
		}

		List<ObjectAggregationKind> sortedObjectKinds = new ArrayList<ObjectAggregationKind>(AggregationKind.getObjectAggregationKinds());
		Collections.sort(sortedObjectKinds, new Comparator<ObjectAggregationKind>() {
			@Override
			public int compare(ObjectAggregationKind o1, ObjectAggregationKind o2) {
				if(o1.getAttributes().size() < o2.getAttributes().size())
					return -1;
				if(o1.getAttributes().size() > o2.getAttributes().size())
					return 1;
				return 0;
			}
		});
		
	}

	private void aggregateContextKinds(List<ContextAggregationKind> kinds) {
		ContextAggregationKind k1 = null;
		ContextAggregationKind k2 = null;
		if(k2.getAttributes().containsAll(k1.getAttributes())) {
			if(k1.getAttributes().size() == k2.getAttributes().size()) {
				// Same Kind.
				String mergedKindIRIString = ""; // FIXME: Calculate hash (embedding).
				IRI mergedKindIRI = IRI.get(mergedKindIRIString);
				ContextAggregationKind mergedKind = AggregationKind.getContextAggregationKind(mergedKindIRI);
				mergedKind.getInstances().addAll(k1.getInstances());
				mergedKind.getAttributes().addAll(k1.getAttributes());
				mergedKind.getValues().addAll(k1.getValues());
				mergedKind.getInstances().addAll(k2.getInstances());
				mergedKind.getAttributes().addAll(k2.getAttributes());
				mergedKind.getValues().addAll(k2.getValues());
				AggregationKind.putContextAggregationKind(k1.getIRI(), mergedKind);
				AggregationKind.putContextAggregationKind(k2.getIRI(), mergedKind);
			} else {
				// k1 subset of k2 (Super Kind)
				k2.setParent(k1);
			}
		}
	}
	
	private void aggregateStatementContextKinds(List<ContextAggregationKind> kinds) {
		for(ContextAggregationKind kind : kinds) {
			ContextKind contextKind = Kinds.getInstance().getContextKind(kind.getIRI());
			// Populate
			contextKind.getInstances().addAll(null);
			contextKind.getAttributes().addAll(null);
			contextKind.getValues().addAll(null);
			// Update Kinds registry
			// Kinds.putContextKind(iri, contextKind)
			// Update Occurrences
			for(IRIStatementOccurrence occur : contextKind.getIRI().getOccurrences()) {
				for(Statement stat : occur.getStatementOccurrences())
					stat.setContextKind(contextKind);
			}
			
		}
	}
	
}
