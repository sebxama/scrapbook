package core.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

public class StatementImpl extends ResourceOccurrenceImpl implements Statement {

	private Context context;
	private Subject subject;
	private Property property;
	private Object object;

	private ContextKind contextKind;
	private SubjectKind subjectKind;
	private PropertyKind propertyKind;
	private ObjectKind objectKind;
	
	protected StatementImpl(Resource iri) {
		super(iri);
	}

	public static StatementImpl build(Resource iri) {
		StatementImpl ret = new StatementImpl(iri);
		return ret;
	}
	
	@JsonBackReference
	public Context getContext() {
		return context;
	}

	@JsonBackReference
	public Subject getSubject() {
		return subject;
	}

	@JsonBackReference
	public Property getProperty() {
		return property;
	}

	@JsonBackReference
	public Object getObject() {
		return object;
	}

	public StatementImpl setContext(Context context) {
		context.setContextStatement(this);
		this.context = context;
		return this;
	}

	public StatementImpl setSubject(Subject subject) {
		subject.setContextStatement(this);
		this.subject = subject;
		return this;
		
	}

	public StatementImpl setProperty(Property property) {
		property.setContextStatement(this);
		this.property = property;
		return this;
	}

	public StatementImpl setObject(Object object) {
		object.setContextStatement(this);
		this.object = object;
		return this;
	}
	
	@JsonBackReference
	public ContextKind getContextKind() {
		return contextKind;
	}

	public StatementImpl setContextKind(ContextKind contextKind) {
		this.contextKind = contextKind;
		return this;
	}

	@JsonBackReference
	public SubjectKind getSubjectKind() {
		return subjectKind;
	}

	public StatementImpl setSubjectKind(SubjectKind subjectKind) {
		this.subjectKind = subjectKind;
		return this;
	}

	@JsonBackReference
	public PropertyKind getPropertyKind() {
		return propertyKind;
	}

	public StatementImpl setPropertyKind(PropertyKind propertyKind) {
		this.propertyKind = propertyKind;
		return this;
	}

	@JsonBackReference
	public ObjectKind getObjectKind() {
		return objectKind;
	}

	public StatementImpl setObjectKind(ObjectKind objectKind) {
		this.objectKind = objectKind;
		return this;
	}

	@Override
	public Resource getResource() {
		return Resource.getStatementResource(this.context, this.subject, this.property, this.object);
	}
	
	@Override
	public String toString() {
		return getResource().getIRI();
	}
	
	@Override
	public int hashCode() {
		return this.toString().hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		return this.hashCode() == obj.hashCode();
	}
	
}
