package core.model;

public class ObjectImpl extends ResourceOccurrenceImpl implements Object {

	private ObjectKind kind;
	
	public ObjectImpl(Resource iri) {
		super(iri);
	}
	
	public ObjectKind getObjectKind() {
		return this.kind;
	}
	
	public void setObjectKind(ObjectKind kind) {
		this.kind = kind;
	}
	
}
