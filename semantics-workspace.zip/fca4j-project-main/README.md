# fca4j-project

A set of tools and algorithms for Formal Concept Analysis