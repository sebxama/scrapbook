package com.cognescent.core.services.aggregation;

import java.util.HashMap;
import java.util.Map;

import com.cognescent.core.model.IRI;
import com.cognescent.core.model.IRIStatementOccurrence;
import com.cognescent.core.model.StatementContext;
import com.cognescent.core.model.StatementObject;
import com.cognescent.core.model.StatementPredicate;
import com.cognescent.core.model.StatementSubject;
import com.cognescent.core.services.aggregation.AggregationInstance.ContextAggregationInstance;
import com.cognescent.core.services.aggregation.AggregationInstance.ObjectAggregationInstance;
import com.cognescent.core.services.aggregation.AggregationInstance.PredicateAggregationInstance;
import com.cognescent.core.services.aggregation.AggregationInstance.SubjectAggregationInstance;

public class AggregationAttribute<INST extends IRIStatementOccurrence, ATTR extends IRIStatementOccurrence, VAL extends IRIStatementOccurrence> {

	private static Map<IRI, ContextAggregationAttribute> contextAggregations
		= new HashMap<IRI, ContextAggregationAttribute>();
	private static Map<IRI, SubjectAggregationAttribute> subjectAggregations
		= new HashMap<IRI, SubjectAggregationAttribute>();
	private static Map<IRI, PredicateAggregationAttribute> predicateAggregations
		= new HashMap<IRI, PredicateAggregationAttribute>();;
	private static Map<IRI, ObjectAggregationAttribute> objectAggregations
		= new HashMap<IRI, ObjectAggregationAttribute>();;
	
	private IRI iri;
	private ATTR attribute;
	private Map<AggregationInstance<INST, ATTR, VAL>, AggregationValue<INST, ATTR, VAL>> values;
	
	public AggregationAttribute(ATTR attribute) {
		this.iri = attribute.getIRI();
		this.attribute = attribute;
		this.values = new HashMap<AggregationInstance<INST, ATTR, VAL>, AggregationValue<INST, ATTR, VAL>>();
	}

	public ATTR getAttribute() {
		return this.attribute;
	}

	public IRI getIRI() {
		return iri;
	}

	public void setIRI(IRI iri) {
		this.iri = iri;
	}
	
	public Map<AggregationInstance<INST, ATTR, VAL>, AggregationValue<INST, ATTR, VAL>> getValues() {
		return this.values;
	}

	public static ContextAggregationAttribute getContextAggregationAttribute(StatementSubject subj) {
		ContextAggregationAttribute ret = contextAggregations.get(subj.getIRI());
		if(ret == null) {
			ret = new ContextAggregationAttribute(subj);
			contextAggregations.put(subj.getIRI(), ret);
		}
		return ret;
	}

	public static SubjectAggregationAttribute getSubjectAggregationAttribute(StatementPredicate pred) {
		SubjectAggregationAttribute ret = subjectAggregations.get(pred.getIRI());
		if(ret == null) {
			ret = new SubjectAggregationAttribute(pred);
			subjectAggregations.put(pred.getIRI(), ret);
		}
		return ret;
	}

	public static PredicateAggregationAttribute getPredicateAggregationAttribute(StatementSubject subj) {
		PredicateAggregationAttribute ret = predicateAggregations.get(subj.getIRI());
		if(ret == null) {
			ret = new PredicateAggregationAttribute(subj);
			predicateAggregations.put(subj.getIRI(), ret);
		}
		return ret;
	}

	public static ObjectAggregationAttribute getObjectAggregationAttribute(StatementPredicate pred) {
		ObjectAggregationAttribute ret = objectAggregations.get(pred.getIRI());
		if(ret == null) {
			ret = new ObjectAggregationAttribute(pred);
			objectAggregations.put(pred.getIRI(), ret);
		}
		return ret;
	}
	
	static class ContextAggregationAttribute extends AggregationAttribute<StatementContext, StatementSubject, StatementObject> {

		public ContextAggregationAttribute(StatementSubject subj) {
			super(subj);
			contextAggregations.put(subj.getIRI(), this);
		}
		
	}
	
	static class SubjectAggregationAttribute extends AggregationAttribute<StatementSubject, StatementPredicate, StatementObject> {

		public SubjectAggregationAttribute(StatementPredicate pred) {
			super(pred);
			subjectAggregations.put(pred.getIRI(), this);
		}
		
	}
	
	static class PredicateAggregationAttribute extends AggregationAttribute<StatementPredicate, StatementSubject, StatementObject> {

		public PredicateAggregationAttribute(StatementSubject subj) {
			super(subj);
			predicateAggregations.put(subj.getIRI(), this);
		}
		
	}
	
	static class ObjectAggregationAttribute extends AggregationAttribute<StatementObject, StatementPredicate, StatementSubject> {

		public ObjectAggregationAttribute(StatementPredicate pred) {
			super(pred);
			objectAggregations.put(pred.getIRI(), this);
		}
		
	}
	
}
