package core.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

public class ObjectKindImpl extends KindImpl<Object, Property, Subject> implements ObjectKind {
	
	public ObjectKindImpl(Resource iri) {
		super(iri);
	}
	
	@Override
	@JsonBackReference
	public ContextKind getContextKind() {
		return this.getContextStatement().getContextKind();
	}

	/**
	 * Relationship range.
	 */
	@Override
	@JsonBackReference
	public SubjectKind getSubjectKind() {
		return this.getContextStatement().getSubjectKind();
	}

	/**
	 * Relationship domain.
	 */
	@Override
	@JsonBackReference
	public PropertyKind getPropertyKind() {
		return this.getContextStatement().getPropertyKind();
	}

	@Override
	@JsonBackReference
	public ObjectKind getObjectKind() {
		return this.getContextStatement().getObjectKind();
	}
	
}
