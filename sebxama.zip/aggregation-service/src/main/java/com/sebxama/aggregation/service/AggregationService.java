package com.sebxama.aggregation.service;

import org.eclipse.rdf4j.spring.support.RDF4JTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.sebxama.aggregation.repository.ServiceRepository;
import com.sebxama.functional.model.Statement;
import com.sebxama.functional.service.IndexService;
import com.sebxama.functional.service.NamingService;
import com.sebxama.functional.service.RegistryService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AggregationService {

	@Autowired
	RDF4JTemplate rdfTemplate;
	
	@Autowired
	ServiceRepository serviceRepository;

	@Autowired
	WebClient.Builder wcBuilder;

	IndexService indexService = IndexService.getInstance();
	
	NamingService namingService = NamingService.getInstance();
	
	RegistryService registryService = RegistryService.getInstance();
	
	public Mono<Statement> perform(Statement stat) {
		// TODO
		System.out.println("AggregationService::perform");
		System.out.println(stat);
		return Mono.just(stat);
	}

}
