package com.sebxama.functional.model;

public class PredicateKind extends Kind {

	public PredicateKind(String uri) {
		super(uri);
	}
	
}
