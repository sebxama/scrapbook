package com.sebxama.activation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sebxama.activation.service.ActivationService;
import com.sebxama.functional.model.Statement;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/activation")
public class ActivationController {

	@Autowired
	ActivationService activationService;
	
	@GetMapping("/ping")
	@ResponseStatus(HttpStatus.OK)
	public Mono<String> ping() {
		return Mono.just("OK");
	}

	@PostMapping("/perform")
	@ResponseStatus(HttpStatus.OK)
	public Flux<Statement> perform(Flux<Statement> stream) {
		return activationService.perform(stream);
	}

}
